"""Verify submission file hashes without fitting models or importing numerical packages."""
from pathlib import Path
import argparse,csv,gzip,hashlib,sys
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);a=p.parse_args();root=a.root.resolve();failed=[];count=0;indexed=set()
with (root/'FILE_INDEX.csv').open(newline='') as f:
 for row in csv.DictReader(f):
  path=root/row['file'];count+=1;indexed.add(row['file'])
  if not path.is_file():failed.append((row['file'],'missing'));continue
  if path.stat().st_size!=int(row['bytes']) or hashlib.sha256(path.read_bytes()).hexdigest()!=row['sha256']:failed.append((row['file'],'size or hash mismatch'))
with (root/'provenance/SOURCE_RECORD_MAP.csv').open(newline='') as f:
 for row in csv.DictReader(f):
  path=root/row['submission_file']
  if not path.is_file():failed.append((row['submission_file'],'mapped file missing'));continue
  if hashlib.sha256(path.read_bytes()).hexdigest()!=row['submission_sha256']:failed.append((row['submission_file'],'source-map submission hash mismatch'))
  if row['action']=='retained unchanged' and row['source_sha256']!=row['submission_sha256']:failed.append((row['submission_file'],'unchanged original hash mismatch'))
  if row['action']=='losslessly gzip-compressed original':
   if hashlib.sha256(gzip.decompress(path.read_bytes())).hexdigest()!=row['source_sha256']:failed.append((row['submission_file'],'original decompressed hash mismatch'))
actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.relative_to(root).as_posix()!='FILE_INDEX.csv'}
for name in sorted(actual-indexed):failed.append((name,'not indexed'))
print('Checked',count,'submitted files')
for row in failed:print('FAIL',*row)
print('Submission integrity PASS' if not failed else 'Submission integrity FAIL')
sys.exit(bool(failed))
