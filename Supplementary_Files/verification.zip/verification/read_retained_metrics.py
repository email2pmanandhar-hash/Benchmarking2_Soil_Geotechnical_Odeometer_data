"""Read retained learner metrics and empirical comparator replacements without fitting models.
Usage: python verification/read_retained_metrics.py --study B --output StudyB_metrics.csv.gz
"""
from pathlib import Path
import argparse
import pandas as pd

def load_metrics(root,study):
    root=Path(root);study=study.upper();folder=root/f'S{"ABC".index(study)+1}_Study{study}'
    original=pd.read_csv(folder/'provenance/source_records/primary_metric_export_original.csv.gz',float_precision='round_trip')
    if study=='A':
        original['study']=study
        return original
    learners=original[original.model.isin(['RF','GBR','XGB','Ensemble'])].copy()
    geo=pd.read_csv(folder/'results/empirical_comparator_metrics_recomputed.csv',float_precision='round_trip')
    tasks=learners.query("analysis=='primary' and configuration=='XYZ' and model=='Ensemble' and split=='Test'")[['missing_type','target']].drop_duplicates()
    records=[learners,geo[geo.model=='RK']]
    for task in tasks.itertuples(index=False):
        record=geo[(geo.model=='OK')&(geo.target==task.target)].copy();record['missing_type']=task.missing_type;records.append(record)
    result=pd.concat(records,ignore_index=True);result['source_recorded_study']=result.study;result['study']=study
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);parser.add_argument('--study',choices=['A','B','C'],required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    data=load_metrics(args.root,args.study);data.to_csv(args.output,index=False,float_format='%.17g');print('Exported',len(data),'retained metric rows for Study',args.study)
