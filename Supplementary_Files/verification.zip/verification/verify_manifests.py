"""Verify supplied B/C execution links without fitting models or accessing raw inputs."""
from pathlib import Path
import argparse, csv, gzip, hashlib, json, math

ap = argparse.ArgumentParser(description=__doc__)
ap.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
ap.add_argument('--out', type=Path)
a = ap.parse_args()
root = a.root.resolve()
checks = []
def read(p):
    return json.loads(p.read_text())
def rows(p):
    with p.open(newline='') as f:
        return list(csv.DictReader(f))
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def check(study, name, ok, detail=''):
    checks.append(dict(study=study, check=name, status='PASS' if ok else 'FAIL', detail=detail))
def equal(x, y):
    if x is None:
        return y in ('', None)
    if isinstance(x, (int, float)):
        return math.isclose(float(x), float(y), rel_tol=1e-12, abs_tol=1e-12)
    return str(x) == str(y)

for study, dirname in [('B','S2_StudyB'), ('C','S3_StudyC')]:
    b = root / dirname
    p = b / 'provenance/original'
    tm, run, ex = [read(p / n) for n in ['tuning_manifest.json','run_manifest.json','execution_manifest.json']]
    check(study, 'Completed primary and empirical records', all(x['status']=='COMPLETE' for x in [tm,run,ex]))
    for name, expected in tm['original_artifact_sha256'].items():
        target = p/name if name=='run_manifest.json' else b/'identifiers'/name
        check(study, 'Empirical source artifact hash '+name, sha(target)==expected)
    for key, filename in [('original_cv_folds_sha256','cv_fold_identifiers.csv'), ('original_prediction_index_sha256','prediction_record_index.csv')]:
        check(study, key, sha(b/'identifiers'/filename)==tm[key])
    original = gzip.decompress((b/'provenance/source_records/primary_metric_export_original.csv.gz').read_bytes())
    check(study, 'Original metric receipt hash', hashlib.sha256(original).hexdigest()==tm['original_metrics_sha256'])
    check(study, 'Primary engine bytes', sha(b/'code/StudyC_fast_resume.py')==run['execution_engine_sha256']==ex['engine_sha256'])
    check(study, 'Protocol linkage', tm['original_protocol_signature']==run['protocol_signature']==ex['original_protocol_signature'])
    check(study, 'Parent source snapshot linkage', run['source_snapshot_sha256']==ex['original_source_snapshot_sha256'])
    check(study, 'Primary prediction index linkage', sha(b/'identifiers/prediction_record_index.csv')==run['prediction_index_sha256'])
    check(study, 'Primary and empirical tuning budget', run['config']['search_iterations']==tm['config']['n_candidates']==20 and run['config']['cv_folds']==tm['config']['inner_folds']==5)
    check(study, 'Seeds and refit count', run['config']['base_seed']==2026 and run['config']['runs']==40 and run['config']['tuning_seed']==tm['config']['tuning_seed']==1729)
    check(study, 'Retained empirical numerical settings', tm['config']['diagonal_jitter']==1e-10 and tm['config']['max_variogram_evaluations']==1000)
    counts = {r['source']: (int(r['rows']),int(r['boreholes'])) for r in rows(b/'identifiers/input_counts.csv')}
    check(study, 'Primary counts match supplied identifiers', counts['train']==(run['n_training_records'],run['n_training_boreholes']) and counts['test']==(run['n_test_records'],run['n_test_boreholes']))
    check(study, 'Recorded primary-to-comparator chronology', run['completed_time_utc'] < tm['started_time_utc'] < tm['selection_locked_time_utc'] < tm['completed_time_utc'], 'Recorded timestamps only; earlier test-inspection history is not established.')
    selected = {r['task']:r for r in rows(b/'results/selected_OK_RK_settings.csv')}
    budgets = {r['task']:r for r in rows(b/'results/comparator_tuning_budget.csv')}
    locked = read(p/'locked_comparator_settings.json')
    check(study, 'Nineteen locked selections and budgets', set(locked)==set(selected)==set(budgets) and len(locked)==19)
    for task, record in locked.items():
        s, budget = selected[task], budgets[task]
        check(study, task+' locked parameters', all(equal(v,s[k]) for k,v in record['parameters'].items()) and equal(record['mean_cv_rmse'],s['mean_cv_rmse']))
        check(study, task+' fold-score file identity', sha(b/f'selection/kriging/{task}_fold_scores.csv')==record['fold_scores_sha256'])
        check(study, task+' budget and timing', all(equal(record[k],budget[k]) for k in ['n_candidates','n_folds','n_valid_candidates','candidate_fold_evaluations','cv_wall_seconds','trend_fit_calls','variogram_fit_calls']))
        check(study, task+' tuning signature', record['tuning_signature']==tm['tuning_signature'])
    if study=='B':
        compat = read(p/'source_compatibility.json')
        check(study, 'Empirical source bytes', sha(b/'code/StudyB_OK_RK_tuning_Table7_compatible.py')==tm['source_sha256'])
        check(study, 'Compatibility records agree', compat==tm['source_compatibility'])
        check(study, 'Recorded B mapping and source identity', compat['comparison_study']=='B' and compat['source_study']=='C' and compat['source_manifest_sha256']==sha(p/'run_manifest.json'))
        c = compat['observed_counts']
        check(study, 'Compatibility populations', counts['train']==(c['train_records'],c['train_boreholes']) and counts['test']==(c['test_records'],c['test_boreholes']))
    else:
        check(study, 'Embedded empirical source bytes', sha(b/'code/StudyC_empirical_source_as_hashed.py')==tm['source_sha256'])

summary = {'checks':{s:sum(r['status']==s for r in checks) for s in ['PASS','FAIL']}, 'models_fitted':False,
 'scope':'Internal consistency of supplied original manifests, source bytes, identifiers, selection records and timing budgets.',
 'qualifications':[
 'Raw inputs, full primary learner predictions and fitted learner models are unavailable; recorded raw-input hash claims cannot be independently verified against their bytes.',
 'Primary run manifests retain historical heuristic comparator configuration. Separate empirical tuning manifests and canonical results define the retained B/C OK/RK comparisons.',
 'Study B retains inherited Study C labels in original records; its B configuration, split identifiers and 555/52 test population identify the study.',
 'Study C embedded source identity matches its recorded hash; the separately supplied notebook definitions differ in revision/default paths, so exact live-kernel source attribution remains qualified.',
 'Historical overall/table7 export hashes identify exports omitted during consolidation; retained canonical summaries are checked separately against supplied records.',
 'Recorded selection timestamps do not establish that earlier test inspection never informed methodological choices.' ]}
if a.out:
    a.out.mkdir(parents=True, exist_ok=True)
    with (a.out/'manifest_consistency_checks.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['study','check','status','detail']);w.writeheader();w.writerows(checks)
    (a.out/'manifest_consistency_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
for r in checks:
    if r['status']=='FAIL': print(r)
raise SystemExit(bool(summary['checks']['FAIL']))
