"""Check supplementary numerical records without fitting models.
Usage: python verification/verify_analysis.py [--root PATH] [--out PATH]
Requires numpy, pandas and scipy. Original raw inputs and model binaries are not supplied.
"""
from pathlib import Path
import argparse,ast,csv,gzip,hashlib,json,re,sys
import numpy as np
import pandas as pd
from scipy.stats import rankdata,wilcoxon
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);ap.add_argument('--out',type=Path);args=ap.parse_args();R=args.root.resolve();checks=[];sys.path.insert(0,str(R/'verification'))
from read_retained_metrics import load_metrics
def read(p):return pd.read_csv(p,float_precision='round_trip')
def check(study,name,condition,detail=''):checks.append(dict(study=study,check=name,status='PASS' if bool(condition) else 'FAIL',detail=str(detail)))
def close(x,y):return np.allclose(x,y,rtol=1e-9,atol=1e-10,equal_nan=True)
def sh(p):return hashlib.sha256(p.read_bytes()).hexdigest()
summary={};rankrows=[]
keys=['analysis','missing_type','configuration','target','model','split'];metricnames=['rmse','rmse_percent','l2','robust_l2','robust_l2_standardized','mae','bias','r2','calibration_slope_observed_on_predicted','calibration_intercept_observed_on_predicted']
for i,k in enumerate('ABC',1):
 d=R/f'S{i}_Study{k}';m=load_metrics(R,k);s=read(d/'results/summary_mean_sd.csv');summary[k]=s
 check(k,'Unique retained run keys',not m.duplicated(keys+['seed']).any(),len(m));check(k,'Forty fixed refit seeds',set(m.seed)==set(range(2026,2066)) and (m.groupby(keys).seed.nunique()==40).all())
 for c in metricnames:
  a=m.groupby(keys)[c].agg(mean=lambda x:np.mean(x.to_numpy()),sd=lambda x:np.std(x.to_numpy(),ddof=1)).reset_index();j=a.merge(s[keys+[c+'_mean',c+'_sd']],on=keys,validate='one_to_one');check(k,'Summary mean/SD '+c,close(j['mean'],j[c+'_mean']) and np.all(np.isclose(j.sd,j[c+'_sd'],rtol=1e-9,atol=np.maximum(1e-10,64*np.finfo(float).eps*np.maximum(abs(j['mean']),1)),equal_nan=True)),len(j))
 split=read(d/'identifiers/split_identifiers.csv');dev=split[split.source_split!='test'];test=split[split.source_split=='test'];fold=read(d/'identifiers/cv_fold_identifiers.csv')
 counts={'A':(2754,236,20,8),'B':(2219,184,555,52),'C':(2668,228,106,8)}[k]
 check(k,'Development and test populations',(len(dev),dev.borehole_id.nunique(),len(test),test.borehole_id.nunique())==counts,counts)
 check(k,'Distinct development/test records',not(set(dev.global_id)&set(test.global_id)))
 check(k,'Borehole allocation',set(test.borehole_id).issubset(set(dev.borehole_id)) if k=='A' else not(set(test.borehole_id)&set(dev.borehole_id)))
 check(k,'Grouped fold coverage',set(fold.global_id)==set(dev.global_id) and not fold.global_id.duplicated().any() and (fold.groupby('borehole_id').fold.nunique()==1).all())
 sel=read(d/'results/selected_learner_settings.csv');check(k,'276 learner selections',len(sel)==276)
 for r in sel.itertuples():
  name=f'{r.analysis}_{r.missing_type}_{r.configuration}_{r.target}_{r.model}_cv_results.csv';cv=read(d/'selection/learner'/name);pars=ast.literal_eval(r.parameters)
  candidates=[{a.removeprefix('regressor__model__'):b for a,b in ast.literal_eval(v).items()} for v in cv.params]
  hits=[n for n,p in enumerate(candidates) if p==pars];ok=len(cv)==20 and len(hits)>0 and np.isclose(r.best_cv_neg_rmse,cv.mean_test_score.max()) and any(np.isclose(cv.iloc[n].mean_test_score,r.best_cv_neg_rmse) for n in hits)
  check(k,'Selected learner CV '+name,ok and close(cv[[f'split{j}_test_score' for j in range(5)]].mean(axis=1),cv.mean_test_score))
 gs=read(d/'results/selected_OK_RK_settings.csv');check(k,'Nineteen empirical selections',len(gs)==19)
 for r in gs.itertuples():
  task=r.task
  if k=='A':
   cv=read(d/f'selection/kriging/{task}_cv_results.csv');valid=cv[cv.valid_all_folds.astype(str).str.lower()=='true'];best=valid.mean_rmse.min();folds=[f'fold{j}_rmse' for j in range(5)];ok=len(cv)==20 and close(cv[folds].mean(axis=1),cv.mean_rmse)
  else:
   cv=read(d/f'selection/kriging/{task}_candidate_summary.csv');fs=read(d/f'selection/kriging/{task}_fold_scores.csv');valid=cv[cv.valid.astype(str).str.lower()=='true'];best=valid.mean_cv_rmse.min();ok=len(cv)==20 and len(fs)==100 and close(fs.groupby('candidate_id').rmse.mean().sort_index(),cv.set_index('candidate_id').mean_cv_rmse.sort_index())
  check(k,'Selected comparator CV '+task,ok and np.isclose(r.mean_cv_rmse,best))
  selected=cv[cv.candidate_id==r.candidate_id].iloc[0];check(k,'Comparator candidate parameters '+task,all(str(selected[c])==str(getattr(r,c)) for c in ['family','nugget_mode','neighbors','n_lags']) and (pd.isna(r.ridge_alpha) or np.isclose(selected.ridge_alpha,r.ridge_alpha)))
 vg=read(d/'results/fitted_variogram_parameters.csv');check(k,'760 final variograms',len(vg)==760 and close(vg.nugget+vg.partial_sill,vg.sill))
 for r in vg.itertuples():
  match=gs[(gs.method==r.method)&(gs.target==r.target)]
  if r.method=='RK':match=match[match.missing_type==r.missing_type]
  a=match.iloc[0];check(k,'Fitted variogram selection '+str((r.method,r.missing_type,r.target,r.seed)),r.family==a.family and r.nugget_mode==a.nugget_mode and int(r.neighbors)==int(a.neighbors) and (r.method=='OK' or np.isclose(r.ridge_alpha,a.ridge_alpha)))
 if k!='A':
  scales=read(d/'results/training_target_scales_reconstructed_from_metrics.csv').set_index('target').training_target_sd_population;stored=read(d/'results/empirical_comparator_metrics_recomputed.csv');print_index=['missing_type','target','seed','model'];stored=stored.set_index(print_index);nrows=0;negative=[]
  for f in sorted((d/'predictions/kriging').glob('*.csv')):
   p=read(f);mt='All' if f.name.startswith('OK_') else re.search(r'MT[1-4]',f.name).group();method=str(p.method.iloc[0]).replace('_tuned','');t=p.target.iloc[0];seed=int(p.seed.iloc[0]);y=p.actual.to_numpy();yp=p.prediction.to_numpy();res=y-yp;sd=scales[t];z=res/sd;hub=np.where(abs(z)<=1,.5*z*z,abs(z)-.5).mean();slope=np.sum((yp-yp.mean())*(y-y.mean()))/np.sum((yp-yp.mean())**2);intercept=y.mean()-slope*yp.mean();r=stored.loc[(mt,t,seed,method)]
   check(k,'Comparator prediction summary '+f.stem,close([np.sqrt(np.mean(res**2)),slope,intercept,hub],[r.rmse,r.calibration_slope_observed_on_predicted,r.calibration_intercept_observed_on_predicted,r.robust_l2_standardized]) and set(p.global_id)==set(test.global_id) and set(p.borehole_id)==set(test.borehole_id));nrows+=len(p)
   if k=='C':
    md=json.loads(f.with_suffix('.json').read_text());check(k,'Prediction byte hash '+f.stem,sh(f)==md['prediction_sha256'])
    if method=='RK' and t=='E50' and mt in ['MT1','MT4']:negative.extend(yp[yp<0])
  check(k,'Empirical prediction population',nrows==760*counts[2],nrows)
  if k=='C':check(k,'Retained negative E50 example',len(negative)==83 and round(float(min(negative)),3)==-1045.215,{'count':len(negative),'minimum':min(negative)})
 if k=='A':
  for f in (d/'diagnostics/variogram').glob('*.json'):
   j=json.loads(f.read_text());v=j['variogram'];check(k,'Diagnostic sill and normalization '+f.stem,close(v['nugget']+v['partial_sill'],v['sill']) and close([v['nugget_normalized']*v['variance'],v['partial_sill_normalized']*v['variance']],[v['nugget'],v['partial_sill']]) and all(x>0 for x in j['coordinate_scale']))
 # Primary forty-seed paired fitting-stability calculation.
 p=m[(m.analysis=='primary')&(m.model=='Ensemble')&(m.split=='Test')];stats=[]
 for (mt,t),g in p.groupby(['missing_type','target']):
  q=g.pivot(index='seed',columns='configuration',values='rmse')
  for conf in ['XY','Z','XYZ']:
   diff=q[conf]-q.NoSpatial;stats.append(dict(missing_type=mt,target=t,configuration=conf,p=wilcoxon(diff,alternative='two-sided').pvalue,mean=diff.mean()))
 stats=pd.DataFrame(stats);order=np.argsort(stats.p.to_numpy());adj=np.empty(len(stats));adj[order]=np.minimum(1,np.maximum.accumulate(stats.p.to_numpy()[order]*(len(stats)-np.arange(len(stats)))));n=int((adj<.05).sum());check(k,'Primary fitting stability count',n=={'A':40,'B':42,'C':40}[k],n)
 xyz=s[(s.analysis=='primary')&(s.configuration=='XYZ')&(s.split=='Test')&(s.model.isin(['RF','GBR','XGB','Ensemble']))]
 for (mt,t),g in xyz.groupby(['missing_type','target']):
  for r,rank in zip(g.itertuples(),rankdata(g.rmse_mean,method='average')):rankrows.append(dict(study=k,missing_type=mt,target=t,method=r.model,mean_rmse=r.rmse_mean,rank=rank))
 # Verify original source hashes against corresponding provided engines.
 if k in ['A','B']:
  ex=json.loads((d/'provenance/original/execution_manifest.json').read_text());code=d/'code'/('StudyA_retuned_fast_resume.py' if k=='A' else 'StudyC_fast_resume.py');check(k,'Primary engine hash',sh(code)==ex['engine_sha256'])
 else:
  tm=json.loads((d/'provenance/original/tuning_manifest.json').read_text());check(k,'Empirical hashed source identity',sh(d/'code/StudyC_empirical_source_as_hashed.py')==tm['source_sha256']);check(k,'Retained C endpoint counts',sum((gs.method=='RK')&(gs.neighbors==256))==10 and sum((gs.method=='RK')&(gs.ridge_alpha==1000))==1 and sum(gs.n_lags==20)==10 and sum(gs.n_lags==12)==9)

cross=read(R/'Cross_study/SHAP_additivity_and_sampling.csv');check('ABC','Thirty-four presented SHAP cases',len(cross)==34 and cross.groupby('study').size().to_dict()=={'A':14,'B':10,'C':10})
for row in cross.itertuples():
 bg=read(R/row.background_id_file);ev=read(R/row.evaluation_id_file);ad=read(R/row.additivity_file);v=np.load(R/row.values_file,allow_pickle=False);rec=v['base_values']+v['values'].sum(axis=1);md=json.loads((R/row.provenance_file).read_text());n=row.n_evaluation;check(row.study,'SHAP case '+str((row.missing_type,row.target)),len(bg)==50 and bg.global_id.nunique()==50 and len(ev)==n and ev.borehole_id.nunique()==row.n_evaluation_boreholes and np.array_equal(v['global_ids'],ev.global_id.to_numpy()) and np.allclose(rec,ad.prediction,rtol=1e-12,atol=1e-10) and row.max_evals==10*(2*v['values'].shape[1]+1) and abs(abs(ad.additivity_residual).mean()-row.mean_absolute_error)<1e-15 and abs(abs(ad.additivity_residual).max()-row.maximum_absolute_error)<1e-15 and sh(R/row.figure_file)==md['figure_sha256'])
ranked=pd.DataFrame(rankrows);ranked['target']=ranked.target.replace('su','Su');given=read(R/'Cross_study/ensemble_rank_calculation.csv');given['target']=given.target.replace('su','Su');joined=ranked.merge(given,on=['study','missing_type','target','method'],suffixes=('_calc','_supplied'),validate='one_to_one');check('ABC','Unrounded ranks',len(joined)==168 and close(joined.mean_rmse_calc,joined.mean_rmse_supplied) and close(joined['rank_calc'],joined['rank_supplied']))
counts={'PASS':sum(x['status']=='PASS' for x in checks),'FAIL':sum(x['status']=='FAIL' for x in checks)}
result={'checks':counts,'models_fitted':False,'summary_sd_tolerance':'rtol=1e-9; atol=max(1e-10,64*machine_epsilon*abs(group_mean)), allowing serialization roundoff for nearly constant large MSE groups','scope':'Supplied records and numerical consistency; original raw inputs and complete learner predictions unavailable'}
if args.out:
 args.out.mkdir(parents=True,exist_ok=True);pd.DataFrame(checks).to_csv(args.out/'analysis_checks.csv',index=False);(args.out/'analysis_summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
for row in checks:
 if row['status']=='FAIL':print('FAIL',row)
raise SystemExit(bool(counts['FAIL']))
