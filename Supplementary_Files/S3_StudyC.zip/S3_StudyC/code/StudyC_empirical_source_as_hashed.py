"""Tune OK/RK and compare them with saved Study C results, without refitting learners.

Command line:
    python StudyC_OK_RK_tuning.py --study-c-output StudyC_reconciled

Existing notebook kernel (isolated module; preserve the original function names):
    from StudyC_OK_RK_tuning import TuningConfig, run_ok_rk_tuning
    ok_rk_context = run_ok_rk_tuning(TuningConfig(study_c_output_dir=str(validation_context['out'])))

Only Ridge trend and kriging models are fitted. RF/GBR/XGB/SHAP are not imported.
Original output files and the original manifest are never changed.
Study C uses only its two saved input datasets; every task uses all test rows.
The new Table 7-style view replaces the original OK/RK columns with tuned values.
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import sys
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import least_squares
from scipy.spatial import cKDTree
from sklearn.base import clone
from sklearn.linear_model import Ridge
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from threadpoolctl import threadpool_limits


REVISION = 'study-c-complementary-ok-rk-tuning-2026-11-02-v1'
COORDINATES = ['x', 'y', 'z_depth']
CORE_FEATURES = ['Sr', 'gamma_t', 'e', 'LL', 'PL', 'w', 'PI', 'LI',
                 'e_squared', 'w_by_LL', 'Sr_log', 'moisture_void_ratio']
TARGETS = ['Cc', 'Cv', 'Pc', 'E50', 'su']
PATTERNS = {
    'MT1': dict(known=[], targets=['Cc', 'Cv', 'Pc', 'E50', 'su'], degree=1),
    'MT2': dict(known=['su'], targets=['Cc', 'Cv', 'Pc', 'E50'], degree=2),
    'MT3': dict(known=['su', 'E50'], targets=['Cc', 'Cv', 'Pc'], degree=2),
    'MT4': dict(known=['Pc', 'Cc', 'Cv'], targets=['E50', 'su'], degree=2),
}


@dataclass
class TuningConfig:
    study_c_output_dir: str = 'StudyC_reconciled'
    output_dir: str | None = None  # defaults to a separate child directory
    input_overrides: dict | None = None  # moved files must retain original hashes
    n_candidates: int = 20  # equal complete-pipeline candidate budgets for OK and RK
    tuning_seed: int = 1729
    families: tuple = ('spherical', 'exponential', 'gaussian')
    nugget_modes: tuple = ('zero', 'fit')
    neighbor_counts: tuple = (8, 16, 32, 64, 128)
    lag_counts: tuple = (12, 20)
    ridge_alphas: tuple = (0.01, 0.1, 1.0, 10.0, 100.0)
    inner_folds: int = 5
    pair_sample: int = 50_000
    max_lag_quantile: float = 0.90
    max_variogram_evaluations: int = 1000
    batch_size: int = 32
    diagonal_jitter: float = 1e-10  # in variance-normalized semivariance units
    linear_algebra_threads: int = 1
    missing_types: tuple = ('MT1', 'MT2', 'MT3', 'MT4')
    targets: tuple = ('Cc', 'Cv', 'Pc', 'E50', 'su')
    final_seeds: tuple | None = None  # default: all seeds from the original run
    require_full_source: bool = True
    verify_all_prediction_hashes: bool = False
    resume: bool = True


def sha256_file(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def _json(value):
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    raise TypeError(type(value).__name__)


def save_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.tmp')
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True, default=_json), encoding='utf-8')
    tmp.replace(path)


def save_csv(path, frame):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.tmp')
    frame.to_csv(tmp, index=False, float_format='%.17g')
    tmp.replace(path)


def read_input(path):
    path = Path(path)
    frame = pd.read_excel(path) if path.suffix.lower() in {'.xlsx', '.xls'} else pd.read_csv(path)
    frame = frame.loc[:, ~frame.columns.astype(str).str.startswith('Unnamed:')].copy()
    required = ['global_id', 'borehole_id', 'Sr', 'gamma_t', 'e', 'LL', 'PL', 'w'] + TARGETS + COORDINATES
    missing = set(required) - set(frame)
    if missing:
        raise ValueError(f'{path.name}: missing columns {sorted(missing)}')
    for name in required:
        frame[name] = pd.to_numeric(frame[name], errors='raise')
    if not np.isfinite(frame[required].to_numpy(float)).all():
        raise ValueError(f'{path.name}: nonfinite required values')
    for name in ['global_id', 'borehole_id']:
        if not np.equal(frame[name], np.floor(frame[name])).all():
            raise ValueError(f'{path.name}: {name} must be integer')
        frame[name] = frame[name].astype('int64')
    if frame.global_id.duplicated().any():
        raise ValueError(f'{path.name}: duplicated global_id')
    frame['PI'] = frame.LL - frame.PL
    frame['LI'] = (frame.w - frame.PL) / (frame.PI + 1e-5)
    frame['e_squared'] = frame.e ** 2
    frame['w_by_LL'] = frame.w / (frame.LL + 1e-5)
    if (frame.Sr + 1e-5 <= 0).any():
        raise ValueError('Sr outside the log-transform domain')
    frame['Sr_log'] = np.log(frame.Sr + 1e-5)
    frame['moisture_void_ratio'] = frame.w * frame.e
    if not np.isfinite(frame[CORE_FEATURES].to_numpy(float)).all():
        raise ValueError('Nonfinite engineered features')
    return frame


def _read_original_part(root, name, signature, expected_sha=None):
    path = root / 'prediction_record' / name
    receipt = path.with_name(path.name + '.sha256.json')
    if not path.is_file() or not receipt.is_file():
        raise FileNotFoundError(f'Original prediction or receipt missing: {path}')
    meta = json.loads(receipt.read_text())
    digest = sha256_file(path)
    if meta['protocol_signature'] != signature or digest != meta['sha256']:
        raise ValueError(f'Original prediction integrity check failed: {name}')
    if expected_sha is not None and digest != expected_sha:
        raise ValueError(f'Original prediction index mismatch: {name}')
    frame = pd.read_csv(path)
    if len(frame) != meta['rows'] or set(frame.protocol_signature) != {signature}:
        raise ValueError(f'Original prediction lineage mismatch: {name}')
    return frame


def load_existing_study(cfg):
    root = Path(cfg.study_c_output_dir).expanduser().resolve()
    manifest_path = root / 'run_manifest.json'
    if not manifest_path.is_file():
        raise FileNotFoundError(f'Set study_c_output_dir to the existing Study C output folder: {manifest_path}')
    original = json.loads(manifest_path.read_text())
    if original.get('study') != 'C':
        raise ValueError('This companion requires Study C output, not another study')
    if cfg.require_full_source and original.get('output_class') != 'FULL_STUDY_C_40_SEED':
        raise ValueError('Source is not a full Study C run; use require_full_source=False only for diagnostics')
    original_config = original['config']
    seed_set = tuple(range(original_config['base_seed'], original_config['base_seed'] + original_config['runs']))
    seeds = seed_set if cfg.final_seeds is None else tuple(cfg.final_seeds)
    if not seeds or len(set(seeds)) != len(seeds) or not set(seeds) <= set(seed_set):
        raise ValueError('final_seeds must be a unique subset of the original fitting seeds')
    if set(original['input_paths']) != {'train', 'test'} or set(original['input_sha256']) != {'train', 'test'}:
        raise ValueError('Study C must contain exactly the training and test datasets, without a verification dataset')
    if set(cfg.input_overrides or {}) - {'train', 'test'}:
        raise ValueError('input_overrides accepts train and test only')
    inputs = {}
    for role in ['train', 'test']:
        supplied = (cfg.input_overrides or {}).get(role, original['input_paths'][role])
        path = Path(supplied).expanduser()
        if not path.is_file() or sha256_file(path) != original['input_sha256'][role]:
            raise ValueError(f'Original {role} file is missing or changed. Set input_overrides to an identical copy: {path}')
        inputs[role] = read_input(path)
    split_ids = pd.read_csv(root / 'split_identifiers.csv')
    if split_ids.global_id.duplicated().any() or set(split_ids.source_split) != {'train', 'test'}:
        raise ValueError('Original Study C split identifiers are invalid')
    for role in ['train', 'test']:
        selected = split_ids.loc[split_ids.source_split == role]
        if set(selected.global_id) != set(inputs[role].global_id):
            raise ValueError(f'Saved {role} IDs differ from the complete original dataset')
        ordered = inputs[role].set_index('global_id').loc[selected.global_id]
        np.testing.assert_array_equal(ordered.borehole_id, selected.borehole_id)
    dev_ids = split_ids.loc[split_ids.source_split == 'train', 'global_id'].tolist()
    test_ids = split_ids.loc[split_ids.source_split == 'test', 'global_id'].tolist()
    dev = inputs['train'].set_index('global_id', drop=False).loc[dev_ids].reset_index(drop=True)
    test = inputs['test'].set_index('global_id', drop=False).loc[test_ids].reset_index(drop=True)
    if set(dev.global_id) & set(test.global_id):
        raise ValueError('Study C training and test record IDs overlap')
    if set(dev.borehole_id) & set(test.borehole_id):
        raise ValueError('Study C training and test boreholes overlap')
    if cfg.require_full_source and (len(test) != 106 or test.borehole_id.nunique() != 8):
        raise ValueError('The full Study C comparison requires all 106 records from eight held-out boreholes')
    fold_ids = pd.read_csv(root / 'cv_fold_identifiers.csv')
    if fold_ids.global_id.duplicated().any() or set(fold_ids.global_id) != set(dev.global_id):
        raise ValueError('Study C CV assignments must cover all training records exactly once')
    if 'source_split' in fold_ids and set(fold_ids.source_split) != {'train'}:
        raise ValueError('Test or auxiliary records appear in the saved training-only CV')
    cv_data = dev.copy()
    assignment = fold_ids.set_index('global_id').loc[cv_data.global_id, 'fold'].to_numpy(int)
    np.testing.assert_array_equal(fold_ids.set_index('global_id').loc[cv_data.global_id, 'borehole_id'], cv_data.borehole_id)
    folds = []
    for fold in sorted(np.unique(assignment)):
        tr, va = np.flatnonzero(assignment != fold), np.flatnonzero(assignment == fold)
        if not len(tr) or not len(va) or set(cv_data.iloc[tr].borehole_id) & set(cv_data.iloc[va].borehole_id):
            raise ValueError('Saved original folds are not borehole-disjoint')
        if cv_data.iloc[tr].borehole_id.nunique() < cfg.inner_folds:
            raise ValueError('Not enough training boreholes for RK inner grouped folds')
        folds.append((tr, va))
    if len(folds) != original_config['cv_folds'] or len(folds) < 2:
        raise ValueError('Saved CV fold count differs from the original Study C configuration')
    index_path = root / 'prediction_record_index.csv'
    index = pd.read_csv(index_path)
    if index.file.duplicated().any() or set(index.protocol_signature) != {original['protocol_signature']}:
        raise ValueError('Invalid original prediction index')
    if original.get('prediction_index_sha256') and sha256_file(index_path) != original['prediction_index_sha256']:
        raise ValueError('Original prediction index hash changed')
    if cfg.verify_all_prediction_hashes:
        for record in index.itertuples(index=False):
            _read_original_part(root, record.file, original['protocol_signature'], record.sha256)
    counts = pd.read_csv(root / 'effective_test_counts.csv')
    feature_manifest = pd.read_csv(root / 'feature_manifest.csv')
    representative = original_config['representative_seed']
    tasks = []
    for row in counts.itertuples(index=False):
        mt, target = row.missing_type, row.target
        if mt not in cfg.missing_types or target not in cfg.targets:
            continue
        if mt not in PATTERNS or target not in PATTERNS[mt]['targets']:
            raise ValueError(f'Invalid Study C task: {mt}/{target}')
        if (mt, target) in {(t['missing_type'], t['target']) for t in tasks}:
            raise ValueError(f'Duplicate task in effective_test_counts.csv: {mt}/{target}')
        candidates = index.loc[index.file.str.startswith(f'primary_{mt}_XYZ_{target}_learners_seed{representative}.')]
        if len(candidates) != 1:
            raise ValueError(f'Need one original representative XYZ record for {mt}/{target}')
        record = candidates.iloc[0]
        part = _read_original_part(root, record.file, original['protocol_signature'], record.sha256)
        ev = part.loc[part.split == 'Test'].copy()
        if ev.global_id.duplicated().any() or len(ev) != len(test) or set(ev.global_id) != set(test.global_id):
            raise ValueError(f'{mt}/{target} must use the complete Study C test dataset; row mapping is not allowed')
        evaluation = test.set_index('global_id', drop=False).loc[ev.global_id].reset_index(drop=True)
        np.testing.assert_allclose(evaluation[target], ev.actual, rtol=1e-12, atol=1e-12)
        np.testing.assert_array_equal(evaluation.borehole_id, ev.borehole_id)
        if len(ev) != row.n_test_records or ev.borehole_id.nunique() != row.n_test_boreholes:
            raise ValueError(f'Original evaluation counts disagree for {mt}/{target}')
        feature_row = feature_manifest.loc[(feature_manifest.missing_type == mt) &
                                          (feature_manifest.target == target) &
                                          (feature_manifest.configuration == 'XYZ')]
        if len(feature_row) != 1:
            raise ValueError(f'Need one original XYZ feature definition for {mt}/{target}')
        raw_features = json.loads(feature_row.features.iloc[0])
        trend_features = [name for name in raw_features if name not in COORDINATES]
        if target in trend_features or not trend_features or not set(trend_features) <= set(dev.columns):
            raise ValueError('Invalid original nonspatial RK trend features')
        tasks.append(dict(missing_type=mt, target=target, degree=int(feature_row.polynomial_degree.iloc[0]),
                          features=trend_features, test_ids=ev.global_id.astype(int).tolist()))
    if not tasks:
        raise ValueError('No requested Study C tasks found')
    expected = {(mt, target) for mt in original_config['missing_types'] if mt in cfg.missing_types
                for target in PATTERNS[mt]['targets'] if target in original_config['targets'] and target in cfg.targets}
    if {(t['missing_type'], t['target']) for t in tasks} != expected:
        raise ValueError('Some requested Study C tasks are missing from the saved effective counts')
    metrics_path = root / 'run_metrics_from_predictions.csv'
    if not metrics_path.is_file():
        raise FileNotFoundError('run_metrics_from_predictions.csv is required; it was exported before SHAP in the original run')
    original_metrics = pd.read_csv(metrics_path)
    original_metrics = original_metrics.loc[(original_metrics.analysis == 'primary') &
                                            (original_metrics.split == 'Test') &
                                            original_metrics.seed.isin(seeds)].copy()
    metric_keys = ['missing_type', 'target', 'configuration', 'model', 'seed']
    if original_metrics.duplicated(metric_keys).any():
        raise ValueError('Duplicate original primary test metrics')
    learners = tuple(original_config['learners'])
    ensemble = 'Ensemble' if set(learners) == {'RF', 'GBR', 'XGB'} else 'DiagnosticMean_' + '_'.join(learners)
    for task in tasks:
        for conf in original_config['configurations']:
            for model in learners + (ensemble,):
                group = original_metrics.loc[(original_metrics.missing_type == task['missing_type']) &
                                             (original_metrics.target == task['target']) &
                                             (original_metrics.configuration == conf) & (original_metrics.model == model)]
                if set(group.seed) != set(seeds):
                    raise ValueError(f'Incomplete retained {model}/{conf} metrics for {task["missing_type"]}/{task["target"]}')
                if not (group.n_records == len(test)).all() or not (group.n_boreholes == test.borehole_id.nunique()).all():
                    raise ValueError('Retained metric sample sizes differ from the complete Study C test population')
                if not np.isfinite(group.rmse).all():
                    raise ValueError('Nonfinite retained RMSE')
    artifacts = ['run_manifest.json', 'split_identifiers.csv', 'effective_test_counts.csv', 'feature_manifest.csv']
    return dict(root=root, original=original, dev=dev, test=test, cv_data=cv_data,
                folds=folds, tasks=tasks, seeds=seeds, all_seeds=seed_set,
                original_metrics=original_metrics, ensemble=ensemble, learners=learners,
                index_sha256=sha256_file(index_path), metrics_sha256=sha256_file(metrics_path),
                folds_sha256=sha256_file(root / 'cv_fold_identifiers.csv'),
                source_artifact_sha256={name: sha256_file(root / name) for name in artifacts})


def candidate_configurations(cfg, method):
    alpha_values = (None,) if method == 'OK' else cfg.ridge_alphas
    combinations = [dict(family=family, nugget_mode=mode, neighbors=int(k), n_lags=int(lags),
                         ridge_alpha=alpha)
                    for family, mode, k, lags, alpha in itertools.product(
                        cfg.families, cfg.nugget_modes, cfg.neighbor_counts, cfg.lag_counts, alpha_values)]
    if cfg.n_candidates > len(combinations):
        raise ValueError(f'{method} has {len(combinations)} distinct candidates; reduce n_candidates or expand the grid')
    rng = np.random.default_rng(cfg.tuning_seed + (0 if method == 'OK' else 1))
    # Ensure every declared family is represented when the budget permits.
    selected = []
    if cfg.n_candidates >= len(cfg.families):
        for family in cfg.families:
            eligible = [i for i, p in enumerate(combinations) if p['family'] == family]
            selected.append(int(rng.choice(eligible)))
    remaining = [i for i in range(len(combinations)) if i not in selected]
    selected += rng.choice(remaining, cfg.n_candidates - len(selected), replace=False).astype(int).tolist()
    return [dict(candidate_id=i, **combinations[j]) for i, j in enumerate(selected)]


def variogram_shape(distance, family, range_parameter):
    ratio = np.asarray(distance, float) / range_parameter
    if family == 'spherical':
        return np.where(ratio <= 1, 1.5 * ratio - 0.5 * ratio ** 3, 1.0)
    if family == 'exponential':
        return -np.expm1(-3.0 * ratio)
    if family == 'gaussian':
        return -np.expm1(-3.0 * ratio ** 2)
    raise ValueError(family)


def empirical_variogram(coords, values, n_lags, cfg, seed):
    values = np.asarray(values, float)
    variance = float(np.var(values, ddof=1))
    if not np.isfinite(variance) or variance <= np.finfo(float).eps:
        raise ValueError('Cannot estimate a variogram for a constant target/residual')
    rng = np.random.default_rng(seed)
    n = len(values)
    pairs = min(cfg.pair_sample, n * (n - 1) // 2)
    a, b = rng.integers(0, n, size=(2, pairs))
    h = np.linalg.norm(coords[a] - coords[b], axis=1)
    gamma = 0.5 * (values[a] - values[b]) ** 2 / variance
    valid = (a != b) & (h > 1e-12) & np.isfinite(gamma)
    h, gamma = h[valid], gamma[valid]
    if len(h) < 20:
        raise ValueError('Too few nonzero-distance pairs for an empirical variogram')
    max_lag = float(np.quantile(h, cfg.max_lag_quantile))
    use = h <= max_lag
    h, gamma = h[use], gamma[use]
    indices = np.minimum((h / max_lag * n_lags).astype(int), n_lags - 1)
    count = np.bincount(indices, minlength=n_lags)
    count_safe = np.maximum(count, 1)
    mean_h = np.bincount(indices, weights=h, minlength=n_lags) / count_safe
    mean_gamma = np.bincount(indices, weights=gamma, minlength=n_lags) / count_safe
    keep = count >= 5
    if keep.sum() < 4:
        raise ValueError('Fewer than four adequately populated empirical lag bins')
    return dict(h=mean_h[keep], gamma=mean_gamma[keep], count=count[keep],
                variance=variance, max_lag=max_lag, n_pairs=int(len(h)))


def fit_variogram(empirical, parameters, cfg):
    h, gamma = empirical['h'], empirical['gamma']
    weights = np.sqrt(empirical['count'] / np.mean(empirical['count']))
    max_lag = empirical['max_lag']
    lower = [1e-8, 0.01 * max_lag]
    upper = [5.0, 10.0 * max_lag]
    initial = [0.95, max_lag * 0.5]
    if parameters['nugget_mode'] == 'fit':
        lower.append(0.0); upper.append(2.0); initial.append(0.05)
    elif parameters['nugget_mode'] != 'zero':
        raise ValueError('nugget_mode must be zero or fit')

    def residual(theta):
        partial, range_parameter = theta[:2]
        nugget = theta[2] if len(theta) == 3 else 0.0
        fitted = nugget + partial * variogram_shape(h, parameters['family'], range_parameter)
        return weights * (fitted - gamma)

    result = least_squares(residual, initial, bounds=(lower, upper), loss='soft_l1',
                           max_nfev=cfg.max_variogram_evaluations)
    if not result.success or not np.isfinite(result.x).all():
        raise RuntimeError(f'Variogram fit failed: {result.message}')
    partial, range_parameter = result.x[:2]
    nugget = result.x[2] if len(result.x) == 3 else 0.0
    variance = empirical['variance']
    return dict(
        family=parameters['family'], nugget_mode=parameters['nugget_mode'],
        partial_sill=float(partial * variance), nugget=float(nugget * variance),
        sill=float((partial + nugget) * variance), range_parameter=float(range_parameter),
        partial_sill_normalized=float(partial), nugget_normalized=float(nugget), variance=variance,
        range_convention='Spherical reaches sill at range; exponential/Gaussian reach 1-exp(-3) of partial sill at range',
        weighted_bin_fit_rmse=float(np.sqrt(np.mean(result.fun ** 2))),
        variogram_optimizer_evaluations=int(result.nfev), empirical_pairs=empirical['n_pairs'],
        empirical_bins=len(h), max_lag=empirical['max_lag'],
    )


class SpatialGeometry:
    """Fold-local coordinate scaling and reusable nearest-neighbor distances."""
    def __init__(self, train, query, cfg):
        self.cfg = cfg
        self.scaler = StandardScaler().fit(np.asarray(train, float))
        self.train = self.scaler.transform(np.asarray(train, float))
        self.query = self.scaler.transform(np.asarray(query, float))
        self.kmax = min(max(cfg.neighbor_counts), len(self.train))
        if self.kmax < 2:
            raise ValueError('Kriging requires at least two training locations')
        distances, indices = cKDTree(self.train).query(self.query, k=self.kmax)
        self.distances = np.asarray(distances).reshape(len(self.query), self.kmax)
        self.indices = np.asarray(indices).reshape(len(self.query), self.kmax)
        self._pair_distances = None

    def pair_distances(self):
        if self._pair_distances is None:
            result = np.empty((len(self.query), self.kmax, self.kmax), dtype=float)
            for start in range(0, len(self.query), self.cfg.batch_size):
                stop = min(start + self.cfg.batch_size, len(self.query))
                coordinates = self.train[self.indices[start:stop]]
                result[start:stop] = np.linalg.norm(coordinates[:, :, None, :] - coordinates[:, None, :, :], axis=-1)
            self._pair_distances = result
        return self._pair_distances

    def predict(self, values, fitted, neighbors):
        k = min(int(neighbors), len(self.train))
        values = np.asarray(values, float)
        predictions = np.empty(len(self.query), dtype=float)
        distances = self.pair_distances()
        fallback_count = 0

        def gamma(h):
            result = fitted['nugget_normalized'] + fitted['partial_sill_normalized'] * variogram_shape(
                h, fitted['family'], fitted['range_parameter'])
            return np.where(h <= 1e-12, 0.0, result)

        for start in range(0, len(self.query), self.cfg.batch_size):
            stop = min(start + self.cfg.batch_size, len(self.query))
            idx = self.indices[start:stop, :k]
            query_distances = self.distances[start:stop, :k]
            exact = query_distances <= 1e-12
            has_exact = exact.any(axis=1)
            for row in np.flatnonzero(has_exact):
                predictions[start + row] = values[idx[row, exact[row]]].mean()
            active = np.flatnonzero(~has_exact)
            if not len(active):
                continue
            matrix = np.ones((len(active), k + 1, k + 1), dtype=float)
            matrix[:, :k, :k] = gamma(distances[start:stop, :k, :k][active])
            diagonal = np.arange(k)
            matrix[:, diagonal, diagonal] += self.cfg.diagonal_jitter
            matrix[:, k, k] = 0.0
            rhs = np.ones((len(active), k + 1), dtype=float)
            rhs[:, :k] = gamma(query_distances[active])
            try:
                solution = np.linalg.solve(matrix, rhs[..., None])[..., 0]
            except np.linalg.LinAlgError:
                solution = np.empty_like(rhs)
                for row in range(len(active)):
                    try:
                        solution[row] = np.linalg.solve(matrix[row], rhs[row])
                    except np.linalg.LinAlgError:
                        solution[row] = np.linalg.lstsq(matrix[row], rhs[row], rcond=None)[0]
                        fallback_count += 1
            predictions[start + active] = np.sum(solution[:, :k] * values[idx[active]], axis=1)
        if not np.isfinite(predictions).all():
            raise ValueError('Nonfinite kriging predictions')
        return predictions, fallback_count


def ridge_components(train, query, task, alpha, inner_folds, seed):
    """Build the trend and OOF residuals without accessing the outer validation labels."""
    features = task['features']
    trend = Pipeline([('poly', PolynomialFeatures(degree=task['degree'], include_bias=False)),
                      ('scale', StandardScaler()), ('ridge', Ridge(alpha=alpha))])
    splitter = GroupKFold(n_splits=inner_folds, shuffle=True, random_state=seed)
    residual_predictions = np.empty(len(train))
    for tr, va in splitter.split(train, groups=train.borehole_id):
        assert not set(train.iloc[tr].borehole_id) & set(train.iloc[va].borehole_id)
        model = clone(trend).fit(train.iloc[tr][features], train.iloc[tr][task['target']])
        residual_predictions[va] = model.predict(train.iloc[va][features])
    trend.fit(train[features], train[task['target']])
    return (train[task['target']].to_numpy(float) - residual_predictions,
            trend.predict(query[features]), inner_folds + 1)


def tune_one(ctx, method, task):
    cfg, out = ctx['cfg'], ctx['out']
    key = f'OK_{task["target"]}' if method == 'OK' else f'RK_{task["missing_type"]}_{task["target"]}'
    selected_path = out / 'selection' / f'{key}_selected.json'
    fold_path = out / 'selection' / f'{key}_fold_scores.csv'
    candidates = candidate_configurations(cfg, method)
    save_json(out / 'selection' / f'{key}_candidates.json', candidates)
    if selected_path.is_file() and cfg.resume:
        selected = json.loads(selected_path.read_text())
        if selected['tuning_signature'] != ctx['signature'] or sha256_file(fold_path) != selected['fold_scores_sha256']:
            raise ValueError(f'Cached selection changed: {key}')
        return selected
    rows = pd.read_csv(fold_path).to_dict('records') if fold_path.is_file() and cfg.resume else []
    completed = {(int(r['fold']), int(r['candidate_id'])) for r in rows}
    data = ctx['cv_data']
    for fold, (tr, va) in enumerate(ctx['folds']):
        if all((fold, p['candidate_id']) in completed for p in candidates):
            continue
        train, validation = data.iloc[tr].reset_index(drop=True), data.iloc[va].reset_index(drop=True)
        geometry = SpatialGeometry(train[COORDINATES], validation[COORDINATES], cfg)
        components, empirical_cache, fitted_cache = {}, {}, {}
        for parameters in candidates:
            if (fold, parameters['candidate_id']) in completed:
                continue
            started = time.perf_counter()
            alpha = parameters['ridge_alpha']
            trend_calls = 0
            record = dict(method=method, task=key, fold=fold, **parameters,
                          n_training_records=len(train), n_validation_records=len(validation),
                          n_validation_boreholes=validation.borehole_id.nunique())
            try:
                if method == 'OK':
                    values, base = train[task['target']].to_numpy(float), np.zeros(len(validation))
                else:
                    if alpha not in components:
                        components[alpha] = ridge_components(train, validation, task, alpha, cfg.inner_folds,
                                                             cfg.tuning_seed + 10000 + fold)
                        trend_calls = components[alpha][2]
                    values, base, _ = components[alpha]
                empirical_key = (alpha, parameters['n_lags'])
                if empirical_key not in empirical_cache:
                    empirical_cache[empirical_key] = empirical_variogram(
                        geometry.train, values, parameters['n_lags'], cfg, cfg.tuning_seed + fold)
                fitted_key = empirical_key + (parameters['family'], parameters['nugget_mode'])
                variogram_calls = int(fitted_key not in fitted_cache)
                if fitted_key not in fitted_cache:
                    fitted_cache[fitted_key] = fit_variogram(empirical_cache[empirical_key], parameters, cfg)
                fitted = fitted_cache[fitted_key]
                correction, fallback = geometry.predict(values, fitted, parameters['neighbors'])
                prediction = base + correction
                rmse = float(np.sqrt(np.mean((validation[task['target']].to_numpy(float) - prediction) ** 2)))
                record.update(status='OK', rmse=rmse, trend_fit_calls=trend_calls,
                              variogram_fit_calls=variogram_calls, least_squares_fallbacks=fallback,
                              **{name: fitted[name] for name in ['range_parameter', 'nugget', 'partial_sill', 'sill']})
            except Exception as exc:
                record.update(status='FAILED', rmse=None, trend_fit_calls=trend_calls,
                              error=f'{type(exc).__name__}: {exc}')
            record['elapsed_seconds'] = time.perf_counter() - started
            rows.append(record)
            save_csv(fold_path, pd.DataFrame(rows))
        print(f'Tuning {key}: completed grouped fold {fold + 1}/{len(ctx["folds"])}', flush=True)
    scores = pd.DataFrame(rows)
    summaries = []
    for parameters in candidates:
        group = scores.loc[scores.candidate_id == parameters['candidate_id']]
        valid = len(group) == len(ctx['folds']) and (group.status == 'OK').all() and np.isfinite(group.rmse).all()
        summaries.append(dict(**parameters, valid=bool(valid),
                              mean_cv_rmse=float(group.rmse.mean()) if valid else np.nan,
                              sd_cv_rmse=float(group.rmse.std(ddof=1)) if valid else np.nan))
    summary = pd.DataFrame(summaries)
    save_csv(out / 'selection' / f'{key}_candidate_summary.csv', summary)
    valid = summary.loc[summary.valid].sort_values(['mean_cv_rmse', 'candidate_id'])
    if valid.empty:
        raise RuntimeError(f'Every {key} candidate failed. Inspect {fold_path}')
    best = valid.iloc[0]
    parameters = candidates[int(best.candidate_id)]
    selected = dict(task=key, method=method, missing_type=task['missing_type'] if method == 'RK' else None,
                    target=task['target'], parameters=parameters, mean_cv_rmse=float(best.mean_cv_rmse),
                    tuning_signature=ctx['signature'], n_candidates=len(candidates),
                    n_valid_candidates=int(summary.valid.sum()), n_folds=len(ctx['folds']),
                    candidate_fold_evaluations=len(scores), fold_scores_sha256=sha256_file(fold_path),
                    selected_time_utc=datetime.now(timezone.utc).isoformat(),
                    selection_basis='Mean grouped validation-fold RMSE of the complete predictor; no test scores',
                    trend_fit_calls=int(scores.trend_fit_calls.fillna(0).sum()),
                    variogram_fit_calls=int(scores.get('variogram_fit_calls', pd.Series(dtype=float)).fillna(0).sum()),
                    cv_wall_seconds=float(scores.elapsed_seconds.sum()))
    save_json(selected_path, selected)
    return selected


def fit_selected(ctx, method, task, selection, seed, geometry):
    parameters = selection['parameters']
    dev, test, cfg = ctx['dev'], ctx['test'], ctx['cfg']
    if method == 'OK':
        values, base, trend_calls = dev[task['target']].to_numpy(float), np.zeros(len(test)), 0
    else:
        values, base, trend_calls = ridge_components(dev, test, task, parameters['ridge_alpha'], cfg.inner_folds, seed)
    empirical = empirical_variogram(geometry.train, values, parameters['n_lags'], cfg, seed)
    fitted = fit_variogram(empirical, parameters, cfg)
    correction, fallback = geometry.predict(values, fitted, parameters['neighbors'])
    prediction = base + correction
    return prediction, dict(**fitted, method=method, target=task['target'],
                            missing_type=task['missing_type'] if method == 'RK' else None,
                            seed=seed, neighbors=parameters['neighbors'], ridge_alpha=parameters['ridge_alpha'],
                            trend_fit_calls=trend_calls, least_squares_fallbacks=fallback,
                            coordinate_mean=geometry.scaler.mean_.tolist(), coordinate_scale=geometry.scaler.scale_.tolist())


def predict_selected(ctx, selections):
    out, cfg, signature = ctx['out'], ctx['cfg'], ctx['signature']
    geometry = SpatialGeometry(ctx['dev'][COORDINATES], ctx['test'][COORDINATES], cfg)
    methods = []
    for target in TARGETS:
        tasks = [task for task in ctx['tasks'] if task['target'] == target]
        if tasks:
            methods.append(('OK', tasks[0], selections[f'OK_{target}']))
    methods += [('RK', task, selections[f'RK_{task["missing_type"]}_{task["target"]}']) for task in ctx['tasks']]
    for method, task, selection in methods:
        key = selection['task']
        for seed in ctx['seeds']:
            path = out / 'predictions' / f'{key}_seed{seed}.csv'
            meta_path = path.with_suffix('.json')
            if path.is_file() and meta_path.is_file() and cfg.resume:
                meta = json.loads(meta_path.read_text())
                if meta['tuning_signature'] != signature or meta['prediction_sha256'] != sha256_file(path):
                    raise ValueError(f'Changed cached tuned predictions: {path}')
                continue
            started = time.perf_counter()
            prediction, metadata = fit_selected(ctx, method, task, selection, seed, geometry)
            frame = ctx['test'][['global_id', 'borehole_id']].copy()
            frame['actual'] = ctx['test'][task['target']].to_numpy(float)
            frame['prediction'] = prediction
            frame['seed'] = seed
            frame['target'] = task['target']
            frame['method'] = method + '_tuned'
            save_csv(path, frame)
            save_json(meta_path, dict(**metadata, tuning_signature=signature,
                                     prediction_sha256=sha256_file(path), fit_predict_seconds=time.perf_counter() - started,
                                     selected_parameters=selection['parameters']))
        print(f'Tuned predictions {key}: {len(ctx["seeds"])} original fitting seeds', flush=True)
    return methods


def write_comparison_tex(path, frame, columns, caption):
    def escape(value):
        mapping = {'\\': r'\textbackslash{}', '&': r'\&', '%': r'\%', '_': r'\_',
                   '#': r'\#', '$': r'\$', '{': r'\{', '}': r'\}'}
        return ''.join(mapping.get(c, c) for c in str(value))
    def header(value):
        return r'\shortstack{' + r'\\'.join(escape(part) for part in value.split(' ')) + '}'
    def cell(value):
        return escape(value).replace(' +/- ', r' $\pm$ ')
    lines = [r'% Requires booktabs, longtable, pdflscape in a one-column supplement.', r'\begin{landscape}', r'\begingroup',
             r'\small\setlength{\tabcolsep}{4pt}', r'\begin{longtable}{' + 'l' * len(columns) + '}',
             r'\caption{' + escape(caption) + r'}\\', r'\toprule',
             ' & '.join(header(c) for c in columns) + r' \\', r'\midrule', r'\endfirsthead',
             r'\toprule', ' & '.join(header(c) for c in columns) + r' \\', r'\midrule', r'\endhead',
             r'\bottomrule\endfoot']
    for _, row in frame.iterrows():
        lines.append(' & '.join(cell(row[c]) for c in columns) + r' \\')
    lines += [r'\end{longtable}',
              r'\noindent\footnotesize Data notes. Values are mean RMSE +/- sample SD across the same fitting seeds and evaluation records. '
              r'This SD describes seeded computation, not borehole-sampling uncertainty. '
              r'Learner results are retained from the original Study C prediction-derived metrics. '
              r'New OK/RK settings use grouped development CV only; no learner is refitted. '
              r'New OK/RK have equal candidate budgets; retained learner budgets are audited separately. '
              r'Test boreholes are excluded from fitting and tuning. All applicable tasks reuse the same test records and boreholes; '
              r'they are not independent populations. Scope is within-site. In replacement tables OK and RK denote the tuned implementations.',
              r'\endgroup', r'\end{landscape}']
    Path(path).write_text('\n'.join(lines) + '\n', encoding='utf-8')


def _export_comparison_audit(ctx, selections, final_methods):
    out = ctx['out']
    records = []
    original = ctx['original_metrics']
    ensemble = ctx['ensemble']
    old_labels = {'NoSpatial': 'Ensemble NoSpatial', 'XY': 'Ensemble XY', 'Z': 'Ensemble Z', 'XYZ': 'Ensemble XYZ'}
    for task in ctx['tasks']:
        subset = original.loc[(original.missing_type == task['missing_type']) & (original.target == task['target'])]
        for _, row in subset.iterrows():
            if row.model == ensemble:
                label = old_labels.get(row.configuration, 'Ensemble ' + row.configuration)
            elif row.configuration == 'XYZ' and row.model in ctx['learners']:
                label = row.model + ' XYZ'
            elif row.model in {'OK', 'RK'} and row.configuration == 'XYZ':
                label = row.model + ' original'
            else:
                continue
            records.append(dict(missing_type=task['missing_type'], target=task['target'], method=label,
                                seed=int(row.seed), n_test_records=int(row.n_records),
                                n_test_boreholes=int(row.n_boreholes), rmse=float(row.rmse), source='retained original'))
        for method in ['OK', 'RK']:
            key = f'OK_{task["target"]}' if method == 'OK' else f'RK_{task["missing_type"]}_{task["target"]}'
            for seed in ctx['seeds']:
                frame = pd.read_csv(out / 'predictions' / f'{key}_seed{seed}.csv').set_index('global_id')
                evaluation = frame.loc[task['test_ids']]
                error = evaluation.actual.to_numpy(float) - evaluation.prediction.to_numpy(float)
                records.append(dict(missing_type=task['missing_type'], target=task['target'], method=method + ' tuned',
                                    seed=seed, n_test_records=len(evaluation),
                                    n_test_boreholes=evaluation.borehole_id.nunique(), rmse=float(np.sqrt(np.mean(error ** 2))),
                                    source='new empirical-variogram tuning'))
    by_seed = pd.DataFrame(records)
    save_csv(out / 'comparison_rmse_by_seed.csv', by_seed)
    long = by_seed.groupby(['missing_type', 'target', 'method', 'n_test_records', 'n_test_boreholes'], sort=False).agg(
        seeds=('seed', 'size'), rmse_mean=('rmse', 'mean'), rmse_sd=('rmse', 'std')).reset_index()
    save_csv(out / 'overall_comparison_long.csv', long)
    methods_order = ['Ensemble NoSpatial', 'Ensemble XY', 'Ensemble Z', 'Ensemble XYZ']
    methods_order += [name + ' XYZ' for name in ctx['learners']]
    methods_order += ['OK original', 'RK original', 'OK tuned', 'RK tuned']
    wide = []
    numeric = []
    for task in ctx['tasks']:
        group = long.loc[(long.missing_type == task['missing_type']) & (long.target == task['target'])]
        row = {'Missing type': task['missing_type'], 'Target': task['target'],
               'Test records': len(task['test_ids']),
               'Test boreholes': int(group.n_test_boreholes.iloc[0]), 'Seeds': len(ctx['seeds'])}
        numbers = dict(row)
        for method in methods_order:
            match = group.loc[group.method == method]
            if match.empty:
                row[method] = 'not available'
                numbers[method + ' mean'] = np.nan
                numbers[method + ' SD'] = np.nan
            else:
                value = match.iloc[0]
                digits = 4 if task['target'] == 'Cc' else 3
                sd = float(value.rmse_sd)
                row[method] = f'{value.rmse_mean:.{digits}f} +/- {sd:.{digits}f}' if np.isfinite(sd) else f'{value.rmse_mean:.{digits}f}'
                numbers[method + ' mean'] = value.rmse_mean
                numbers[method + ' SD'] = value.rmse_sd
        wide.append(row); numeric.append(numbers)
    overall = pd.DataFrame(wide)
    save_csv(out / 'StudyC_original_vs_tuned_comparison.csv', overall)
    save_csv(out / 'StudyC_original_vs_tuned_comparison_numeric.csv', pd.DataFrame(numeric))
    common = ['Missing type', 'Target', 'Test records', 'Test boreholes', 'Seeds']
    write_comparison_tex(out / 'StudyC_original_vs_tuned_comparison.tex', overall,
                         common + ['Ensemble NoSpatial', 'Ensemble XYZ', 'OK original', 'RK original', 'OK tuned', 'RK tuned'],
                         'Study C retained ensemble results and original versus newly tuned geostatistical comparisons.')
    write_comparison_tex(out / 'StudyC_constituent_audit.tex', overall,
                         common + [name + ' XYZ' for name in ctx['learners']] + ['Ensemble XYZ', 'OK tuned', 'RK tuned'],
                         'Study C retained XYZ constituent/ensemble results and newly tuned geostatistical comparisons.')
    write_comparison_tex(out / 'StudyC_spatial_audit.tex', overall,
                         common + ['Ensemble NoSpatial', 'Ensemble XY', 'Ensemble Z', 'Ensemble XYZ', 'OK tuned', 'RK tuned'],
                         'Study C spatial configurations and newly tuned geostatistical comparisons.')
    budget = []
    for selected in selections.values():
        budget.append({k: selected[k] for k in ['task', 'method', 'target', 'n_candidates', 'n_valid_candidates',
                                               'n_folds', 'candidate_fold_evaluations', 'trend_fit_calls',
                                               'variogram_fit_calls', 'cv_wall_seconds']})
    save_csv(out / 'tuning_budget_audit.csv', pd.DataFrame(budget))
    settings = [dict(task=value['task'], method=value['method'], target=value['target'],
                     missing_type=value['missing_type'], mean_cv_rmse=value['mean_cv_rmse'], **value['parameters'])
                for value in selections.values()]
    save_csv(out / 'selected_OK_RK_settings.csv', pd.DataFrame(settings))
    fitted = []
    for path in sorted((out / 'predictions').glob('*.json')):
        metadata = json.loads(path.read_text())
        fitted.append({k: metadata.get(k) for k in ['method', 'missing_type', 'target', 'seed', 'family',
                       'nugget_mode', 'nugget', 'partial_sill', 'sill', 'range_parameter', 'neighbors',
                       'ridge_alpha', 'empirical_pairs', 'empirical_bins', 'fit_predict_seconds']})
    save_csv(out / 'final_fitted_variogram_parameters.csv', pd.DataFrame(fitted))
    # Prediction equality across missing types is guaranteed by the shared OK
    # cache; selected task subsets can legitimately give different task RMSEs.
    save_json(out / 'comparison_scope.json', dict(
        original_protocol_signature=ctx['original']['protocol_signature'],
        source_mode=ctx['original']['config']['mode'], learner_refitting=False,
        original_files_modified=False, new_comparator_budgets_matched=True,
        equal_historical_effort_across_all_methods_established=False,
        reason='Per-estimator candidate budgets do not establish equal aggregate effort for the three-learner ensemble',
        test_case_policy='Exact original per-task global IDs and fitting seeds retained',
        reporting='Mean +/- fitting/computation SD, not a borehole-bootstrap confidence interval',
    ))
    return overall


def export_retained_tuning_budget(ctx):
    rows = []
    for path in sorted((ctx['root'] / 'selection').glob('primary_*_selected.csv')):
        for record in pd.read_csv(path).to_dict('records'):
            if record.get('missing_type') not in ctx['cfg'].missing_types or record.get('target') not in ctx['cfg'].targets:
                continue
            count = record.get('n_candidates', np.nan)
            rows.append(dict(missing_type=record.get('missing_type'), target=record.get('target'),
                             configuration=record.get('configuration'), model=record.get('model'),
                             n_candidates=count, n_folds=len(ctx['folds']),
                             candidate_fold_evaluations=count * len(ctx['folds']),
                             recorded_search_seconds=record.get('seconds', np.nan),
                             source_file=path.name, source_sha256=sha256_file(path),
                             source='Retained training-only learner selection log; no learner refitted'))
    columns = ['missing_type', 'target', 'configuration', 'model', 'n_candidates', 'n_folds',
               'candidate_fold_evaluations', 'recorded_search_seconds', 'source_file', 'source_sha256', 'source']
    frame = pd.DataFrame(rows, columns=columns)
    save_csv(ctx['out'] / 'retained_learner_tuning_budget.csv', frame)
    return frame


def export_comparison(ctx, selections, final_methods):
    # First preserve the explicit original-versus-tuned audit in this new folder.
    audit = _export_comparison_audit(ctx, selections, final_methods)
    out = ctx['out']
    rename = {'OK tuned': 'OK', 'RK tuned': 'RK'}
    overall = audit.drop(columns=['OK original', 'RK original']).rename(columns=rename)
    save_csv(out / 'StudyC_overall_comparison.csv', overall)
    numeric_audit = pd.read_csv(out / 'StudyC_original_vs_tuned_comparison_numeric.csv')
    numeric = numeric_audit.drop(columns=[c for c in numeric_audit if c.startswith(('OK original ', 'RK original '))])
    numeric = numeric.rename(columns={name + suffix: rename[name] + suffix
                                      for name in rename for suffix in [' mean', ' SD']})
    save_csv(out / 'StudyC_overall_comparison_numeric.csv', numeric)
    common = ['Missing type', 'Target', 'Test records', 'Test boreholes', 'Seeds']
    main_columns = common + ['Ensemble NoSpatial', 'Ensemble XYZ', 'OK', 'RK']
    write_comparison_tex(out / 'StudyC_overall_comparison.tex', overall, main_columns,
                         'Study C retained ensemble results, replacing original OK and RK with training-only tuned implementations.')
    write_comparison_tex(out / 'StudyC_constituent_comparison.tex', overall,
                         common + [name + ' XYZ' for name in ctx['learners']] + ['Ensemble XYZ', 'OK', 'RK'],
                         'Study C retained XYZ constituents and ensemble compared with tuned OK and RK.')
    write_comparison_tex(out / 'StudyC_spatial_comparison.tex', overall,
                         common + ['Ensemble NoSpatial', 'Ensemble XY', 'Ensemble Z', 'Ensemble XYZ', 'OK', 'RK'],
                         'Study C retained spatial configurations compared with tuned OK and RK.')
    # Table 7-style manuscript view. No unverified published-study columns.
    table7 = overall.loc[:, main_columns].rename(columns={
        'Missing type': 'Missing Type', 'Seeds': 'Refit runs',
        'Ensemble NoSpatial': 'Without Spatial', 'Ensemble XYZ': 'XYZ',
        'OK': 'Ordinary Kriging', 'RK': 'Regression Kriging'})
    table7.insert(0, 'Study', 'C')
    table7_numeric = numeric.loc[:, common + [method + suffix for method in ['Ensemble NoSpatial', 'Ensemble XYZ', 'OK', 'RK']
                                               for suffix in [' mean', ' SD']]].rename(columns={
        'Missing type': 'Missing Type', 'Seeds': 'Refit runs',
        **{method + suffix: label + suffix for method, label in [
            ('Ensemble NoSpatial', 'Without Spatial'), ('Ensemble XYZ', 'XYZ'),
            ('OK', 'Ordinary Kriging'), ('RK', 'Regression Kriging')]
           for suffix in [' mean', ' SD']}})
    table7_numeric.insert(0, 'Study', 'C')
    save_csv(out / 'StudyC_Table7_comparison.csv', table7)
    save_csv(out / 'StudyC_Table7_comparison_numeric.csv', table7_numeric)
    write_comparison_tex(out / 'StudyC_Table7_comparison.tex', table7, list(table7),
                         'Study C Table 7-style comparison: original learner results with tuned OK and RK replacements.')
    # The same coordinate-only predictor and identical test population must give
    # identical OK RMSE under every missing type for each target and seed.
    by_seed = pd.read_csv(out / 'comparison_rmse_by_seed.csv')
    checks = []
    for (target, seed), group in by_seed.loc[by_seed.method == 'OK tuned'].groupby(['target', 'seed']):
        span = float(group.rmse.max() - group.rmse.min())
        consistent = bool(np.allclose(group.rmse, group.rmse.iloc[0], rtol=1e-12, atol=1e-12))
        checks.append(dict(target=target, seed=int(seed), missing_types=';'.join(group.missing_type),
                           n_missing_types=len(group), rmse_max_minus_min=span, consistent=consistent))
    invariance = pd.DataFrame(checks)
    save_csv(out / 'tuned_OK_invariance_checks.csv', invariance)
    if not invariance.consistent.all():
        raise AssertionError('Tuned OK differs across identical Study C cases; inspect the invariance audit')
    learner_budget = export_retained_tuning_budget(ctx)
    # Explicitly record what was and was not matched across methods.
    save_json(out / 'comparison_scope.json', dict(
        study='C', original_protocol_signature=ctx['original']['protocol_signature'],
        source_mode=ctx['original']['config']['mode'], learner_refitting=False,
        original_files_modified=False, new_comparator_budgets_matched=True,
        retained_learner_budget_rows=len(learner_budget),
        per_estimator_candidate_budget=int(ctx['cfg'].n_candidates),
        equal_aggregate_effort_across_all_methods_established=False,
        reason='OK/RK candidate budgets match each other. Learner logs are reported separately. '
               'The ensemble has three constituent searches, while RK also fits inner-fold trends; '
               'equal candidate counts are not equal wall time or aggregate fitting effort.',
        test_case_policy='Every task uses the entire original test dataset; no row mapping',
        n_test_records=len(ctx['test']), n_test_boreholes=int(ctx['test'].borehole_id.nunique()),
        n_training_records=len(ctx['dev']), n_training_boreholes=int(ctx['dev'].borehole_id.nunique()),
        shared_training_test_boreholes=0, fitting_seeds=list(ctx['seeds']),
        table7_geo_columns='Tuned OK/RK replace originals in the new comparison only',
        published_method_values='Not supplied for this Study C split; omitted rather than copied from Study A',
        reporting='Mean +/- sample SD of per-seed RMSE; not a borehole-bootstrap confidence interval',
        uncertainty_scope='Existing bootstrap/statistical/figure outputs for original OK/RK do not describe the new tuned models',
        interpretation='Within-site held-out-borehole evaluation; only eight test clusters in the full Study C case',
    ))
    notes = """Study C additional comparator analysis

OK and RK in StudyC_Table7_comparison and StudyC_overall_comparison refer to the
new empirically fitted, training-only tuned variogram implementations. Original
learner results, case identifiers, folds and fitting seeds are retained.
StudyC_original_vs_tuned_comparison preserves both comparator versions.

RMSE is in each target's original units. Cells report mean per-seed RMSE +/-
sample SD (ddof=1), not RMSE of seed-averaged predictions or a confidence interval.
SD for OK can reflect sampled variogram pairs; RK also varies inner grouped folds.
All missing-type scenarios reuse the same test records; do not multiply their
record or borehole counts. No cross-target average of raw RMSE is meaningful.

The full case has 106 records from eight training-disjoint boreholes. This is
within-site evidence, not independent-site validation. Hyperparameters, empirical
variograms and coordinate/trend scalers are fitted using training partitions only.
XYZ coordinates use training-fitted axis standardization (an implicit metric
choice); no separate anisotropy search is made. RK uses nonspatial predictors and
the saved task polynomial degree; its variogram uses grouped out-of-fold training
residuals, not outer-validation or test residuals.

Twenty sampled candidates per estimator is the default, not an exhaustive grid.
Compare retained_learner_tuning_budget.csv and tuning_budget_audit.csv before
describing tuning fairness. The ensemble comprises three separately tuned learners;
RK requires inner-fold trend fits. Equal candidate counts do not prove identical
computational effort. Comparator choices were developed as a post-review addition,
after earlier test results existed, so this remains a supplemental comparison.

Old bootstrap intervals, Wilcoxon/Holm comparisons and figures involving the old
OK/RK are not silently updated. Recompute those from the new saved predictions if
you cite inferential/figure results for the tuned comparators. These tables alone
do not demonstrate statistical significance, universal superiority or depth effects.
Use NoSpatial/XY/Z/XYZ matched comparisons for the contribution of spatial features.
"""
    (out / 'TABLE_DATA_NOTES.txt').write_text(notes, encoding='utf-8')
    ctx['table7_comparison'] = table7
    return overall


def run_ok_rk_tuning(cfg, validate_only=False):
    if cfg.n_candidates < 1 or cfg.inner_folds < 2 or cfg.pair_sample < 20 or cfg.batch_size < 1:
        raise ValueError('Invalid tuning/inner-CV/variogram settings')
    if not set(cfg.families) <= {'spherical', 'exponential', 'gaussian'} or not cfg.families:
        raise ValueError('Unsupported variogram families')
    if not set(cfg.nugget_modes) <= {'zero', 'fit'} or not cfg.nugget_modes:
        raise ValueError('Unsupported nugget modes')
    if min(cfg.neighbor_counts) < 2 or min(cfg.lag_counts) < 4 or not 0 < cfg.max_lag_quantile <= 1:
        raise ValueError('Invalid neighborhood or lag settings')
    candidate_configurations(cfg, 'OK'); candidate_configurations(cfg, 'RK')
    ctx = load_existing_study(cfg)
    ctx['cfg'] = cfg
    print(f'Existing Study C: {len(ctx["dev"])} development records; {len(ctx["tasks"])} requested tasks; '
          f'{len(ctx["folds"])} original grouped folds; {len(ctx["seeds"])} original fitting seeds.', flush=True)
    if validate_only:
        return ctx
    out = Path(cfg.output_dir).expanduser().resolve() if cfg.output_dir else ctx['root'] / 'OK_RK_tuning'
    if out == ctx['root']:
        raise ValueError('The companion must use a separate output directory')
    source = TUNING_SOURCE if 'TUNING_SOURCE' in globals() else Path(__file__).read_text()
    protocol = dict(
        revision=REVISION, source_sha256=hashlib.sha256(source.encode()).hexdigest(), config=asdict(cfg),
        original_protocol_signature=ctx['original']['protocol_signature'],
        original_prediction_index_sha256=ctx['index_sha256'], original_metrics_sha256=ctx['metrics_sha256'],
        original_cv_folds_sha256=ctx['folds_sha256'],
        original_artifact_sha256=ctx['source_artifact_sha256'],
    )
    signature_data = json.loads(json.dumps(protocol, default=_json))
    for name in ['study_c_output_dir', 'output_dir', 'input_overrides', 'resume']:
        signature_data['config'].pop(name, None)
    signature = hashlib.sha256(json.dumps(signature_data, sort_keys=True).encode()).hexdigest()
    out.mkdir(parents=True, exist_ok=True)
    manifest_path = out / 'tuning_manifest.json'
    if manifest_path.exists():
        old = json.loads(manifest_path.read_text())
        if old.get('tuning_signature') != signature:
            raise ValueError('Companion output belongs to different settings/code/source results; choose a new output_dir')
        if not cfg.resume:
            raise ValueError('Companion results already exist; enable resume or choose a new output_dir')
    ctx.update(out=out, signature=signature)
    started = time.perf_counter()
    manifest = dict(**protocol, tuning_signature=signature, status='TUNING',
                    source_results_unchanged=True, learner_refitting=False,
                    started_time_utc=datetime.now(timezone.utc).isoformat())
    save_json(manifest_path, manifest)
    try:
        selections = {}
        with threadpool_limits(limits=cfg.linear_algebra_threads):
            for target in TARGETS:
                tasks = [task for task in ctx['tasks'] if task['target'] == target]
                if tasks:
                    selections[f'OK_{target}'] = tune_one(ctx, 'OK', tasks[0])
            for task in ctx['tasks']:
                selections[f'RK_{task["missing_type"]}_{task["target"]}'] = tune_one(ctx, 'RK', task)
            manifest.update(status='SETTINGS_LOCKED_BEFORE_NEW_TEST_PREDICTIONS',
                            selection_locked_time_utc=datetime.now(timezone.utc).isoformat())
            save_json(manifest_path, manifest)
            save_json(out / 'locked_comparator_settings.json', selections)
            final_methods = predict_selected(ctx, selections)
            comparison = export_comparison(ctx, selections, final_methods)
        manifest.update(status='COMPLETE', completed_time_utc=datetime.now(timezone.utc).isoformat(),
                        elapsed_seconds=time.perf_counter() - started,
                        overall_comparison_sha256=sha256_file(out / 'StudyC_overall_comparison.csv'),
                        table7_comparison_sha256=sha256_file(out / 'StudyC_Table7_comparison.csv'))
        save_json(manifest_path, manifest)
        print(f'Completed additional OK/RK tuning without refitting RF/GBR/XGB: {out}', flush=True)
        print(comparison.to_string(index=False), flush=True)
        ctx['overall_comparison'] = comparison
        return ctx
    except BaseException as exc:
        manifest.update(status='FAILED', error_type=type(exc).__name__, error_message=str(exc),
                        failed_time_utc=datetime.now(timezone.utc).isoformat())
        save_json(manifest_path, manifest)
        raise


def cli():
    parser = argparse.ArgumentParser(description='Additional Study C empirical-variogram OK/RK tuning; retain existing learner results')
    parser.add_argument('--study-c-output', default='StudyC_reconciled')
    parser.add_argument('--output-dir')
    parser.add_argument('--config', help='JSON object of TuningConfig fields')
    parser.add_argument('--validate-only', action='store_true')
    args = parser.parse_args()
    settings = json.loads(Path(args.config).read_text()) if args.config else {}
    settings.setdefault('study_c_output_dir', args.study_c_output)
    if args.output_dir:
        settings['output_dir'] = args.output_dir
    return run_ok_rk_tuning(TuningConfig(**settings), validate_only=args.validate_only)


if __name__ == '__main__':
    ok_rk_context = cli()
