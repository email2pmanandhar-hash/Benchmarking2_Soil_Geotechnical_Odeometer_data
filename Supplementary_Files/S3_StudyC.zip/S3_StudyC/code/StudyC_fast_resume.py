"""Study C execution engine with persistent, fine-grained checkpoints.

The original scientific source is embedded below and executed in an isolated
module. The original notebook and its kernel helper functions are not modified.
Use run_study_c_fast(CONFIG, RuntimeOptions(workers=4, stage='all')).
"""
from __future__ import annotations

ORIGINAL_CORE_SOURCE = '# Study C: two datasets, complete held-out test set, no row mapping.\n\nfrom __future__ import annotations\n\nimport argparse\nimport json\nimport platform\nimport sys\nimport time\nimport warnings\nfrom dataclasses import asdict, dataclass\nfrom pathlib import Path\nfrom typing import Any, Iterable\n\nimport joblib\nimport numpy as np\nimport pandas as pd\nimport scipy\nfrom scipy.stats import t as student_t\nfrom scipy.stats import wilcoxon\nimport sklearn\nfrom sklearn.base import clone\nfrom sklearn.compose import TransformedTargetRegressor\nfrom sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor\nfrom sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score\nfrom sklearn.model_selection import GridSearchCV, GroupKFold, KFold, RandomizedSearchCV, ParameterSampler, ParameterGrid, cross_val_predict\nfrom sklearn.pipeline import Pipeline\nfrom sklearn.preprocessing import PolynomialFeatures, StandardScaler\n\n\nCORE_FEATURES = [\n    "Sr",\n    "gamma_t",\n    "e",\n    "LL",\n    "PL",\n    "w",\n    "PI",\n    "LI",\n    "e_squared",\n    "w_by_LL",\n    "Sr_log",\n    "moisture_void_ratio",\n]\n\nSPATIAL_FEATURES = {\n    "NoSpatial": [],\n    "XY": ["x", "y"],\n    "Z": ["z_depth"],\n    "XYZ": ["x", "y", "z_depth"],\n}\n\nCONFIG_LABELS = {\n    "NoSpatial": "Without Spatial",\n    "XY": "With XY",\n    "Z": "With Z",\n    "XYZ": "With XYZ",\n}\n\nTARGET_ORDER = ["Cc", "Cv", "Pc", "E50", "su"]\nCONFIG_ORDER = ["NoSpatial", "XY", "Z", "XYZ"]\nMISSING_TYPE_ORDER = ["MT1", "MT2", "MT3", "MT4"]\nMODEL_ORDER = ["RF", "GBR", "XGB", "Ensemble"]\nSPLIT_ORDER = ["Development", "Test"]\n\nMISSINGNESS_PATTERNS = {\n    "MT1": {\n        "known_mechanical": [],\n        "targets": ["Cc", "Cv", "Pc", "E50", "su"],\n        "polynomial_degree": 1,\n    },\n    "MT2": {\n        "known_mechanical": ["su"],\n        "targets": ["Cc", "Cv", "Pc", "E50"],\n        "polynomial_degree": 2,\n    },\n    "MT3": {\n        "known_mechanical": ["su", "E50"],\n        "targets": ["Cc", "Cv", "Pc"],\n        "polynomial_degree": 2,\n    },\n    "MT4": {\n        "known_mechanical": ["Pc", "Cc", "Cv"],\n        "targets": ["E50", "su"],\n        "polynomial_degree": 2,\n    },\n}\n\n\n@dataclass(frozen=True)\nclass ExperimentTask:\n    configuration: str\n    missing_type: str\n    target: str\n    features: tuple[str, ...]\n    polynomial_degree: int\n\nfrom scipy.spatial import cKDTree\nfrom scipy.spatial.distance import cdist\nfrom sklearn.linear_model import Ridge\nfrom importlib import metadata as importlib_metadata\nimport hashlib, os, itertools, gzip, math, shutil\nfrom datetime import datetime, timezone\n\ndef get_xgb_regressor(seed: int) -> Any:\n    try:\n        import xgboost\n        from xgboost import XGBRegressor\n    except ImportError as exc:\n        raise ImportError(\n            "XGBoost is required for the three-model manuscript ensemble. "\n            "Install it with `pip install xgboost`, or use --models RF GBR only for a smoke test."\n        ) from exc\n    return XGBRegressor(\n        objective="reg:squarederror",\n        eval_metric="rmse",\n        random_state=seed,\n        n_jobs=1,\n        verbosity=0,\n    )\n\ndef base_model(model_name: str, seed: int) -> Any:\n    if model_name == "RF":\n        return RandomForestRegressor(random_state=seed, n_jobs=1)\n    if model_name == "GBR":\n        return GradientBoostingRegressor(random_state=seed, loss="squared_error")\n    if model_name == "XGB":\n        return get_xgb_regressor(seed)\n    raise KeyError(model_name)\n\ndef search_space(model_name: str, profile: str) -> dict[str, list[Any]]:\n    prefix = "regressor__model__"\n    if profile == "smoke":\n        spaces = {\n            "RF": {"n_estimators": [20], "max_depth": [5], "min_samples_split": [2]},\n            "GBR": {"n_estimators": [20], "learning_rate": [0.05], "max_depth": [3]},\n            "XGB": {"n_estimators": [20], "learning_rate": [0.05], "max_depth": [3]},\n        }\n    elif profile == "manuscript":\n        spaces = {\n            "RF": {\n                "n_estimators": [100, 200, 500],\n                "max_depth": [5, 10],\n                "min_samples_split": [2, 5],\n            },\n            "GBR": {\n                "n_estimators": [100, 200, 500],\n                "learning_rate": [0.05, 0.1],\n                "max_depth": [3, 5],\n            },\n            "XGB": {\n                "n_estimators": [100, 200, 500],\n                "learning_rate": [0.05, 0.1],\n                "max_depth": [3, 5],\n            },\n        }\n    else:\n        spaces = {\n            "RF": {\n                "n_estimators": [200, 500, 800],\n                "max_depth": [None, 5, 10, 20],\n                "min_samples_split": [2, 5, 10],\n                "min_samples_leaf": [1, 2, 4],\n                "max_features": [1.0, 0.5, "sqrt"],\n            },\n            "GBR": {\n                "n_estimators": [100, 200, 500],\n                "learning_rate": [0.03, 0.05, 0.1],\n                "max_depth": [2, 3, 5],\n                "min_samples_split": [2, 5, 10],\n                "min_samples_leaf": [1, 2, 4],\n                "subsample": [0.8, 1.0],\n                "max_features": [None, "sqrt"],\n            },\n            "XGB": {\n                "n_estimators": [100, 200, 500],\n                "learning_rate": [0.03, 0.05, 0.1],\n                "max_depth": [3, 5, 8],\n                "min_child_weight": [1, 3, 5],\n                "subsample": [0.8, 1.0],\n                "colsample_bytree": [0.8, 1.0],\n                "reg_alpha": [0.0, 0.1],\n                "reg_lambda": [1.0, 5.0],\n            },\n        }\n    return {prefix + key: value for key, value in spaces[model_name].items()}\n\ndef build_estimator(model_name: str, degree: int, seed: int) -> TransformedTargetRegressor:\n    pipeline = Pipeline(\n        [\n            ("poly", PolynomialFeatures(degree=degree, include_bias=False)),\n            ("scale", StandardScaler()),\n            ("model", base_model(model_name, seed)),\n        ]\n    )\n    return TransformedTargetRegressor(regressor=pipeline, transformer=StandardScaler())\n\ndef _expanded_feature_count(raw_count: int, degree: int) -> int:\n    if degree == 1:\n        return raw_count\n    if degree == 2:\n        return raw_count + raw_count * (raw_count + 1) // 2\n    poly = PolynomialFeatures(degree=degree, include_bias=False)\n    poly.fit(np.zeros((1, raw_count)))\n    return int(poly.n_output_features_)\n\ndef robust_l2(y_true: np.ndarray, y_pred: np.ndarray, delta: float) -> float:\n    residual = np.asarray(y_true, dtype=float) - np.asarray(y_pred, dtype=float)\n    absolute = np.abs(residual)\n    loss = np.where(\n        absolute <= delta,\n        0.5 * residual**2,\n        delta * (absolute - 0.5 * delta),\n    )\n    return float(np.mean(loss))\n\ndef holm_adjust(p_values: np.ndarray) -> np.ndarray:\n    p_values = np.asarray(p_values, dtype=float)\n    order = np.argsort(p_values)\n    adjusted_sorted = np.empty_like(p_values)\n    running = 0.0\n    total = len(p_values)\n    for rank, original_index in enumerate(order):\n        candidate = min(1.0, (total - rank) * p_values[original_index])\n        running = max(running, candidate)\n        adjusted_sorted[original_index] = running\n    return adjusted_sorted\n\ndef mean_sd_text(mean: float, sd: float, target: str, metric: str) -> str:\n    if pd.isna(mean):\n        return ""\n    if target == "Cc" and metric not in {"rmse_percent", "r2"}:\n        digits = 4\n    elif metric in {"rmse_percent", "r2"}:\n        digits = 3\n    elif target in {"E50", "Cv"}:\n        digits = 2\n    else:\n        digits = 3\n    if pd.isna(sd):\n        return f"{mean:.{digits}f}"\n    return f"{mean:.{digits}f} +/- {sd:.{digits}f}"\n\ndef spherical_semivariogram(\n    distances: np.ndarray,\n    spatial_range: float,\n    partial_sill: float,\n    nugget: float,\n) -> np.ndarray:\n    distances = np.asarray(distances, dtype=float)\n    ratio = np.clip(distances / spatial_range, 0.0, None)\n    inside = nugget + partial_sill * (1.5 * ratio - 0.5 * ratio**3)\n    semivariance = np.where(\n        distances <= spatial_range,\n        inside,\n        nugget + partial_sill,\n    )\n    return np.where(distances == 0.0, 0.0, semivariance)\n\ndef local_ordinary_kriging_predict(\n    train_coordinates: np.ndarray,\n    train_values: np.ndarray,\n    query_coordinates: np.ndarray,\n    neighbors: int,\n    variogram: dict[str, float],\n) -> np.ndarray:\n    """Predict with local ordinary kriging and an unbiasedness constraint."""\n    train_coordinates = np.asarray(train_coordinates, dtype=float)\n    train_values = np.asarray(train_values, dtype=float)\n    query_coordinates = np.asarray(query_coordinates, dtype=float)\n    neighbor_count = min(int(neighbors), len(train_coordinates))\n    if neighbor_count < 2:\n        raise ValueError("Ordinary kriging requires at least two neighbors.")\n\n    tree = cKDTree(train_coordinates)\n    predictions = []\n    for query in query_coordinates:\n        distances, indices = tree.query(query, k=neighbor_count)\n        distances = np.atleast_1d(distances)\n        indices = np.atleast_1d(indices)\n\n        exact = np.flatnonzero(distances <= 1e-12)\n        if exact.size:\n            predictions.append(float(np.mean(train_values[indices[exact]])))\n            continue\n\n        local_coordinates = train_coordinates[indices]\n        local_values = train_values[indices]\n        gamma_matrix = spherical_semivariogram(\n            cdist(local_coordinates, local_coordinates),\n            variogram["range"],\n            variogram["partial_sill"],\n            variogram["nugget"],\n        )\n        gamma_query = spherical_semivariogram(\n            cdist(local_coordinates, query.reshape(1, -1)).ravel(),\n            variogram["range"],\n            variogram["partial_sill"],\n            variogram["nugget"],\n        )\n\n        system = np.empty((neighbor_count + 1, neighbor_count + 1), dtype=float)\n        system[:neighbor_count, :neighbor_count] = gamma_matrix\n        system[:neighbor_count, -1] = 1.0\n        system[-1, :neighbor_count] = 1.0\n        system[-1, -1] = 0.0\n        system[:neighbor_count, :neighbor_count] += np.eye(neighbor_count) * 1e-10\n        rhs = np.append(gamma_query, 1.0)\n        try:\n            solution = np.linalg.solve(system, rhs)\n        except np.linalg.LinAlgError:\n            solution = np.linalg.lstsq(system, rhs, rcond=None)[0]\n        predictions.append(float(np.dot(solution[:neighbor_count], local_values)))\n    return np.asarray(predictions)\n\nREVISION = \'study-c-two-dataset-reviewer-revision-2026-11-02-v1\'\nSPATIAL_COORDINATES = [\'x\', \'y\', \'z_depth\']\nPRIMARY_LEARNERS = [\'RF\', \'GBR\', \'XGB\']\n\n@dataclass\nclass StudyCConfig:\n    train: str = \'BM2_Data_All_without_106_records.csv\'\n    test: str = \'BM2_Data_All_with_106_records.csv\'\n    output_dir: str = \'StudyC_reconciled\'\n    mode: str = \'retune\'  # retune or smoke; no Study A settings are replayed\n    cv_policy: str = \'training_only_grouped_cv\'\n    expected_test_records: int | None = 106\n    runs: int = 40\n    base_seed: int = 2026\n    tuning_seed: int = 1729\n    cv_folds: int = 5\n    search_iterations: int = 20\n    n_jobs: int = 1\n    learners: tuple = (\'RF\', \'GBR\', \'XGB\')\n    configurations: tuple = (\'NoSpatial\', \'XY\', \'Z\', \'XYZ\')\n    missing_types: tuple = (\'MT1\', \'MT2\', \'MT3\', \'MT4\')\n    targets: tuple = (\'Cc\', \'Cv\', \'Pc\', \'E50\', \'su\')\n    robust_delta: float = 1.0\n    bootstrap_replicates: int = 2000\n    bootstrap_seed: int = 902026\n    representative_seed: int = 2026\n    comparators: bool = True\n    run_polynomial_ablation: bool = True\n    run_variogram_sensitivity: bool = True\n    sensitivity_seed: int = 1729\n    sensitivity_neighbors: int = 32\n    save_representative_models: bool = True\n    run_shap: bool = True\n    shap_background_size: int = 50\n    shap_scope: str = \'heldout_all\'\n    shap_max_development_samples: int | None = None\n    ok_neighbors: int = 64\n    pair_sample: int = 50_000\n    range_quantile: float = 0.75\n    nugget_fraction: float = 0.05\n    ridge_alphas: tuple = (0.01, 0.1, 1.0, 10.0, 100.0)\n    resume: bool = True\n\n    @property\n    def ensemble_label(self):\n        return \'Ensemble\' if set(self.learners) == set(PRIMARY_LEARNERS) else \'DiagnosticMean_\' + \'_\'.join(self.learners)\n\n    @property\n    def is_full_protocol(self):\n        return (self.mode == \'retune\' and set(self.learners) == set(PRIMARY_LEARNERS)\n                and self.runs == 40 and self.base_seed == 2026\n                and set(self.configurations) == set(CONFIG_ORDER)\n                and set(self.missing_types) == set(MISSING_TYPE_ORDER)\n                and set(self.targets) == set(TARGET_ORDER))\n\n\ndef json_safe(value):\n    if isinstance(value, Path): return str(value)\n    if isinstance(value, np.generic): return value.item()\n    if isinstance(value, np.ndarray): return value.tolist()\n    raise TypeError(type(value).__name__)\n\n\ndef save_json(path, obj):\n    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)\n    tmp = path.with_suffix(path.suffix + \'.tmp\')\n    tmp.write_text(json.dumps(obj, indent=2, default=json_safe), encoding=\'utf-8\')\n    tmp.replace(path)\n\n\ndef save_locked_json(path, obj):\n    save_json(path, obj)\n    save_json(Path(str(path)+\'.receipt.json\'), {\'sha256\': sha256_file(path)})\n\n\ndef read_locked_json(path):\n    receipt=Path(str(path)+\'.receipt.json\')\n    if not receipt.exists() or json.loads(receipt.read_text())[\'sha256\']!=sha256_file(path):\n        raise ValueError(f\'Selection integrity check failed: {Path(path).name}\')\n    return json.loads(Path(path).read_text())\n\n\ndef sha256_file(path):\n    h = hashlib.sha256()\n    with open(path, \'rb\') as f:\n        for chunk in iter(lambda: f.read(1024 * 1024), b\'\'): h.update(chunk)\n    return h.hexdigest()\n\n\ndef core_source_hash():\n    # Include executed function bytecode so editing a notebook cell cannot retain a stale snapshot hash.\n    import ast, marshal, types, __future__\n    source=CORE_SOURCE if \'CORE_SOURCE\' in globals() else Path(__file__).read_text()\n    def normalize(code):\n        constants=tuple(normalize(v) if isinstance(v,types.CodeType) else v for v in code.co_consts)\n        return code.replace(co_filename=\'<study-c-core>\',co_firstlineno=1,co_linetable=b\'\',co_consts=constants,\n                            co_flags=code.co_flags & ~__future__.annotations.compiler_flag)\n    functions={}\n    for node in ast.parse(source).body:\n        if isinstance(node,ast.FunctionDef):\n            obj=globals()[node.name]\n            functions[node.name]=hashlib.sha256(marshal.dumps(normalize(obj.__code__)) + repr(obj.__defaults__).encode()).hexdigest()\n        elif isinstance(node,ast.ClassDef):\n            for method in node.body:\n                if isinstance(method,ast.FunctionDef):\n                    obj=getattr(globals()[node.name],method.name)\n                    if isinstance(obj,property):obj=obj.fget\n                    functions[node.name+\'.\'+method.name]=hashlib.sha256(marshal.dumps(normalize(obj.__code__))).hexdigest()\n    schema={name:globals()[name] for name in [\'CORE_FEATURES\',\'SPATIAL_FEATURES\',\'CONFIG_ORDER\',\'MISSINGNESS_PATTERNS\',\n            \'SOURCE_ARTIFACTS\',\'PSEUDOCODE_TEXT\']}\n    payload=dict(snapshot_sha256=hashlib.sha256(source.encode()).hexdigest(),executed_functions=functions,schema=schema)\n    return hashlib.sha256(json.dumps(payload,sort_keys=True,default=json_safe).encode()).hexdigest()\n\n\ndef resolve_file(raw):\n    p = Path(raw).expanduser()\n    roots = [Path.cwd(), Path.cwd() / \'inputs\']\n    if \'__file__\' in globals(): roots += [Path(__file__).resolve().parent, Path(__file__).resolve().parent.parent.parent / \'inputs\']\n    candidates = [p] if p.is_absolute() else [r / p for r in roots]\n    for candidate in candidates:\n        if candidate.is_file(): return candidate.resolve()\n    raise FileNotFoundError(f\'Input not found: {raw}. Set the two paths in the configuration cell.\')\n\n\ndef read_input(path):\n    path = Path(path)\n    f = pd.read_excel(path) if path.suffix.lower() in {\'.xlsx\', \'.xls\'} else pd.read_csv(path)\n    f = f.loc[:, ~f.columns.astype(str).str.startswith(\'Unnamed:\')].copy()\n    required = [\'global_id\', \'borehole_id\', \'Sr\', \'gamma_t\', \'e\', \'LL\', \'PL\', \'w\', \'su\', \'E50\', \'Pc\', \'Cc\', \'Cv\'] + SPATIAL_COORDINATES\n    absent = set(required) - set(f)\n    if absent: raise ValueError(f\'{path.name}: missing columns {sorted(absent)}\')\n    if f[[\'global_id\', \'borehole_id\']].isna().any().any(): raise ValueError(\'Missing record or borehole identifier\')\n    for col in [\'global_id\', \'borehole_id\']:\n        num = pd.to_numeric(f[col], errors=\'raise\')\n        if not np.equal(num, np.floor(num)).all(): raise ValueError(f\'{col} must contain integer identifiers\')\n        f[col] = num.astype(\'int64\')\n    if f.global_id.duplicated().any(): raise ValueError(f\'Duplicated global_id in {path.name}\')\n    for col in required[2:]: f[col] = pd.to_numeric(f[col], errors=\'raise\')\n    if not np.isfinite(f[required[2:]].to_numpy(float)).all(): raise ValueError(f\'Nonfinite data in {path.name}\')\n    if (f.Sr + 1e-5 <= 0).any(): raise ValueError(\'Sr is outside log-transform domain\')\n    # Preserve the supplied implementation, including the LI epsilon.\n    f[\'PI\'] = f.LL - f.PL\n    f[\'LI\'] = (f.w - f.PL) / (f.PI + 1e-5)\n    f[\'e_squared\'] = f.e ** 2\n    f[\'w_by_LL\'] = f.w / (f.LL + 1e-5)\n    f[\'Sr_log\'] = np.log(f.Sr + 1e-5)\n    f[\'moisture_void_ratio\'] = f.w * f.e\n    if not np.isfinite(f[CORE_FEATURES].to_numpy(float)).all(): raise ValueError(\'Nonfinite engineered values\')\n    return f\n\n\ndef selected_test(test, mt):\n    """Every Study C task evaluates the complete supplied held-out test set."""\n    if mt not in MISSINGNESS_PATTERNS:\n        raise KeyError(mt)\n    return test.reset_index(drop=True).copy()\n\n\ndef grouped_folds(frame, folds, seed):\n    if frame.borehole_id.nunique() < folds: raise ValueError(\'Too few boreholes for grouped CV\')\n    # Require the declared shuffled splitter. Never silently fall back to unshuffled CV.\n    try: splitter = GroupKFold(n_splits=folds, shuffle=True, random_state=seed)\n    except TypeError as exc: raise RuntimeError(\'scikit-learn >= 1.6 is required for this grouped/shuffled protocol\') from exc\n    indices = list(splitter.split(frame, groups=frame.borehole_id))\n    for tr, va in indices:\n        assert not set(frame.iloc[tr].borehole_id) & set(frame.iloc[va].borehole_id)\n    return indices\n\n\ndef study_tasks(cfg, analysis=\'primary\'):\n    for mt in MISSING_TYPE_ORDER:\n        if mt not in cfg.missing_types: continue\n        spec = MISSINGNESS_PATTERNS[mt]\n        if analysis == \'no_polynomial\' and spec[\'polynomial_degree\'] == 1: continue\n        for conf in CONFIG_ORDER:\n            if conf not in cfg.configurations: continue\n            for target in spec[\'targets\']:\n                if target in cfg.targets:\n                    yield ExperimentTask(conf, mt, target, tuple(CORE_FEATURES + SPATIAL_FEATURES[conf] + spec[\'known_mechanical\']), 1 if analysis == \'no_polynomial\' else spec[\'polynomial_degree\'])\n\n\ndef sample_count_tables(dev, test, cfg):\n    tasks = list(study_tasks(cfg))\n    rows = []\n    seen = set()\n    for task in tasks:\n        key = (task.missing_type, task.target)\n        if key in seen:\n            continue\n        seen.add(key)\n        rows.append(dict(\n            study=\'C\', missing_type=task.missing_type, target=task.target,\n            n_test_records=len(test), n_test_boreholes=test.borehole_id.nunique(),\n            n_development_records=len(dev), n_development_boreholes=dev.borehole_id.nunique(),\n            test_global_ids=json.dumps(test.global_id.tolist()),\n            test_borehole_ids=json.dumps(sorted(test.borehole_id.unique().tolist())),\n            evaluation_basis=\'Complete same held-out test set for every missing type; no row mapping\',\n        ))\n    totals = []\n    for target in TARGET_ORDER:\n        applicable = sorted({t.missing_type for t in tasks if t.target == target})\n        if not applicable:\n            continue\n        totals.append(dict(\n            target=target, applicable_scenarios=len(applicable),\n            observation_scenario_pairs=len(test) * len(applicable),\n            unique_records_across_scenarios=test.global_id.nunique(),\n            unique_boreholes_across_scenarios=test.borehole_id.nunique(),\n            interpretation=\'The same test records are reused across scenarios; scenario repetitions are not independent observations\',\n        ))\n    return pd.DataFrame(rows), pd.DataFrame(totals)\n\n\ndef dependency_report(require_shap=False):\n    names = [\'numpy\', \'pandas\', \'scipy\', \'scikit-learn\', \'xgboost\', \'shap\', \'matplotlib\', \'joblib\', \'openpyxl\']\n    rows = []\n    for name in names:\n        try:\n            d = importlib_metadata.distribution(name)\n            rows.append(dict(package=name, version=d.version, requires_python=d.metadata.get(\'Requires-Python\', \'\'), installed=True))\n        except importlib_metadata.PackageNotFoundError:\n            rows.append(dict(package=name, version=\'NOT INSTALLED\', requires_python=\'\', installed=False))\n    return pd.DataFrame([dict(package=\'Python\', version=platform.python_version(), requires_python=\'\', installed=True)] + rows)\n\n\ndef initialize_run(cfg):\n    if cfg.mode not in {\'retune\', \'smoke\'}:\n        raise ValueError(\'Study C mode must be retune or smoke; Study A Table 20 replay is not supported\')\n    if cfg.cv_policy != \'training_only_grouped_cv\':\n        raise ValueError(\'Study C uses training-only grouped CV and no auxiliary verification set\')\n    if cfg.runs < 1 or cfg.robust_delta <= 0 or cfg.bootstrap_replicates < 1 or cfg.search_iterations < 1:\n        raise ValueError(\'Invalid run, loss, bootstrap or search settings\')\n    if cfg.representative_seed not in range(cfg.base_seed, cfg.base_seed + cfg.runs):\n        raise ValueError(\'Representative seed must belong to the run set\')\n    if not cfg.learners or len(set(cfg.learners)) != len(cfg.learners) or set(cfg.learners) - set(PRIMARY_LEARNERS):\n        raise ValueError(\'Invalid learners\')\n    if not cfg.configurations or set(cfg.configurations) - set(CONFIG_ORDER):\n        raise ValueError(\'Invalid spatial configurations\')\n    if not cfg.missing_types or set(cfg.missing_types) - set(MISSING_TYPE_ORDER):\n        raise ValueError(\'Invalid missing types\')\n    if not cfg.targets or set(cfg.targets) - set(TARGET_ORDER):\n        raise ValueError(\'Invalid targets\')\n    if cfg.shap_scope not in {\'heldout_all\', \'development_nonmechanical\'} or cfg.shap_background_size < 1:\n        raise ValueError(\'Invalid SHAP settings\')\n    if cfg.shap_max_development_samples is not None and cfg.shap_max_development_samples < 1:\n        raise ValueError(\'SHAP development cap must be positive\')\n    paths = dict(train=resolve_file(cfg.train), test=resolve_file(cfg.test))\n    train = read_input(paths[\'train\']).reset_index(drop=True)\n    test = read_input(paths[\'test\']).reset_index(drop=True)\n    if train.empty or test.empty:\n        raise ValueError(\'Training and test datasets must both be nonempty\')\n    if cfg.expected_test_records is not None and len(test) != cfg.expected_test_records:\n        raise ValueError(f\'Expected {cfg.expected_test_records} Study C test records, found {len(test)}\')\n    overlap = sorted(set(train.global_id) & set(test.global_id))\n    if overlap:\n        raise ValueError(f\'Training/test global_id overlap: {overlap[:10]}\')\n    shared = sorted(set(train.borehole_id) & set(test.borehole_id))\n    if shared:\n        raise ValueError(f\'Study C requires borehole-disjoint training/test datasets; shared boreholes: {shared}\')\n    train[\'source_split\'] = \'train\'\n    test[\'source_split\'] = \'test\'\n    dev = train.copy()\n    cv_data = dev\n    folds = grouped_folds(cv_data, cfg.cv_folds, cfg.tuning_seed)\n    hashes = {key: sha256_file(path) for key, path in paths.items()}\n    source_hash = core_source_hash()\n    contract = dict(\n        revision=REVISION, study=\'C\', config=asdict(cfg), input_sha256=hashes,\n        source_sha256=source_hash,\n        source_snapshot_sha256=hashlib.sha256(CORE_SOURCE.encode()).hexdigest() if \'CORE_SOURCE\' in globals() else sha256_file(__file__),\n        source_artifacts=SOURCE_ARTIFACTS,\n        metric_definitions={\n            \'rmse\': \'sqrt(mean((actual-predicted)^2))\',\n            \'rmse_percent\': \'100*RMSE/mean(abs(actual)) on the declared split\',\n            \'l2\': \'mean((actual-predicted)^2)\',\n            \'standard_deviation\': \'Sample SD across seeded fits/computations, ddof=1\',\n            \'standardized_huber\': \'Huber(delta=1) applied to residual/training_target_SD; SD uses ddof=0\',\n        },\n    )\n    scientific = json.loads(json.dumps(contract, default=json_safe))\n    for key in [\'output_dir\', \'resume\', \'train\', \'test\']:\n        scientific[\'config\'].pop(key, None)\n    signature = hashlib.sha256(json.dumps(scientific, sort_keys=True).encode()).hexdigest()\n    out = Path(cfg.output_dir).expanduser().resolve()\n    out.mkdir(parents=True, exist_ok=True)\n    manifest_file = out / \'run_manifest.json\'\n    if manifest_file.exists():\n        old = json.loads(manifest_file.read_text())\n        if old.get(\'protocol_signature\') != signature:\n            raise ValueError(\'Output directory belongs to a different protocol/code/data version. Choose a new output directory.\')\n        if not cfg.resume and any((out / \'prediction_record\').glob(\'*.csv.gz\')):\n            raise ValueError(\'Existing predictions: enable resume or choose another directory\')\n    contract.update(\n        protocol_signature=signature, status=\'VALIDATED_NOT_FITTED\',\n        validation_time_utc=datetime.now(timezone.utc).isoformat(),\n        input_paths={key: str(path) for key, path in paths.items()},\n        interpretation=\'Within-site evaluation on boreholes excluded from model development; not an independent-site study\',\n        cv_contract=\'Hyperparameters selected by borehole-grouped CV on the training CSV only; final models fit the entire training CSV; no third dataset\',\n        test_contract=\'All supplied test observations are evaluated for every applicable target/missing-type/configuration task; no row selection\',\n        target_scaling=\'TransformedTargetRegressor(StandardScaler): target scaler fitted within each CV training fold and on full training for final fits; predict inverse-transforms before averaging and metrics\',\n        shared_development_test_boreholes=shared, n_shared_boreholes=0,\n        n_training_records=len(train), n_training_boreholes=train.borehole_id.nunique(),\n        n_test_records=len(test), n_test_boreholes=test.borehole_id.nunique(),\n        output_class=\'FULL_STUDY_C_40_SEED\' if cfg.is_full_protocol else \'DIAGNOSTIC_PARTIAL_NOT_MANUSCRIPT_RESULTS\',\n        historical_reproduction=\'New training-only Study C selection; no historical Study C settings or benchmark values were supplied\',\n    )\n    save_json(manifest_file, contract)\n    counts, totals = sample_count_tables(dev, test, cfg)\n    counts.to_csv(out / \'effective_test_counts.csv\', index=False)\n    totals.to_csv(out / \'counts_across_scenarios.csv\', index=False)\n    dependency_report().to_csv(out / \'environment_actual.csv\', index=False)\n    pd.concat([dev[[\'global_id\', \'borehole_id\', \'source_split\']],\n               test[[\'global_id\', \'borehole_id\', \'source_split\']]], ignore_index=True).to_csv(out / \'split_identifiers.csv\', index=False)\n    assignment = []\n    for fold, (_, indices) in enumerate(folds):\n        for _, row in cv_data.iloc[indices].iterrows():\n            assignment.append(dict(global_id=int(row.global_id), borehole_id=int(row.borehole_id),\n                                   source_split=\'train\', fold=fold, seed=cfg.tuning_seed))\n    pd.DataFrame(assignment).to_csv(out / \'cv_fold_identifiers.csv\', index=False)\n    pd.DataFrame([\n        dict(source=\'train\', rows=len(train), boreholes=train.borehole_id.nunique()),\n        dict(source=\'test\', rows=len(test), boreholes=test.borehole_id.nunique()),\n    ]).to_csv(out / \'input_counts.csv\', index=False)\n    features = [{**asdict(task), \'features\': json.dumps(task.features),\n                 \'raw_features\': len(task.features),\n                 \'expanded_features\': _expanded_feature_count(len(task.features), task.polynomial_degree)}\n                for task in study_tasks(cfg)]\n    if not features:\n        raise ValueError(\'Configuration contains no applicable tasks\')\n    pd.DataFrame(features).to_csv(out / \'feature_manifest.csv\', index=False)\n    print(counts[[\'missing_type\', \'target\', \'n_test_records\', \'n_test_boreholes\']].to_string(index=False))\n    print(f\'Training: {len(train)} records in {train.borehole_id.nunique()} boreholes; \'\n          f\'test: {len(test)} records in {test.borehole_id.nunique()} boreholes; shared boreholes: 0. \'\n          \'All test records are reused across missing types.\')\n    return dict(cfg=cfg, out=out, train=train, dev=dev, test=test,\n                cv_data=cv_data, folds=folds, manifest=contract)\n\ndef task_key(task, analysis=\'primary\'):\n    return f\'{analysis}_{task.missing_type}_{task.configuration}_{task.target}\'\n\n\ndef strip_model_prefix(params):\n    return {k.removeprefix(\'regressor__model__\'): v for k,v in params.items()}\n\n\ndef reviewer_extended_search_space(model):\n    # Declared extended search distributions for training-only Study C selection.\n    space=search_space(model,\'expanded\')\n    additions={\n        \'RF\':{\'n_estimators\':[200,500,800,1200],\'max_depth\':[None,5,10,20,40],\n              \'min_samples_split\':[2,5,10,20],\'min_samples_leaf\':[1,2,4,8]},\n        \'GBR\':{\'n_estimators\':[100,200,500,800],\'learning_rate\':[0.01,0.03,0.05,0.10,0.20],\n               \'max_depth\':[1,2,3,5,8],\'min_samples_split\':[2,5,10,20],\n               \'min_samples_leaf\':[1,2,4,8],\'subsample\':[0.6,0.8,1.0]},\n        \'XGB\':{\'n_estimators\':[100,200,500,800],\'learning_rate\':[0.01,0.03,0.05,0.10,0.20],\n               \'max_depth\':[2,3,5,8,12],\'min_child_weight\':[1,3,5,10],\n               \'subsample\':[0.6,0.8,1.0],\'colsample_bytree\':[0.6,0.8,1.0],\n               \'reg_alpha\':[0.0,0.1,1.0],\'reg_lambda\':[0.1,1.0,5.0,10.0]}}\n    space.update({\'regressor__model__\'+k:v for k,v in additions[model].items()})\n    return space\n\n\ndef select_models(ctx, task, analysis=\'primary\'):\n    cfg, out = ctx[\'cfg\'], ctx[\'out\']\n    key = task_key(task, analysis)\n    cache = out / \'selection\' / f\'{key}.json\'\n    if cache.exists():\n        selected = read_locked_json(cache)\n        if selected[\'protocol_signature\'] != ctx[\'manifest\'][\'protocol_signature\']:\n            raise ValueError(\'Settings signature mismatch\')\n    else:\n        results, bounds = [], []\n        selected = dict(protocol_signature=ctx[\'manifest\'][\'protocol_signature\'], models={})\n        X, y = ctx[\'cv_data\'].loc[:, task.features], ctx[\'cv_data\'][task.target]\n        for name in cfg.learners:\n            model = build_estimator(name, task.polynomial_degree, cfg.tuning_seed)\n            space = search_space(name, \'smoke\') if cfg.mode == \'smoke\' else reviewer_extended_search_space(name)\n            if cfg.mode == \'smoke\':\n                space[\'regressor__model__n_estimators\'] = [8]\n            started = time.perf_counter()\n            search = RandomizedSearchCV(\n                model, space, n_iter=min(cfg.search_iterations, len(ParameterGrid(space))),\n                scoring=\'neg_root_mean_squared_error\', cv=ctx[\'folds\'], random_state=cfg.tuning_seed,\n                n_jobs=cfg.n_jobs, refit=False, error_score=\'raise\', return_train_score=True,\n            )\n            search.fit(X, y)\n            raw = strip_model_prefix(search.best_params_)\n            cvpath = out / \'selection\' / f\'{key}_{name}_cv_results.csv\'\n            cvpath.parent.mkdir(parents=True, exist_ok=True)\n            pd.DataFrame(search.cv_results_).to_csv(cvpath, index=False)\n            selected[\'models\'][name] = dict(\n                parameters=raw, best_cv_neg_rmse=float(search.best_score_),\n                selection_status=\'Training-only borehole-grouped CV; choices locked before test prediction\',\n                n_candidates=len(search.cv_results_[\'params\']), seconds=time.perf_counter() - started,\n                polynomial_degree=task.polynomial_degree, raw_features=list(task.features), cv_policy=cfg.cv_policy,\n            )\n            fullspace = strip_model_prefix(space)\n            for param, value in raw.items():\n                values = fullspace.get(param, [])\n                numeric = [v for v in values if isinstance(v, (int, float)) and not isinstance(v, bool)]\n                bounds.append(dict(\n                    analysis=analysis, missing_type=task.missing_type, configuration=task.configuration,\n                    target=task.target, model=name, parameter=param, value=json.dumps(value),\n                    search_values=json.dumps(values),\n                    at_numeric_boundary=bool(numeric and value in [min(numeric), max(numeric)]),\n                    interpretation=\'Boundary relative to the declared search distribution; inspect training-only CV logs\',\n                ))\n            results.append(dict(analysis=analysis, missing_type=task.missing_type,\n                                configuration=task.configuration, target=task.target, model=name,\n                                **selected[\'models\'][name]))\n        save_locked_json(cache, selected)\n        pd.DataFrame(results).to_csv(out / \'selection\' / f\'{key}_selected.csv\', index=False)\n        pd.DataFrame(bounds).to_csv(out / \'selection\' / f\'{key}_boundaries.csv\', index=False)\n    estimators = {}\n    for name, record in selected[\'models\'].items():\n        estimator = build_estimator(name, task.polynomial_degree, cfg.tuning_seed)\n        estimator.set_params(**{\'regressor__model__\' + k: v for k, v in record[\'parameters\'].items()})\n        estimators[name] = estimator\n    return estimators\n\n\ndef prediction_path(ctx,task,seed,analysis=\'primary\',kind=\'learners\'):\n    return ctx[\'out\']/\'prediction_record\'/f\'{task_key(task,analysis)}_{kind}_seed{seed}.csv.gz\'\n\n\ndef write_prediction_part(ctx,path,frame):\n    path.parent.mkdir(parents=True,exist_ok=True)\n    if frame[[\'seed\',\'split\',\'global_id\']].duplicated().any(): raise ValueError(\'Duplicate prediction keys\')\n    frame[\'protocol_signature\']=ctx[\'manifest\'][\'protocol_signature\']\n    frame[\'study\']=\'C\'\n    frame[\'output_class\']=ctx[\'manifest\'][\'output_class\']\n    tmp=path.with_name(path.name+\'.tmp\')\n    frame.to_csv(tmp,index=False,compression=\'gzip\',float_format=\'%.17g\')\n    tmp.replace(path)\n    save_json(path.with_name(path.name+\'.sha256.json\'),dict(sha256=sha256_file(path),rows=len(frame),protocol_signature=ctx[\'manifest\'][\'protocol_signature\']))\n\n\ndef read_prediction_part(ctx,path):\n    receipt=path.with_name(path.name+\'.sha256.json\')\n    if not receipt.exists(): raise ValueError(f\'Missing prediction integrity record: {path.name}\')\n    meta=json.loads(receipt.read_text())\n    if meta[\'protocol_signature\']!=ctx[\'manifest\'][\'protocol_signature\'] or sha256_file(path)!=meta[\'sha256\']: raise ValueError(f\'Prediction integrity check failed: {path.name}\')\n    frame=pd.read_csv(path)\n    if len(frame)!=meta[\'rows\'] or set(frame.protocol_signature)!={ctx[\'manifest\'][\'protocol_signature\']}: raise ValueError(\'Prediction lineage mismatch\')\n    return frame\n\n\ndef base_prediction_frame(ctx, task, seed, analysis, split, frame):\n    scale = float(ctx[\'dev\'][task.target].std(ddof=0))\n    if scale <= 0:\n        scale = 1.0\n    return pd.DataFrame(dict(\n        analysis=analysis, missing_type=task.missing_type, configuration=task.configuration,\n        target=task.target, seed=seed, split=split, global_id=frame.global_id.to_numpy(),\n        borehole_id=frame.borehole_id.to_numpy(), actual=frame[task.target].to_numpy(float),\n        target_scale=scale, polynomial_degree=task.polynomial_degree,\n    ))\n\n\ndef fit_learner_task(ctx,task,analysis=\'primary\'):\n    cfg=ctx[\'cfg\']; models=select_models(ctx,task,analysis)\n    dev=ctx[\'dev\'];ev=selected_test(ctx[\'test\'],task.missing_type)\n    for seed in range(cfg.base_seed,cfg.base_seed+cfg.runs):\n        path=prediction_path(ctx,task,seed,analysis)\n        modelpath=ctx[\'out\']/\'models\'/f\'{task_key(task,analysis)}_seed{seed}.joblib\'\n        if path.exists() and (not cfg.save_representative_models or seed!=cfg.representative_seed or modelpath.exists()):\n            read_prediction_part(ctx,path);continue\n        records={s:base_prediction_frame(ctx,task,seed,analysis,s,f) for s,f in [(\'Development\',dev),(\'Test\',ev)]}\n        fitted={}\n        for name,template in models.items():\n            estimator=clone(template)\n            estimator.set_params(**{k:seed for k in estimator.get_params() if k.endswith(\'random_state\')})\n            start=time.perf_counter();estimator.fit(dev.loc[:,task.features],dev[task.target]);elapsed=time.perf_counter()-start\n            for split,f in [(\'Development\',dev),(\'Test\',ev)]:\n                records[split][\'prediction_\'+name]=estimator.predict(f.loc[:,task.features])\n            fitted[name]=estimator\n            timing=ctx[\'out\']/\'timing\';timing.mkdir(exist_ok=True)\n            save_json(timing/f\'{task_key(task,analysis)}_{name}_{seed}.json\',dict(analysis=analysis,missing_type=task.missing_type,configuration=task.configuration,target=task.target,model=name,seed=seed,fit_seconds=elapsed))\n        for split in records:\n            records[split][\'prediction_\'+cfg.ensemble_label]=records[split][[\'prediction_\'+n for n in cfg.learners]].mean(axis=1)\n        if cfg.save_representative_models and seed==cfg.representative_seed:\n            modelpath.parent.mkdir(exist_ok=True)\n            joblib.dump(dict(models=fitted,features=list(task.features),task=asdict(task),analysis=analysis,seed=seed,\n                       protocol_signature=ctx[\'manifest\'][\'protocol_signature\']),modelpath)\n        write_prediction_part(ctx,path,pd.concat(records.values(),ignore_index=True))\n        print(f\'{analysis}: {task.missing_type} {task.configuration} {task.target}, seed {seed}\',flush=True)\n\n\ndef linear_fit(x,y):\n    x=np.asarray(x,float);y=np.asarray(y,float)\n    if len(x)<2 or np.ptp(x)<=np.finfo(float).eps: return np.nan,np.nan\n    slope=float(np.dot(x-x.mean(),y-y.mean())/np.dot(x-x.mean(),x-x.mean()))\n    return slope,float(y.mean()-slope*x.mean())\n\n\ndef metrics_from_arrays(actual,predicted,target_scale,delta):\n    a=np.asarray(actual,float);p=np.asarray(predicted,float);r=a-p\n    mse=float(np.mean(r*r)); rmse=float(np.sqrt(mse)); denom=float(np.mean(np.abs(a)))\n    cal_slope,cal_intercept=linear_fit(p,a)  # observed = intercept + slope * predicted\n    trend_slope,trend_intercept=linear_fit(a,p)\n    return dict(rmse=rmse,rmse_percent=100*rmse/denom if denom else np.nan,l2=mse,\n                robust_l2=robust_l2(a,p,delta),robust_l2_standardized=robust_l2(a/target_scale,p/target_scale,1.0),\n                mae=float(np.mean(np.abs(r))),bias=float(np.mean(p-a)),\n                r2=float(r2_score(a,p)) if len(a)>1 and np.ptp(a)>0 else np.nan,\n                calibration_slope_observed_on_predicted=cal_slope,calibration_intercept_observed_on_predicted=cal_intercept,\n                trend_slope_predicted_on_observed=trend_slope,trend_intercept_predicted_on_observed=trend_intercept,\n                trend_angle_deviation_from_45_deg=float(abs(np.degrees(np.arctan(trend_slope))-45)))\n\n\ndef derive_run_metrics(ctx):\n    rows=[];index=[];cfg=ctx[\'cfg\']\n    for path in sorted((ctx[\'out\']/\'prediction_record\').glob(\'*.csv.gz\')):\n        f=read_prediction_part(ctx,path)\n        index.append(dict(file=path.name,sha256=sha256_file(path),rows=len(f),protocol_signature=ctx[\'manifest\'][\'protocol_signature\']))\n        for split,g in f.groupby(\'split\',sort=False):\n            key={k:g.iloc[0][k] for k in [\'analysis\',\'missing_type\',\'configuration\',\'target\',\'seed\',\'study\',\'output_class\']}\n            key.update(split=split,n_records=len(g),n_boreholes=g.borehole_id.nunique())\n            for col in [c for c in g if c.startswith(\'prediction_\')]:\n                if g[col].isna().any(): raise ValueError(\'Missing predictions\')\n                rows.append(dict(**key,model=col.removeprefix(\'prediction_\'),**metrics_from_arrays(g.actual,g[col],float(g.target_scale.iloc[0]),cfg.robust_delta)))\n    result=pd.DataFrame(rows)\n    if result.empty: raise ValueError(\'No prediction records exist\')\n    unique=[\'analysis\',\'missing_type\',\'configuration\',\'target\',\'seed\',\'split\',\'model\']\n    if result.duplicated(unique).any(): raise ValueError(\'Duplicated model/run/split metric rows\')\n    for _,g in result.groupby(unique[:-3]+[\'split\',\'model\'],sort=False):\n        if set(g.seed)!=set(range(cfg.base_seed,cfg.base_seed+cfg.runs)): raise ValueError(\'Incomplete seed set\')\n    pd.DataFrame(index).to_csv(ctx[\'out\']/\'prediction_record_index.csv\',index=False)\n    result.to_csv(ctx[\'out\']/\'run_metrics_from_predictions.csv\',index=False)\n    return result\n\nMETRIC_NAMES=[\'rmse\',\'rmse_percent\',\'l2\',\'robust_l2\',\'robust_l2_standardized\',\'mae\',\'bias\',\'r2\',\n              \'calibration_slope_observed_on_predicted\',\'calibration_intercept_observed_on_predicted\',\n              \'trend_slope_predicted_on_observed\',\'trend_intercept_predicted_on_observed\',\'trend_angle_deviation_from_45_deg\']\n\n\ndef summarize_run_metrics(metrics):\n    keys=[\'analysis\',\'missing_type\',\'configuration\',\'target\',\'model\',\'split\',\'n_records\',\'n_boreholes\']\n    rows=[]\n    for values,g in metrics.groupby(keys,sort=False):\n        row=dict(zip(keys,values));row[\'runs\']=len(g)\n        for metric in METRIC_NAMES:\n            v=g[metric].to_numpy(float);row[metric+\'_mean\']=float(np.mean(v));row[metric+\'_sd\']=float(np.std(v,ddof=1)) if len(v)>1 else np.nan\n        rows.append(row)\n    return pd.DataFrame(rows)\n\ndef heuristic_variogram(coords,values,seed,cfg,range_quantile=None,nugget_fraction=None):\n    # This is a coordinate-distance heuristic, NOT an empirical target-semivariance fit.\n    rng=np.random.default_rng(seed);n=len(coords)\n    n_pairs=min(cfg.pair_sample,max(1,n*(n-1)//2))\n    a=rng.integers(0,n,size=n_pairs);b=rng.integers(0,n,size=n_pairs)\n    dist=np.linalg.norm(coords[a[a!=b]]-coords[b[a!=b]],axis=1);dist=dist[dist>0]\n    if not len(dist): raise ValueError(\'No nonzero coordinate distances\')\n    q=cfg.range_quantile if range_quantile is None else range_quantile\n    nf=cfg.nugget_fraction if nugget_fraction is None else nugget_fraction\n    var=max(float(np.var(values,ddof=1)),np.finfo(float).eps)\n    return dict(range=max(float(np.quantile(dist,q)),np.finfo(float).eps),partial_sill=max(var*(1-nf),np.finfo(float).eps),nugget=var*nf)\n\n\ndef krige(dev,values,ev,seed,cfg,q=None,nf=None,neighbors=None):\n    scaler=StandardScaler().fit(dev[SPATIAL_COORDINATES]);dc=scaler.transform(dev[SPATIAL_COORDINATES]);ec=scaler.transform(ev[SPATIAL_COORDINATES])\n    variogram=heuristic_variogram(dc,values,seed,cfg,q,nf)\n    p=local_ordinary_kriging_predict(dc,np.asarray(values,float),ec,neighbors or cfg.ok_neighbors,variogram)\n    return p,dict(variogram=variogram,range_quantile=cfg.range_quantile if q is None else q,\n                  nugget_fraction=cfg.nugget_fraction if nf is None else nf,neighbors=min(neighbors or cfg.ok_neighbors,len(dev)),\n                  coordinate_mean=scaler.mean_.tolist(),coordinate_scale=scaler.scale_.tolist(),\n                  variogram_estimation=\'Spherical distance-quantile heuristic; not fitted to empirical target semivariances\')\n\n\ndef ridge_pipeline(task,alpha):\n    return Pipeline([(\'poly\',PolynomialFeatures(degree=task.polynomial_degree,include_bias=False)),(\'scale\',StandardScaler()),(\'ridge\',Ridge(alpha=alpha))])\n\n\ndef nonspatial_features(task):\n    return [f for f in task.features if f not in SPATIAL_COORDINATES]\n\n\ndef select_ridge_alpha(ctx,task):\n    key=task_key(task);file=ctx[\'out\']/\'selection\'/f\'{key}_RK_alpha.json\';cfg=ctx[\'cfg\']\n    if file.exists(): return float(read_locked_json(file)[\'ridge_alpha\'])\n    f=nonspatial_features(task);data=ctx[\'cv_data\']\n    search=GridSearchCV(ridge_pipeline(task,1),{\'ridge__alpha\':list(cfg.ridge_alphas)},\n                cv=ctx[\'folds\'],scoring=\'neg_root_mean_squared_error\',n_jobs=cfg.n_jobs,error_score=\'raise\',refit=False)\n    search.fit(data[f],data[task.target]);alpha=float(search.best_params_[\'ridge__alpha\'])\n    pd.DataFrame(search.cv_results_).to_csv(file.with_suffix(\'.csv\'),index=False)\n    save_locked_json(file,dict(ridge_alpha=alpha,selection=\'Development-only grouped CV for trend RMSE, not joint RK optimization\',\n                       best_cv_neg_rmse=float(search.best_score_),features=f,polynomial_degree=task.polynomial_degree))\n    return alpha\n\n\ndef rk_predict(ctx,task,dev,ev,seed,alpha,q=None,nf=None,neighbors=None):\n    cfg=ctx[\'cfg\'];features=nonspatial_features(task);folds=grouped_folds(dev,cfg.cv_folds,seed)\n    trend=ridge_pipeline(task,alpha)\n    oof=cross_val_predict(trend,dev[features],dev[task.target],cv=folds,n_jobs=cfg.n_jobs,method=\'predict\')\n    residual=dev[task.target].to_numpy(float)-oof\n    trend.fit(dev[features],dev[task.target]);base=trend.predict(ev[features])\n    correction,meta=krige(dev,residual,ev,seed,cfg,q,nf,neighbors)\n    meta.update(ridge_alpha=alpha,residual_basis=\'Borehole-grouped out-of-fold development residuals\',seed=seed)\n    return base+correction,meta\n\n\ndef fit_comparators(ctx):\n    cfg=ctx[\'cfg\'];dev=ctx[\'dev\'];test=ctx[\'test\']\n    xyz=[t for t in study_tasks(cfg) if t.configuration==\'XYZ\']\n    if not xyz: return\n    meta_dir=ctx[\'out\']/\'comparator_metadata\';meta_dir.mkdir(exist_ok=True)\n    for task in xyz:\n        alpha=select_ridge_alpha(ctx,task);ev=selected_test(test,task.missing_type)\n        for seed in range(cfg.base_seed,cfg.base_seed+cfg.runs):\n            path=prediction_path(ctx,task,seed,kind=\'comparators\')\n            if path.exists():read_prediction_part(ctx,path);continue\n            # Cache a coordinate-only prediction for ALL supplied test observations per target/seed.\n            # All missing types reuse exactly the same test observations and OK prediction record.\n            cache=meta_dir/f\'OK_all_test_{task.target}_{seed}.csv\'\n            if cache.exists():\n                ok_meta=json.loads(cache.with_suffix(\'.json\').read_text())\n                if ok_meta.get(\'prediction_sha256\')!=sha256_file(cache):raise ValueError(\'Cached OK prediction integrity check failed\')\n                okall=pd.read_csv(cache)\n            else:\n                yp,meta=krige(dev,dev[task.target],test,seed,cfg)\n                okall=pd.DataFrame(dict(global_id=test.global_id,prediction_OK=yp));okall.to_csv(cache,index=False,float_format=\'%.17g\')\n                save_json(cache.with_suffix(\'.json\'),dict(**meta,target=task.target,seed=seed,global_ids=test.global_id.tolist(),prediction_sha256=sha256_file(cache),\n                    development_ids_sha256=hashlib.sha256(dev.global_id.to_numpy().tobytes()).hexdigest(),\n                    rule=\'Identical test observations and OK predictions for every missing type; target/seed RMSE must be invariant\'))\n            ok=ev[[\'global_id\']].merge(okall,on=\'global_id\',how=\'left\',validate=\'one_to_one\').prediction_OK.to_numpy(float)\n            rk,meta=rk_predict(ctx,task,dev,ev,seed,alpha)\n            save_json(meta_dir/f\'{task_key(task)}_RK_{seed}.json\',meta)\n            f=base_prediction_frame(ctx,task,seed,\'primary\',\'Test\',ev);f[\'prediction_OK\']=ok;f[\'prediction_RK\']=rk\n            write_prediction_part(ctx,path,f)\n            print(f\'Comparators: {task.missing_type} {task.target}, seed {seed}\',flush=True)\n    fold_dir=ctx[\'out\']/\'comparator_folds\';fold_dir.mkdir(exist_ok=True)\n    for seed in range(cfg.base_seed,cfg.base_seed+cfg.runs):\n        foldids=np.empty(len(dev),int)\n        for i,(_,vi) in enumerate(grouped_folds(dev,cfg.cv_folds,seed)):foldids[vi]=i\n        pd.DataFrame(dict(global_id=dev.global_id,borehole_id=dev.borehole_id,fold=foldids,seed=seed)).to_csv(fold_dir/f\'RK_oof_seed{seed}.csv\',index=False)\n\n\ndef development_variogram_sensitivity(ctx):\n    cfg=ctx[\'cfg\'];out=ctx[\'out\'];cache=out/\'development_variogram_sensitivity.csv\'\n    if cache.exists():return pd.read_csv(cache)\n    data=ctx[\'cv_data\'];tr,vi=ctx[\'folds\'][0];dev=data.iloc[tr].reset_index(drop=True);ev=data.iloc[vi].reset_index(drop=True)\n    if len(ev)>100:ev=ev.iloc[np.sort(np.random.default_rng(cfg.sensitivity_seed).choice(len(ev),100,replace=False))].reset_index(drop=True)\n    assert not set(dev.borehole_id)&set(ev.borehole_id)\n    ev[[\'global_id\',\'borehole_id\']].to_csv(out/\'sensitivity_development_holdout_ids.csv\',index=False)\n    dev[[\'global_id\',\'borehole_id\']].to_csv(out/\'sensitivity_development_training_ids.csv\',index=False)\n    rows=[]\n    for task in [t for t in study_tasks(cfg) if t.configuration==\'XYZ\']:\n        features=nonspatial_features(task)\n        # Sensitivity holdout cannot influence ridge tuning, coordinate scaling, or residual fitting.\n        inner=grouped_folds(dev,cfg.cv_folds,cfg.tuning_seed)\n        search=GridSearchCV(ridge_pipeline(task,1),{\'ridge__alpha\':list(cfg.ridge_alphas)},cv=inner,\n               scoring=\'neg_root_mean_squared_error\',n_jobs=cfg.n_jobs,error_score=\'raise\')\n        search.fit(dev[features],dev[task.target]);alpha=search.best_params_[\'ridge__alpha\']\n        oof=cross_val_predict(ridge_pipeline(task,alpha),dev[features],dev[task.target],cv=inner,n_jobs=cfg.n_jobs)\n        residual=dev[task.target].to_numpy()-oof;trend=search.predict(ev[features])\n        for q,nf in itertools.product([0.5,0.75,0.9],[0.0,0.05,0.10]):\n            for method,values,base in [(\'OK\',dev[task.target],0.0),(\'RK\',residual,trend)]:\n                yp,meta=krige(dev,values,ev,cfg.sensitivity_seed,cfg,q,nf,cfg.sensitivity_neighbors)\n                rows.append(dict(missing_type=task.missing_type,target=task.target,model=method,range_quantile=q,nugget_fraction=nf,\n                    neighbors=cfg.sensitivity_neighbors,ridge_alpha=alpha if method==\'RK\' else np.nan,\n                    development_holdout_rmse=float(np.sqrt(np.mean((ev[task.target].to_numpy()-yp-base)**2))),\n                    n_holdout_records=len(ev),n_holdout_boreholes=ev.borehole_id.nunique(),\n                    purpose=\'Limited development-only sensitivity; does not change primary settings; not full variogram model selection\'))\n    result=pd.DataFrame(rows);result.to_csv(cache,index=False);return result\n\ndef test_prediction_records(ctx,analysis=\'primary\'):\n    frames=[]\n    for path in sorted((ctx[\'out\']/\'prediction_record\').glob(f\'{analysis}_*_learners_seed*.csv.gz\')):\n        f=read_prediction_part(ctx,path);frames.append(f.loc[f.split==\'Test\'])\n    return pd.concat(frames,ignore_index=True) if frames else pd.DataFrame()\n\n\ndef fitting_stability(metrics,ctx):\n    cfg=ctx[\'cfg\'];m=metrics.loc[(metrics.model==cfg.ensemble_label)&(metrics.split==\'Test\')]\n    rows=[];improvements=[]\n    for (analysis,mt,target),block in m.groupby([\'analysis\',\'missing_type\',\'target\'],sort=False):\n        base=block.loc[block.configuration==\'NoSpatial\'].set_index(\'seed\')\n        if base.empty:continue\n        for conf,g in block.loc[block.configuration!=\'NoSpatial\'].groupby(\'configuration\',sort=False):\n            g=g.set_index(\'seed\').sort_index();base=base.sort_index()\n            if not g.index.equals(base.index):raise ValueError(\'Unmatched seeds in paired comparison\')\n            delta=g.rmse.to_numpy()-base.rmse.to_numpy()\n            p=1.0;stat=0.0\n            if len(delta)>1 and not np.all(delta==0):\n                w=wilcoxon(delta,alternative=\'two-sided\',zero_method=\'wilcox\');p=float(w.pvalue);stat=float(w.statistic)\n            sd=float(np.std(delta,ddof=1)) if len(delta)>1 else np.nan\n            ratios=np.where(base.rmse.to_numpy()>0,-100*delta/base.rmse.to_numpy(),np.nan)\n            rows.append(dict(analysis=analysis,missing_type=mt,target=target,configuration=conf,paired_seeds=len(delta),\n                n_test_records=int(g.n_records.iloc[0]),n_test_boreholes=int(g.n_boreholes.iloc[0]),\n                mean_rmse_difference=float(np.mean(delta)),median_rmse_difference=float(np.median(delta)),\n                sd_difference=sd,dz=float(np.mean(delta)/sd) if sd>0 else np.nan,wilcoxon_statistic=stat,p_value=p,\n                mean_runwise_improvement_percent=float(np.mean(ratios)),sd_runwise_improvement_percent=float(np.std(ratios,ddof=1)) if len(ratios)>1 else np.nan,\n                improvement_from_displayed_means_percent=float(100*(base.rmse.mean()-g.rmse.mean())/base.rmse.mean()) if base.rmse.mean()>0 else np.nan,\n                inference_scope=\'Stochastic fitting on fixed held-out cases; not borehole sampling uncertainty\'))\n            for seed,ratio in zip(g.index,ratios):improvements.append(dict(analysis=analysis,missing_type=mt,target=target,configuration=conf,seed=seed,improvement_percent=ratio))\n    result=pd.DataFrame(rows)\n    if len(result):\n        result[\'p_holm\']=np.nan\n        for analysis,indices in result.groupby(\'analysis\').groups.items():result.loc[indices,\'p_holm\']=holm_adjust(result.loc[indices,\'p_value\'].to_numpy())\n        result[\'significant_fitting_holm_005\']=result.p_holm<0.05\n        result[\'holm_family\']=\'All available Study C spatial-vs-baseline tasks within this analysis; complete primary protocol has 42 comparisons\'\n    pd.DataFrame(improvements).to_csv(ctx[\'out\']/\'improvement_by_seed.csv\',index=False)\n    result.to_csv(ctx[\'out\']/\'fitting_stability_wilcoxon_holm.csv\',index=False)\n    return result\n\n\ndef borehole_bootstrap(ctx,analysis=\'primary\'):\n    cfg=ctx[\'cfg\'];f=test_prediction_records(ctx,analysis);rows=[]\n    if f.empty:return pd.DataFrame()\n    col=\'prediction_\'+cfg.ensemble_label\n    for (mt,target),block in f.groupby([\'missing_type\',\'target\'],sort=False):\n        base=block.loc[block.configuration==\'NoSpatial\']\n        if base.empty:continue\n        ids=sorted(base.global_id.unique());seeds=list(range(cfg.base_seed,cfg.base_seed+cfg.runs))\n        info=base.loc[base.seed==seeds[0]].set_index(\'global_id\').loc[ids]\n        truth=info.actual.to_numpy();holes=info.borehole_id.to_numpy();unique_holes=np.unique(holes);h=len(unique_holes)\n        # Same borehole multiplicities are used for every seed and configuration.\n        rng=np.random.default_rng(cfg.bootstrap_seed+MISSING_TYPE_ORDER.index(mt)*100+TARGET_ORDER.index(target))\n        multiplicities=rng.multinomial(h,np.full(h,1/h),size=cfg.bootstrap_replicates)\n        weights=multiplicities[:,np.searchsorted(unique_holes,holes)].astype(float)\n        denominator=weights.sum(axis=1)\n        base_matrix=base.pivot(index=\'global_id\',columns=\'seed\',values=col).loc[ids,seeds].to_numpy()\n        base_sq=(base_matrix-truth[:,None])**2\n        base_rmse=np.sqrt((weights@base_sq)/denominator[:,None]);base_stat=base_rmse.mean(axis=1)\n        for conf,g in block.groupby(\'configuration\',sort=False):\n            pred=g.pivot(index=\'global_id\',columns=\'seed\',values=col).loc[ids,seeds].to_numpy()\n            if not np.allclose(g.loc[g.seed==seeds[0]].set_index(\'global_id\').loc[ids].actual,truth):raise ValueError(\'Unmatched bootstrap truth\')\n            rmse=np.sqrt((weights@((pred-truth[:,None])**2))/denominator[:,None]);stat=rmse.mean(axis=1)\n            diff=(rmse-base_rmse).mean(axis=1)\n            ratio=np.mean(np.divide(100*(base_rmse-rmse),base_rmse,out=np.full_like(rmse,np.nan),where=base_rmse>0),axis=1)\n            lo,hi=np.quantile(stat,[.025,.975]) if h>=2 else (np.nan,np.nan)\n            dl,dh=np.quantile(diff,[.025,.975]) if h>=2 else (np.nan,np.nan)\n            finite=ratio[np.isfinite(ratio)];rl,rh=np.quantile(finite,[.025,.975]) if h>=2 and len(finite) else (np.nan,np.nan)\n            point=np.sqrt(np.mean((pred-truth[:,None])**2,axis=0))\n            rows.append(dict(analysis=analysis,missing_type=mt,target=target,configuration=conf,n_test_records=len(ids),n_test_boreholes=h,\n                seeds_averaged=len(seeds),bootstrap_replicates=cfg.bootstrap_replicates,bootstrap_seed=cfg.bootstrap_seed,\n                estimand=\'Mean of seed-specific RMSEs; observations pooled within each sampled borehole multiset\',\n                rmse_point=float(point.mean()),rmse_ci95_low=lo,rmse_ci95_high=hi,\n                paired_rmse_difference_ci95_low=dl,paired_rmse_difference_ci95_high=dh,\n                paired_improvement_percent_ci95_low=rl,paired_improvement_percent_ci95_high=rh,\n                inference_scope=\'Percentile borehole-cluster bootstrap conditional on fitted models and observed test boreholes; no development refitting or independent-site inference\',\n                caution=\'Only \'+str(h)+\' test boreholes; interval support is limited and does not remedy the small evaluation set\'))\n    result=pd.DataFrame(rows);result.to_csv(ctx[\'out\']/f\'{analysis}_borehole_bootstrap.csv\',index=False);return result\n\ndef train_test_gaps(metrics,ctx):\n    keys=[\'analysis\',\'missing_type\',\'configuration\',\'target\',\'seed\',\'model\']\n    wide=metrics.pivot(index=keys,columns=\'split\',values=\'rmse\').reset_index()\n    if \'Development\' not in wide or \'Test\' not in wide:return pd.DataFrame()\n    wide=wide.dropna(subset=[\'Development\',\'Test\']);wide[\'test_minus_development_rmse\']=wide.Test-wide.Development\n    wide[\'test_to_development_rmse_ratio\']=np.divide(wide.Test,wide.Development,out=np.full(len(wide),np.nan),where=wide.Development>0)\n    wide[\'interpretation\']=\'Large ratios can reflect low training error; compare absolute held-out RMSE before inferring inferior prediction\'\n    wide.to_csv(ctx[\'out\']/\'train_test_gap_by_seed.csv\',index=False)\n    return wide\n\n\ndef constituent_diagnostics(ctx,metrics):\n    f=test_prediction_records(ctx);rows=[];models=ctx[\'cfg\'].learners\n    for (mt,conf,target,seed),g in f.groupby([\'missing_type\',\'configuration\',\'target\',\'seed\'],sort=False):\n        for a,b in itertools.combinations(models,2):\n            x=g[\'prediction_\'+a]-g.actual;y=g[\'prediction_\'+b]-g.actual\n            corr=float(np.corrcoef(x,y)[0,1]) if x.std()>0 and y.std()>0 else np.nan\n            rows.append(dict(missing_type=mt,configuration=conf,target=target,seed=seed,learner_a=a,learner_b=b,\n                             n_test_records=len(g),n_test_boreholes=g.borehole_id.nunique(),error_correlation=corr,\n                             scope=\'Correlation across fixed held-out observations within this seed; tiny n limits interpretation\'))\n    corr=pd.DataFrame(rows);corr.to_csv(ctx[\'out\']/\'learner_error_correlations_by_seed.csv\',index=False)\n    m=metrics.loc[(metrics.analysis==\'primary\')&(metrics.split==\'Test\')&(metrics.configuration==\'XYZ\')&(metrics.model.isin(list(models)+[ctx[\'cfg\'].ensemble_label]))]\n    scores=[]\n    for (mt,target),g in m.groupby([\'missing_type\',\'target\'],sort=False):\n        means=g.groupby(\'model\').rmse.mean();best=means.loc[list(models)].min()\n        for model,value in means.items():scores.append(dict(missing_type=mt,target=target,model=model,mean_rmse=value,\n            relative_rmse_to_best_constituent=value/best if best>0 else np.nan,\n            lowest_displayed_mean=bool(value<=means.min()),interpretation=\'Descriptive comparison; held-out results do not change the prespecified ensemble rule\'))\n    result=pd.DataFrame(scores);result.to_csv(ctx[\'out\']/\'ensemble_robustness_by_task.csv\',index=False)\n    return corr,result\n\n\ndef polynomial_ablation_summary(metrics,ctx):\n    m=metrics.loc[(metrics.model==ctx[\'cfg\'].ensemble_label)&(metrics.split==\'Test\')]\n    a=m.loc[m.analysis==\'primary\'];b=m.loc[m.analysis==\'no_polynomial\']\n    keys=[\'missing_type\',\'configuration\',\'target\',\'seed\']\n    if b.empty:return pd.DataFrame()\n    merged=a[keys+[\'rmse\']].merge(b[keys+[\'rmse\']],on=keys,suffixes=(\'_expanded\',\'_no_polynomial\'),validate=\'one_to_one\')\n    merged[\'expanded_minus_unexpanded_rmse\']=merged.rmse_expanded-merged.rmse_no_polynomial\n    merged[\'scope\']=\'MT2-MT4 only; MT1 is already degree 1. Same cases/seeds. Both degrees use matched training-only search spaces and candidate budgets; engineered inputs remain present.\'\n    merged.to_csv(ctx[\'out\']/\'polynomial_ablation_paired.csv\',index=False);return merged\n\ndef write_table(ctx,name,frame,caption):\n    dest=ctx[\'out\']/\'tables\';dest.mkdir(exist_ok=True)\n    if ctx[\'manifest\'][\'output_class\']!=\'FULL_STUDY_C_40_SEED\':\n        frame=frame.copy();frame.insert(0,\'Output class\',ctx[\'manifest\'][\'output_class\'])\n        caption=ctx[\'manifest\'][\'output_class\']+\'. \'+caption\n    frame.to_csv(dest/(name+\'.csv\'),index=False)\n    def esc(value):\n        if value is None or (not isinstance(value,(dict,list,tuple)) and pd.isna(value)):return \'\'\n        mapping={\'\\\\\':r\'\\textbackslash{}\',\'&\':r\'\\&\',\'%\':r\'\\%\',\'_\':r\'\\_\',\n                 \'#\':r\'\\#\',\'$\':r\'\\$\',\'{\':r\'\\{\',\'}\':r\'\\}\'}\n        return \'\'.join(mapping.get(char,char) for char in str(value))\n    lines=[r\'% Requires graphicx. Detailed CSV accompanies this table.\',r\'\\begin{table*}[htbp]\',\n           r\'\\centering\',r\'\\caption{\'+esc(caption)+\'}\',r\'\\resizebox{\\textwidth}{!}{%\',\n           r\'\\begin{tabular}{\'+\'l\'*len(frame.columns)+\'}\',r\'\\hline\',\n           \' & \'.join(esc(c) for c in frame.columns)+r\' \\\\\',r\'\\hline\']\n    lines+=[\' & \'.join(esc(v) for v in row)+r\' \\\\\' for row in frame.itertuples(index=False,name=None)]\n    lines += [r\'\\hline\',r\'\\end{tabular}\',r\'}\',r\'\\end{table*}\']\n    (dest/(name+\'.tex\')).write_text(\'\\n\'.join(lines),encoding=\'utf-8\')\n    return frame\n\n\ndef formatted(mean,sd,target=\'\'):\n    digits=4 if target==\'Cc\' else 3\n    return f\'{mean:.{digits}f} +/- {sd:.{digits}f}\' if np.isfinite(sd) else f\'{mean:.{digits}f} (SD unavailable)\'\n\n\ndef performance_table(summary,mts,ctx):\n    cfg=ctx[\'cfg\'];s=summary.loc[(summary.analysis==\'primary\')&(summary.model==cfg.ensemble_label)&(summary.missing_type.isin(mts))]\n    rows=[]\n    for mt in mts:\n        for target in MISSINGNESS_PATTERNS[mt][\'targets\']:\n            for conf in CONFIG_ORDER:\n                g=s.loc[(s.missing_type==mt)&(s.target==target)&(s.configuration==conf)]\n                if g.empty:continue\n                te=g.loc[g.split==\'Test\'].iloc[0];row={\'Study\':\'C\',\'Missing Type\':mt,\'Target\':target,\'Configuration\':CONFIG_LABELS[conf],\n                     \'Test records\':int(te.n_records),\'Test boreholes\':int(te.n_boreholes),\'Runs\':int(te.runs)}\n                for _,v in g.iterrows():\n                    for metric,label in [(\'rmse\',\'RMSE\'),(\'rmse_percent\',\'RMSE%\'),(\'l2\',\'L2\'),(\'robust_l2\',\'Robust L2\')]:\n                        row[f\'{v.split} {label}\']=formatted(v[metric+\'_mean\'],v[metric+\'_sd\'],target)\n                rows.append(row)\n    return pd.DataFrame(rows)\n\n\ndef table7(ctx, summary):\n    """Export Study C comparisons without importing Study A published values."""\n    s = summary.loc[(summary.analysis == \'primary\') & (summary.split == \'Test\')]\n    rows = []\n    for mt in MISSING_TYPE_ORDER:\n        for target in MISSINGNESS_PATTERNS[mt][\'targets\']:\n            group = s.loc[(s.missing_type == mt) & (s.target == target)]\n            if group.empty:\n                continue\n            row = {\'Study\': \'C\', \'Missing Type\': mt, \'Target\': target}\n            for conf, method, label in [\n                (\'NoSpatial\', ctx[\'cfg\'].ensemble_label, \'Without Spatial\'),\n                (\'XYZ\', ctx[\'cfg\'].ensemble_label, \'XYZ\'),\n                (\'XYZ\', \'OK\', \'Ordinary Kriging\'), (\'XYZ\', \'RK\', \'Regression Kriging\'),\n            ]:\n                match = group.loc[(group.configuration == conf) & (group.model == method)]\n                if not match.empty:\n                    value = match.iloc[0]\n                    row[label] = formatted(value.rmse_mean, value.rmse_sd, target)\n                    row[\'Test records\'] = int(value.n_records)\n                    row[\'Test boreholes\'] = int(value.n_boreholes)\n                    row[\'Refit runs\'] = int(value.runs)\n            rows.append(row)\n    write_table(ctx, \'StudyC_comparisons\', pd.DataFrame(rows),\n                \'Study C test RMSE from the same complete held-out test population. \'\n                \'Mean +/- fitting SD; no historical or published Study A values are included.\')\n    save_json(ctx[\'out\'] / \'published_comparator_status.json\', dict(\n        study=\'C\', included=False,\n        reason=\'No independently verified Study C published-benchmark records were supplied\',\n    ))\n\n\ndef export_tables(ctx,metrics,summary,stability,boot):\n    cfg=ctx[\'cfg\'];out=ctx[\'out\'];ens=cfg.ensemble_label\n    summary.to_csv(out/\'summary_mean_sd_fitting.csv\',index=False)\n    write_table(ctx,\'StudyC_MT1_performance\',performance_table(summary,[\'MT1\'],ctx),\'Study C MT1. Training-only diagnostics and metrics on the complete held-out test set. Mean +/- sample SD across fixed-case refits.\')\n    write_table(ctx,\'StudyC_MT2_MT3_MT4_performance\',performance_table(summary,[\'MT2\',\'MT3\',\'MT4\'],ctx),\'Study C MT2-MT4 performance from the same prediction record as comparisons and constituent results.\')\n    xyz=summary.loc[(summary.analysis==\'primary\')&(summary.split==\'Test\')&(summary.configuration==\'XYZ\')]\n    rows=[]\n    for (mt,target),g in xyz.groupby([\'missing_type\',\'target\'],sort=False):\n        row={\'Study\':\'C\',\'Missing Type\':mt,\'Target\':target,\'Test records\':int(g.n_records.iloc[0]),\'Test boreholes\':int(g.n_boreholes.iloc[0])}\n        for _,v in g.loc[g.model.isin(list(cfg.learners)+[ens])].iterrows():row[v.model]=formatted(v.rmse_mean,v.rmse_sd,target)\n        rows.append(row)\n    write_table(ctx,\'StudyC_XYZ_constituents\',pd.DataFrame(rows),\'Study C constituent and fixed-average test RMSE; identical evaluation cases and seeds within each task.\')\n    st=stability.loc[stability.analysis==\'primary\'].copy() if len(stability) else stability\n    improvement_rows=[]\n    for (mt,target),g in st.groupby([\'missing_type\',\'target\'],sort=False) if len(st) else []:\n        row={\'Study\':\'C\',\'Missing Type\':mt,\'Target\':target,\'Test records\':int(g.n_test_records.iloc[0]),\'Test boreholes\':int(g.n_test_boreholes.iloc[0])}\n        for _,v in g.iterrows():row[v.configuration+\' improvement (%)\']=formatted(v.mean_runwise_improvement_percent,v.sd_runwise_improvement_percent)\n        improvement_rows.append(row)\n    write_table(ctx,\'StudyC_spatial_improvements\',pd.DataFrame(improvement_rows),\'Study C paired runwise RMSE improvement (%), mean +/- sample SD. Negative values indicate deterioration. Ratios from displayed means are exported separately in fitting_stability_wilcoxon_holm.csv.\')\n    counts=pd.DataFrame([{\'Study\':\'C\',\'Comparisons\':len(st),\'Significant (Holm p<0.05)\':int(st.significant_fitting_holm_005.sum()) if len(st) else 0,\n           \'Lower RMSE\':int(((st.mean_rmse_difference<0)&st.significant_fitting_holm_005).sum()) if len(st) else 0,\n           \'Higher RMSE\':int(((st.mean_rmse_difference>0)&st.significant_fitting_holm_005).sum()) if len(st) else 0,\n           \'Non-significant\':int((~st.significant_fitting_holm_005).sum()) if len(st) else 0}])\n    write_table(ctx,\'StudyC_fitting_stability\',counts,\'Study C summary of two-sided paired Wilcoxon with Holm correction; stochastic fitting on fixed cases, not borehole sampling uncertainty. Full per-task statistics are supplied separately.\')\n    if len(boot):export_bootstrap_publication(ctx,boot)\n    table7(ctx,summary)\n    selection=[];boundary=[]\n    for p in sorted((out/\'selection\').glob(\'*_selected.csv\')):selection.append(pd.read_csv(p))\n    for p in sorted((out/\'selection\').glob(\'*_boundaries.csv\')):boundary.append(pd.read_csv(p))\n    if selection:\n        selected=pd.concat(selection,ignore_index=True)\n        write_table(ctx,\'StudyC_selected_settings\',selected,\'Study C settings selected by training-only grouped CV. No Study A hyperparameters are replayed.\')\n        repeated=selected.copy();repeated[\'parameters\']=repeated.parameters.astype(str)\n        repeated.groupby([\'model\',\'parameters\']).size().reset_index(name=\'number_of_tasks\').to_csv(out/\'repeated_selected_settings.csv\',index=False)\n    if boundary:pd.concat(boundary,ignore_index=True).to_csv(out/\'hyperparameter_boundary_audit.csv\',index=False)\n    rk=[]\n    for p in sorted((out/\'selection\').glob(\'*_RK_alpha.json\')):\n        rk.append(dict(task=p.stem,**read_locked_json(p)))\n    pd.DataFrame(rk).to_csv(out/\'comparator_selected_settings.csv\',index=False)\n    write_table(ctx,\'StudyC_actual_environment\',dependency_report(),\'Actual executing Python and package versions, not copied historical environment claims.\')\n    cal=summary.loc[(summary.analysis==\'primary\')&(summary.split==\'Test\'),[\'missing_type\',\'configuration\',\'target\',\'model\',\'n_records\',\'n_boreholes\',\n        \'calibration_slope_observed_on_predicted_mean\',\'calibration_intercept_observed_on_predicted_mean\',\'trend_slope_predicted_on_observed_mean\',\'trend_intercept_predicted_on_observed_mean\']]\n    write_table(ctx,\'Supplement_StudyC_calibration\',cal,\'Calibration is observed = intercept + slope * predicted, ideal intercept 0 and slope 1; the plotting trend regression is separately identified.\')\n    robust=summary.loc[summary.analysis==\'primary\',[\'missing_type\',\'configuration\',\'target\',\'model\',\'split\',\'n_records\',\'n_boreholes\',\'robust_l2_mean\',\'robust_l2_sd\',\'robust_l2_standardized_mean\',\'robust_l2_standardized_sd\']]\n    write_table(ctx,\'Supplement_StudyC_robust_L2_scale\',robust,\'Original-unit Huber delta=1 retained for continuity. Standardized residuals use the pooled-development target SD and dimensionless delta=1. Metrics do not tune the models.\')\n    classifications=[]\n    mechanisms={\'su\':\'Possible association with stress level and consolidation history\',\'Pc\':\'Possible association with stress history\',\'E50\':\'Possible association with soil fabric and stress level\',\'Cc\':\'Possible association with soil composition and state\',\'Cv\':\'Possible association with compressibility and permeability\'}\n    for target,g in st.groupby(\'target\',sort=False) if len(st) else []:\n        row=dict(target=target,classification=\'Qualitative dataset-specific summary, no fixed threshold\',\n                 geotechnical_interpretation=mechanisms[target]+\'; hypothesis, not physically tested\',scope=\'Study C only; do not replace a three-study summary with this row\')\n        for conf,c in g.groupby(\'configuration\'):row[conf+\'_mean_improvement_percent\']=float(c.mean_runwise_improvement_percent.mean())\n        z=g.loc[g.configuration==\'XYZ\'];row[\'positive_XYZ_tasks\']=int((z.mean_rmse_difference<0).sum());row[\'XYZ_tasks\']=len(z)\n        classifications.append(row)\n    write_table(ctx,\'StudyC_qualitative_summary\',pd.DataFrame(classifications),\'Study C descriptive spatial-sensitivity evidence. Geotechnical mechanisms are qualitative hypotheses, not causal tests or formal classifications.\')\n    checks=[]\n    for _, row in xyz.loc[xyz.model==ens].iterrows():\n        performance_name=\'StudyC_MT1_performance\' if row.missing_type==\'MT1\' else \'StudyC_MT2_MT3_MT4_performance\'\n        performance=pd.read_csv(out/\'tables\'/(performance_name+\'.csv\'))\n        p=performance.loc[(performance[\'Missing Type\']==row.missing_type)&(performance.Target==row.target)&\n                          (performance.Configuration==CONFIG_LABELS[\'XYZ\'])]\n        comparisons=pd.read_csv(out/\'tables\'/\'StudyC_comparisons.csv\')\n        c=comparisons.loc[(comparisons[\'Missing Type\']==row.missing_type)&(comparisons.Target==row.target)]\n        constituents=pd.read_csv(out/\'tables\'/\'StudyC_XYZ_constituents.csv\')\n        k=constituents.loc[(constituents[\'Missing Type\']==row.missing_type)&(constituents.Target==row.target)]\n        if len(p)!=1 or len(c)!=1 or len(k)!=1:raise AssertionError(\'Nonunique saved Study C table view\')\n        expected=formatted(row.rmse_mean,row.rmse_sd,row.target)\n        consistent=bool(p[\'Test RMSE\'].iloc[0]==expected and c.XYZ.iloc[0]==expected and k[ens].iloc[0]==expected)\n        checks.append(dict(study=\'C\',missing_type=row.missing_type,target=row.target,\n                           views=performance_name+\',StudyC_comparisons,StudyC_XYZ_constituents\',\n                           rmse_mean=row.rmse_mean,rmse_sd=row.rmse_sd,consistent=consistent))\n    if checks and not all(r[\'consistent\'] for r in checks):raise AssertionError(\'Saved Study C table disagreement\')\n    pd.DataFrame(checks,columns=[\'study\',\'missing_type\',\'target\',\'views\',\'rmse_mean\',\'rmse_sd\',\'consistent\']).to_csv(\n        out/\'table_consistency_checks.csv\',index=False)\n\n\n\ndef export_bootstrap_publication(ctx, boot):\n    """Keep the 12 reporting columns and place repeated metadata in notes."""\n    columns = [\'missing_type\', \'target\', \'configuration\', \'n_test_records\', \'n_test_boreholes\',\n               \'rmse_point\', \'rmse_ci95_low\', \'rmse_ci95_high\',\n               \'paired_rmse_difference_ci95_low\', \'paired_rmse_difference_ci95_high\',\n               \'paired_improvement_percent_ci95_low\', \'paired_improvement_percent_ci95_high\']\n    cfg = ctx[\'cfg\']\n    notes = (\n        f\'Primary Study C analysis; {cfg.runs} seed-specific RMSEs are averaged \'\n        f\'(fitting seeds {cfg.base_seed}-{cfg.base_seed + cfg.runs - 1}). \'\n        f\'Intervals use {cfg.bootstrap_replicates} whole-borehole bootstrap replicates and \'\n        f\'base seed {cfg.bootstrap_seed}, with deterministic task offsets. \'\n        \'All observations from each sampled borehole are retained. The same borehole multiplicities \'\n        \'are used across spatial configurations and fitting seeds. RMSE is calculated separately \'\n        \'for each seed before averaging; this is not RMSE of seed-averaged predictions. \'\n        \'Intervals are pointwise 95% percentile intervals, not multiplicity-adjusted. \'\n        \'Paired RMSE differences are spatial minus NoSpatial; negative differences favor spatial inputs. \'\n        \'Percentage improvement is 100*(NoSpatial RMSE-spatial RMSE)/NoSpatial RMSE, averaged \'\n        \'over seeds within each replicate; positive values favor spatial inputs. Baseline paired \'\n        \'intervals are zero by definition. RMSE quantities retain original target units. \'\n        f\'Each task evaluates {len(ctx["test"])} records from {ctx["test"].borehole_id.nunique()} \'\n        \'boreholes excluded from training. The same test records are reused across missing types. \'\n        \'Intervals are conditional on fitted models and observed test boreholes; training is not \'\n        \'resampled and models are not refitted. Few test boreholes limit interval reliability. \'\n        \'These intervals are distinct from seed SDs and Wilcoxon/Holm fitting tests and do not \'\n        \'establish independent-site generalization.\'\n    )\n    table = write_table(ctx, \'Supplement_StudyC_borehole_bootstrap\', boot.loc[:, columns],\n                        \'Study C pointwise borehole-cluster bootstrap intervals conditional on fitted models.\')\n    path = ctx[\'out\'] / \'tables\' / \'Supplement_StudyC_borehole_bootstrap.tex\'\n    text = path.read_text()\n    # Data notes are outside the resized tabular so their text remains readable.\n    def escape(value):\n        mapping = {\'\\\\\': r\'\\textbackslash{}\', \'&\': r\'\\&\', \'%\': r\'\\%\', \'_\': r\'\\_\',\n                   \'#\': r\'\\#\', \'$\': r\'\\$\', \'{\': r\'\\{\', \'}\': r\'\\}\'}\n        return \'\'.join(mapping.get(char, char) for char in value)\n    text = text.replace(r\'\\end{table*}\',\n                        r\'\\par\\smallskip\\begin{minipage}{\\textwidth}\\footnotesize \'\n                        + \'Data notes. \' + escape(notes) + r\'\\end{minipage}\' + \'\\n\' + r\'\\end{table*}\')\n    path.write_text(text)\n    (ctx[\'out\'] / \'tables\' / \'Supplement_StudyC_borehole_bootstrap_notes.txt\').write_text(notes + \'\\n\')\n    return table\n\ndef record_figure(ctx,path,metadata):\n    file=Path(path);metadata=dict(metadata,figure=file.name,figure_sha256=sha256_file(file),revision=REVISION,\n          protocol_signature=ctx[\'manifest\'][\'protocol_signature\'],source_sha256=ctx[\'manifest\'][\'source_sha256\'],\n          output_class=ctx[\'manifest\'][\'output_class\'])\n    save_json(file.with_suffix(\'.provenance.json\'),metadata)\n\n\ndef regenerate_prediction_figures(ctx):\n    import matplotlib\n    matplotlib.use(\'Agg\')\n    import matplotlib.pyplot as plt\n    cfg=ctx[\'cfg\'];f=ctx[\'out\']/\'figures\';f.mkdir(exist_ok=True)\n    for mt,split,number in [(\'MT1\',\'Development\',\'08\'),(\'MT1\',\'Test\',\'10\'),(\'MT4\',\'Development\',\'22\'),(\'MT4\',\'Test\',\'24\')]:\n        if mt not in cfg.missing_types:continue\n        tasks=[t for t in study_tasks(cfg) if t.missing_type==mt]\n        if not tasks:continue\n        targets=[t for t in MISSINGNESS_PATTERNS[mt][\'targets\'] if t in cfg.targets]\n        fig,axes=plt.subplots(len(targets),len(cfg.configurations),figsize=(4*len(cfg.configurations),3.5*len(targets)),squeeze=False)\n        ids=set();counts=[]\n        for i,target in enumerate(targets):\n            for j,conf in enumerate(cfg.configurations):\n                task=next(t for t in tasks if t.target==target and t.configuration==conf)\n                g=read_prediction_part(ctx,prediction_path(ctx,task,cfg.representative_seed));g=g.loc[g.split==split]\n                a=g.actual.to_numpy();p=g[\'prediction_\'+cfg.ensemble_label].to_numpy();ax=axes[i,j]\n                ax.scatter(a,p,s=12,alpha=.65);lo=min(a.min(),p.min());hi=max(a.max(),p.max());pad=(hi-lo)*.04 or 1;lo-=pad;hi+=pad\n                ax.plot([lo,hi],[lo,hi],color=\'black\',linestyle=\':\',label=\'Identity\')\n                slope,intercept=linear_fit(a,p)\n                if np.isfinite(slope):ax.plot([lo,hi],[intercept+slope*lo,intercept+slope*hi],color=\'#2171b5\',label=\'Fitted trend\')\n                cal_s,cal_i=linear_fit(p,a)\n                ax.set(xlabel=\'Observed\',ylabel=\'Predicted\',title=f\'{target}, {conf}\\nn={len(g)}, boreholes={g.borehole_id.nunique()}\')\n                ax.text(.03,.97,f\'Calibration: observed={cal_i:.3g}+{cal_s:.3g} predicted\',transform=ax.transAxes,va=\'top\',fontsize=8)\n                ids.update(g.global_id.tolist());counts.append(dict(target=target,configuration=conf,n_records=len(g),n_boreholes=g.borehole_id.nunique()))\n        fig.suptitle(f\'Study C {mt}, {split}, seed {cfg.representative_seed}; {ctx["manifest"]["output_class"]}\',fontsize=11)\n        fig.tight_layout(rect=[0,0,1,.97]);path=f/f\'StudyC_{mt}_{split}.png\';fig.savefig(path,dpi=160);plt.close(fig)\n        record_figure(ctx,path,dict(seed=cfg.representative_seed,split=split,missing_type=mt,global_ids=sorted(ids),sample_counts=counts,\n             scope=\'Regenerated from declared prediction record; development plots are training diagnostics\'))\n\n\ndef load_representative(ctx,task):\n    file=ctx[\'out\']/\'models\'/f\'{task_key(task)}_seed{ctx["cfg"].representative_seed}.joblib\'\n    if not file.exists():raise FileNotFoundError(\'Representative models required for SHAP; enable save_representative_models\')\n    obj=joblib.load(file)\n    if obj[\'protocol_signature\']!=ctx[\'manifest\'][\'protocol_signature\']:raise ValueError(\'Representative model lineage mismatch\')\n    return obj,file\n\n\ndef save_feature_mapping(ctx,task,obj):\n    mapping=[]\n    for name,est in obj[\'models\'].items():\n        poly=est.regressor_.named_steps[\'poly\'];terms=poly.get_feature_names_out(list(task.features))\n        for term,powers in zip(terms,poly.powers_):\n            mapping.append(dict(model=name,expanded_term=term,raw_input_features=json.dumps([f for f,p in zip(task.features,powers) if p]),\n                        powers=json.dumps(powers.tolist()),attribution_rule=\'SHAP masks the pre-expansion input vector and reruns this entire pipeline. Expanded-term SHAP values are not calculated or summed.\'))\n    directory=ctx[\'out\']/\'shap\';directory.mkdir(exist_ok=True)\n    pd.DataFrame(mapping).to_csv(directory/f\'{task_key(task)}_polynomial_feature_mapping.csv\',index=False)\n\n\ndef make_exact_shap_masker(background):\n    """Retain SHAP\'s independent masking, with exact invariance checks.\n\n    A nearly equal feature can cross a tree split. Reusing a background\n    prediction for that feature would explain a different prediction.\n    """\n    import shap\n\n    class ExactIndependentMasker(shap.maskers.Independent):\n        def invariants(self, x):\n            x = np.asarray(x)\n            if x.shape != self.data.shape[1:]:\n                raise ValueError(\n                    f\'SHAP input shape {x.shape} does not match background \'\n                    f\'feature shape {self.data.shape[1:]}\'\n                )\n            # Default Independent.invariants uses np.isclose. Only exactly\n            # equal values can safely skip model evaluations for tree models.\n            return np.equal(self.data, x)\n\n    return ExactIndependentMasker(background, max_samples=len(background))\n\n\ndef validate_shap_additivity(explanation, predictions, global_ids, diagnostic_path,\n                             feature_count, rtol=1e-6, atol=1e-6):\n    """Save reconstruction diagnostics and enforce the original tolerance."""\n    predictions = np.asarray(predictions, dtype=np.float64).reshape(-1)\n    values = np.asarray(explanation.values, dtype=np.float64)\n    base_values = np.asarray(explanation.base_values, dtype=np.float64).reshape(-1)\n    global_ids = np.asarray(global_ids)\n    if values.shape != (len(predictions), feature_count):\n        raise ValueError(f\'Unexpected single-target SHAP shape: {values.shape}\')\n    if base_values.size not in (1, len(predictions)):\n        raise ValueError(f\'Unexpected SHAP base-values shape: {base_values.shape}\')\n    if global_ids.shape != predictions.shape:\n        raise ValueError(\'SHAP diagnostic IDs do not match prediction rows\')\n    base_values = np.broadcast_to(base_values, predictions.shape)\n    shap_sum = values.sum(axis=1, dtype=np.float64)\n    reconstructed = base_values + shap_sum\n    residual = reconstructed - predictions\n    tolerance = atol + rtol * np.abs(predictions)\n    finite = (np.isfinite(predictions) & np.isfinite(base_values)\n              & np.isfinite(values).all(axis=1) & np.isfinite(reconstructed))\n    passed = finite & (np.abs(residual) <= tolerance)\n    pd.DataFrame(dict(\n        global_id=global_ids, prediction=predictions, base_value=base_values,\n        shap_sum=shap_sum, reconstructed_prediction=reconstructed,\n        additivity_residual=residual, tolerance=tolerance, passed=passed,\n    )).to_csv(diagnostic_path, index=False)\n    if not finite.all():\n        raise ValueError(f\'Nonfinite SHAP results; inspect {diagnostic_path}\')\n    np.testing.assert_allclose(\n        reconstructed, predictions, rtol=rtol, atol=atol, equal_nan=False,\n        err_msg=f\'SHAP reconstruction failed; inspect {diagnostic_path}\',\n    )\n    return dict(rtol=rtol, atol=atol, all_passed=bool(passed.all()),\n                max_absolute_residual=float(np.max(np.abs(residual))),\n                diagnostics_file=Path(diagnostic_path).name)\n\n\ndef regenerate_shap(ctx):\n    import shap\n    import matplotlib\n    matplotlib.use(\'Agg\')\n    import matplotlib.pyplot as plt\n    cfg=ctx[\'cfg\'];out=ctx[\'out\']/\'shap\';out.mkdir(exist_ok=True)\n    specification=[(\'MT1\',\'su\',\'13\'),(\'MT4\',\'su\',\'14\'),(\'MT1\',\'E50\',\'15\'),(\'MT4\',\'E50\',\'16\'),\n                   (\'MT1\',\'Pc\',\'17a\'),(\'MT1\',\'Cc\',\'17b\'),(\'MT1\',\'Cv\',\'17c\'),(\'MT3\',\'Pc\',\'18a\'),(\'MT3\',\'Cc\',\'18b\'),(\'MT3\',\'Cv\',\'18c\')]\n    ranks=[]\n    for mt,target,number in specification:\n        candidates=[t for t in study_tasks(cfg) if t.missing_type==mt and t.target==target and t.configuration==\'XYZ\']\n        if not candidates:continue\n        task=candidates[0];obj,model_file=load_representative(ctx,task);save_feature_mapping(ctx,task,obj)\n        dev=ctx[\'dev\'];nb=min(cfg.shap_background_size,len(dev));rng=np.random.default_rng(cfg.representative_seed)\n        bi=np.sort(rng.choice(len(dev),nb,replace=False));background=dev.iloc[bi]\n        heldout=cfg.shap_scope==\'heldout_all\' or target in {\'su\',\'E50\'}\n        evaluation=selected_test(ctx[\'test\'],mt) if heldout else dev\n        population=\'Complete Study C held-out test observations\' if heldout else \'Study C training observations; interpretation only\'\n        if not heldout and cfg.shap_max_development_samples is not None and len(evaluation)>cfg.shap_max_development_samples:\n            choice=np.sort(rng.choice(len(evaluation),cfg.shap_max_development_samples,replace=False));evaluation=evaluation.iloc[choice]\n            population+=\'; explicitly subsampled\'\n        X=evaluation.loc[:,task.features];B=background.loc[:,task.features]\n        def predict_raw(values):\n            frame=pd.DataFrame(np.asarray(values),columns=task.features)\n            return np.mean(np.column_stack([model.predict(frame) for model in obj[\'models\'].values()]),axis=1)\n        stored=read_prediction_part(ctx,prediction_path(ctx,task,cfg.representative_seed))\n        stored=stored.loc[stored.split==(\'Test\' if heldout else \'Development\')].set_index(\'global_id\')\n        np.testing.assert_allclose(predict_raw(X),stored.loc[evaluation.global_id,\'prediction_\'+cfg.ensemble_label],rtol=1e-8,atol=1e-8)\n        masker=make_exact_shap_masker(B)\n        explainer=shap.PermutationExplainer(predict_raw,masker,feature_names=list(task.features),seed=cfg.representative_seed)\n        budget=10*(2*len(task.features)+1)\n        explanation=explainer(X,max_evals=budget,silent=True)\n        prefix=f\'StudyC_SHAP_{mt}_{target}\'\n        additivity=validate_shap_additivity(\n            explanation,predict_raw(X),evaluation.global_id.to_numpy(),\n            out/(prefix+\'_additivity.csv\'),feature_count=len(task.features))\n        np.savez_compressed(out/(prefix+\'_values.npz\'),values=explanation.values,base_values=explanation.base_values,data=X.to_numpy(),feature_names=np.asarray(task.features),global_ids=evaluation.global_id.to_numpy())\n        evaluation[[\'global_id\',\'borehole_id\']].to_csv(out/(prefix+\'_evaluation_ids.csv\'),index=False)\n        background[[\'global_id\',\'borehole_id\']].to_csv(out/(prefix+\'_background_ids.csv\'),index=False)\n        importance=np.mean(np.abs(explanation.values),axis=0);order=np.argsort(-importance)\n        for rank,i in enumerate(order,1):ranks.append(dict(missing_type=mt,target=target,feature=task.features[i],rank=rank,mean_abs_shap=importance[i],population=population,n_evaluation=len(evaluation),seed=cfg.representative_seed))\n        shap.plots.beeswarm(explanation,max_display=len(task.features),show=False)\n        plt.title(f\'Study C {mt} {target}: n={len(evaluation)}, boreholes={evaluation.borehole_id.nunique()}\')\n        plt.tight_layout();figpath=out/(prefix+\'_beeswarm.png\');plt.savefig(figpath,dpi=180,bbox_inches=\'tight\');plt.close(\'all\')\n        provenance=dict(seed=cfg.representative_seed,missing_type=mt,target=target,configuration=\'XYZ\',population=population,\n            n_evaluation_records=len(evaluation),n_evaluation_boreholes=evaluation.borehole_id.nunique(),\n            evaluation_global_ids=evaluation.global_id.tolist(),background_global_ids=background.global_id.tolist(),background_seed=cfg.representative_seed,\n            background_size=len(background),model_file=model_file.name,model_sha256=sha256_file(model_file),method=\'Permutation SHAP on the complete raw-input ensemble pipeline\',\n            max_evals=budget,output_units=\'Original target units after inverse transformation\',\n            shap_version=shap.__version__,masker_invariants=\'Exact equality (np.equal)\',\n            shap_implementation=\'exact-invariants-v1\',shap_source_sha256=core_source_hash(),\n            additivity_validation=additivity,\n            attribution_mapping=\'Pre-polynomial input features, including engineered index variables; no aggregation of transformed-term SHAP values\',\n            dependence_caution=\'Independent masking can create combinations outside observed predictor relationships; associations are not causal\')\n        record_figure(ctx,figpath,provenance)\n        if target in {\'su\',\'E50\'}:\n            shap.force_plot(float(np.asarray(explanation.base_values).reshape(-1)[0]),explanation.values[0],X.iloc[0],matplotlib=True,show=False)\n            forcepath=out/(prefix+\'_local_force.png\');plt.savefig(forcepath,dpi=180,bbox_inches=\'tight\');plt.close(\'all\')\n            record_figure(ctx,forcepath,dict(provenance,local_global_id=int(evaluation.global_id.iloc[0])))\n        print(f\'SHAP: {mt} {target}, {len(evaluation)} observations\',flush=True)\n    ranking=pd.DataFrame(ranks);ranking.to_csv(out/\'shap_feature_rankings.csv\',index=False)\n    pc=ranking.loc[(ranking.missing_type==\'MT3\')&(ranking.target==\'Pc\')]\n    if len(pc):save_json(out/\'Pc_MT3_abstract_alignment_check.json\',dict(top_feature=pc.sort_values(\'rank\').feature.iloc[0],\n          action=\'Align abstract, figure caption and discussion with this regenerated ranking; do not hard-code depth or Su\'))\n    return ranking\n\n\ndef regenerate_mt1_importance(ctx):\n    import matplotlib\n    matplotlib.use(\'Agg\')\n    import matplotlib.pyplot as plt\n    cfg=ctx[\'cfg\'];tasks=[t for t in study_tasks(cfg) if t.missing_type==\'MT1\' and t.configuration in {\'NoSpatial\',\'XYZ\'}]\n    if not tasks:return\n    rows=[]\n    for task in tasks:\n        obj,path=load_representative(ctx,task)\n        scores=[]\n        for name,est in obj[\'models\'].items():\n            value=est.regressor_.named_steps[\'model\'].feature_importances_\n            scores.append(value/value.sum() if value.sum()>0 else value)\n        score=np.mean(scores,axis=0)\n        for feature,value in zip(task.features,score):rows.append(dict(configuration=task.configuration,target=task.target,feature=feature,importance=value))\n    f=pd.DataFrame(rows);f.to_csv(ctx[\'out\']/\'MT1_global_importance.csv\',index=False)\n    targets=[t for t in MISSINGNESS_PATTERNS[\'MT1\'][\'targets\'] if t in cfg.targets];confs=[c for c in [\'NoSpatial\',\'XYZ\'] if c in cfg.configurations]\n    fig,axes=plt.subplots(len(confs),len(targets),figsize=(4*len(targets),5*len(confs)),squeeze=False)\n    for i,conf in enumerate(confs):\n        for j,target in enumerate(targets):\n            g=f.loc[(f.configuration==conf)&(f.target==target)].sort_values(\'importance\');axes[i,j].barh(g.feature,g.importance,color=\'#2171b5\');axes[i,j].set_title(f\'{target}, {conf}\')\n    fig.tight_layout();path=ctx[\'out\']/\'figures\'/\'StudyC_MT1_importance.png\';path.parent.mkdir(exist_ok=True);fig.savefig(path,dpi=160);plt.close(fig)\n    record_figure(ctx,path,dict(seed=cfg.representative_seed,population=\'Fitted models trained on Study C training observations only\',global_ids=ctx[\'dev\'].global_id.tolist(),\n                              method=\'Equal mean of learner-normalized impurity/gain importances; distinct from SHAP\'))\n\ndef summarize_timing(ctx):\n    files=list((ctx[\'out\']/\'timing\').glob(\'*.json\'))\n    if not files:return pd.DataFrame()\n    times=pd.DataFrame([json.loads(p.read_text()) for p in files]);times.to_csv(ctx[\'out\']/\'fit_timing_by_task_seed.csv\',index=False)\n    result=times.groupby([\'analysis\',\'model\']).fit_seconds.agg([\'count\',\'sum\',\'mean\',\'std\']).reset_index()\n    write_table(ctx,\'Supplement_StudyC_fit_time_detail\',result,\'Measured constituent fitting times, separated by primary and no-polynomial analysis.\')\n    selections=[]\n    for p in (ctx[\'out\']/\'selection\').glob(\'primary_*_selected.csv\'):selections.append(pd.read_csv(p))\n    selected=pd.concat(selections,ignore_index=True) if selections else pd.DataFrame()\n    row={\'Study\':\'C\',\'Selection mode\':ctx[\'cfg\'].mode}\n    for model in PRIMARY_LEARNERS:\n        z=selected.loc[(selected.model==model)&(selected.n_candidates>0)] if len(selected) else pd.DataFrame()\n        row[model+\' optimization minutes\']=float(z.seconds.sum()/60) if len(z) else 0.0\n    row[\'Total optimization minutes\']=sum(row[m+\' optimization minutes\'] for m in PRIMARY_LEARNERS)\n    row[\'Primary constituent-fitting minutes\']=float(times.loc[times.analysis==\'primary\',\'fit_seconds\'].sum()/60)\n    row[\'End-to-end including supplements minutes\']=(time.perf_counter()-ctx[\'pipeline_started\'])/60\n    write_table(ctx,\'StudyC_fit_time\',pd.DataFrame([row]),\'Actual Study C timings, including training-only hyperparameter selection. End-to-end includes supplements and cache reuse on resume; saved fit timings are cumulative across completed tasks.\')\n    return result\n\n\ndef final_notes(ctx, metrics, stability, bootstrap):\n    cfg = ctx[\'cfg\']\n    test, dev = ctx[\'test\'], ctx[\'dev\']\n    notes = [\n        f\'Run class: {ctx["manifest"]["output_class"]}; mode: {cfg.mode}; revision: {REVISION}.\',\n        f\'Study C uses {len(dev)} training records in {dev.borehole_id.nunique()} boreholes \'\n        f\'and {len(test)} held-out records in {test.borehole_id.nunique()} different boreholes. \'\n        \'No test record or borehole enters model fitting. This remains a within-site evaluation, not an independent-site study.\',\n        ctx[\'manifest\'][\'cv_contract\'] + \'.\',\n        \'All preprocessing and target scaling are fitted within CV training folds. Final learners are fitted \'\n        \'on the entire training CSV; inverse target transformation precedes fixed arithmetic averaging and all metrics.\',\n        f\'Every applicable target/missing-type task evaluates all {len(test)} test records. \'\n        \'There is no benchmark row mapping and no auxiliary dataset. Counts across scenarios reuse observations.\',\n        \'All tables and prediction figures derive from prediction_record/*.csv.gz. \'\n        \'Historical Study A settings and published numbers are not treated as Study C results.\',\n    ]\n    if len(stability):\n        group = stability.loc[stability.analysis == \'primary\']\n        significant = group.significant_fitting_holm_005\n        benefits = (group.mean_rmse_difference < 0) & significant\n        harms = (group.mean_rmse_difference > 0) & significant\n        notes.append(f\'Study C: {int(significant.sum())}/{len(group)} Holm-significant fitting-stability \'\n                     f\'comparisons, including {int(benefits.sum())} improvements and {int(harms.sum())} deteriorations. \'\n                     \'These are stochastic fitting results on fixed held-out cases. Study-specific Holm families \'\n                     \'must not be presented as a jointly adjusted cross-study family.\')\n    if len(bootstrap):\n        paired = bootstrap.loc[bootstrap.configuration != \'NoSpatial\']\n        below = int((paired.paired_rmse_difference_ci95_high < 0).sum())\n        above = int((paired.paired_rmse_difference_ci95_low > 0).sum())\n        notes.append(f\'Of {len(paired)} pointwise paired bootstrap RMSE-difference intervals, \'\n                     f\'{below} lie below zero, {above} above zero and {len(paired)-below-above} include zero. \'\n                     \'These intervals are conditional on fitted models and the observed held-out boreholes; \'\n                     \'the learning procedure is not refitted and no multiplicity adjustment is applied.\')\n    notes += [\n        \'Calibration uses observed = intercept + slope*predicted; plotting trends use predicted on observed. \'\n        \'Report the effective number of held-out boreholes alongside calibration and other headline results.\',\n        \'Original-unit Robust L2 keeps delta=1; standardized Robust L2 divides residuals by training-target SD \'\n        \'and uses dimensionless delta=1. Neither metric selects the models.\',\n        \'Polynomial ablation covers MT2-MT4; MT1 already has degree 1. Both degrees are selected with the \'\n        \'same declared training-only CV search spaces and candidate budget. Engineered inputs remain present \'\n        \'when the additional PolynomialFeatures expansion is removed.\',\n        \'Kriging uses a spherical coordinate-distance-quantile heuristic. Limited development-only sensitivity \'\n        \'does not constitute empirical variogram fitting or equal optimization effort across comparators. \'\n        \'Coordinate-only OK is cached once per target/seed over the complete test set and checked for \'\n        \'identical RMSE across missing types.\',\n        \'The default SHAP population is the entire held-out test set for every target. Backgrounds come \'\n        \'from training only. Exact masker invariants retain the strict additivity check. Pre-expansion \'\n        \'features pass through complete fitted pipelines; dependent predictors limit causal interpretation.\',\n        \'Study A and C have different evaluation populations and development/tuning protocols. Compare \'\n        \'their counts, effect estimates and uncertainty descriptively; do not pair their seed errors as \'\n        \'independent borehole replications or claim matched historical reproduction.\',\n        \'Study B analyses, original-source published-benchmark verification, manuscript claims and figure \'\n        \'numbering, references, Highlights and the Graphical Abstract still require separate work.\',\n    ]\n    (ctx[\'out\'] / \'analysis_interpretation.txt\').write_text(\'\\n\\n\'.join(notes), encoding=\'utf-8\')\n    pd.DataFrame(REVIEWER_MATRIX).to_csv(ctx[\'out\'] / \'reviewer_response_matrix.csv\', index=False)\n    (ctx[\'out\'] / \'PSEUDOCODE.txt\').write_text(PSEUDOCODE_TEXT, encoding=\'utf-8\')\n    (ctx[\'out\'] / \'README.md\').write_text(\n        \'# Study C outputs\\n\\n\' + \'\\n\\n\'.join(notes)\n        + \'\\n\\nThe full bootstrap CSV is primary_borehole_bootstrap.csv. The supplementary \'\n        \'bootstrap table retains the 12 reporting columns and places repeated metadata in data notes.\\n\',\n        encoding=\'utf-8\',\n    )\n\n\ndef run_study_c(cfg,validate_only=False):\n    start=time.perf_counter();ctx=initialize_run(cfg)\n    ctx[\'pipeline_started\']=start\n    if validate_only:return ctx\n    if \'XGB\' in cfg.learners:get_xgb_regressor(cfg.tuning_seed)\n    if cfg.run_shap:\n        try:import shap\n        except ImportError as exc:raise RuntimeError(\'Install SHAP in this Python environment, or set run_shap=False explicitly for a separately labelled run\') from exc\n    if (cfg.run_shap or cfg.save_representative_models) and not cfg.save_representative_models:raise ValueError(\'SHAP requires representative models\')\n    analyses=[\'primary\']+([\'no_polynomial\'] if cfg.run_polynomial_ablation else [])\n    # Lock all development-only choices before evaluating any held-out labels.\n    for analysis in analyses:\n        for task in study_tasks(cfg,analysis):select_models(ctx,task,analysis)\n    if cfg.comparators:\n        for task in study_tasks(cfg):\n            if task.configuration==\'XYZ\':select_ridge_alpha(ctx,task)\n    if cfg.run_variogram_sensitivity and cfg.comparators:development_variogram_sensitivity(ctx)\n    ctx[\'manifest\'].update(status=\'SETTINGS_LOCKED_BEFORE_TEST_PREDICTION\',selection_locked_time_utc=datetime.now(timezone.utc).isoformat())\n    save_json(ctx[\'out\']/\'run_manifest.json\',ctx[\'manifest\'])\n    for analysis in analyses:\n        for task in study_tasks(cfg,analysis):fit_learner_task(ctx,task,analysis)\n    if cfg.comparators:fit_comparators(ctx)\n    metrics=derive_run_metrics(ctx);verify_ok_invariance(ctx,metrics);summary=summarize_run_metrics(metrics)\n    stability=fitting_stability(metrics,ctx);bootstrap=borehole_bootstrap(ctx)\n    train_test_gaps(metrics,ctx);constituent_diagnostics(ctx,metrics);polynomial_ablation_summary(metrics,ctx)\n    export_tables(ctx,metrics,summary,stability,bootstrap)\n    regenerate_prediction_figures(ctx)\n    if cfg.save_representative_models:regenerate_mt1_importance(ctx)\n    if cfg.run_shap:regenerate_shap(ctx)\n    summarize_timing(ctx);final_notes(ctx,metrics,stability,bootstrap)\n    ctx[\'manifest\'].update(status=\'COMPLETE\',completed_time_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.perf_counter()-start,\n                          prediction_index_sha256=sha256_file(ctx[\'out\']/\'prediction_record_index.csv\'))\n    save_json(ctx[\'out\']/\'run_manifest.json\',ctx[\'manifest\'])\n    print(f\'Completed {ctx["manifest"]["output_class"]}: {ctx["out"]}\',flush=True)\n    return ctx\n\n\ndef cli():\n    parser=argparse.ArgumentParser(description=\'Study C: two datasets, full held-out test set and training-only grouped CV\')\n    parser.add_argument(\'--config\',help=\'JSON object containing StudyCConfig fields\')\n    parser.add_argument(\'--validate-only\',action=\'store_true\')\n    options=parser.parse_args()\n    config=json.loads(Path(options.config).read_text()) if options.config else {}\n    return run_study_c(StudyCConfig(**config),validate_only=options.validate_only)\n\n\ndef verify_ok_invariance(ctx, metrics):\n    """OK must be identical across missing types on the same test population."""\n    rows = []\n    selected = metrics.loc[(metrics.analysis == \'primary\') & (metrics.model == \'OK\') & (metrics.split == \'Test\')]\n    for (target, seed), group in selected.groupby([\'target\', \'seed\'], sort=False):\n        values = group.rmse.to_numpy(float)\n        consistent = bool(np.allclose(values, values[0], rtol=1e-12, atol=1e-12))\n        rows.append(dict(target=target, seed=seed, missing_types=\',\'.join(sorted(group.missing_type)),\n                         n_tasks=len(group), rmse_min=float(values.min()), rmse_max=float(values.max()),\n                         consistent=consistent))\n        if not consistent:\n            raise AssertionError(f\'Coordinate-only OK changed across missing types for {target}, seed {seed}\')\n    result = pd.DataFrame(rows)\n    result.to_csv(ctx[\'out\'] / \'ordinary_kriging_invariance_checks.csv\', index=False)\n    return result\n\nREVIEWER_MATRIX = [{\'reviewer_comment\': \'R1\', \'topic\': \'Satisfactory\', \'implementation_status\': \'No additional computation requested\', \'outputs\': \'\', \'scope_or_remaining_action\': \'Acknowledge in the response letter\'}, {\'reviewer_comment\': \'R2.1\', \'topic\': \'Fitting versus borehole uncertainty\', \'implementation_status\': \'Implemented for Study C\', \'outputs\': \'primary_borehole_bootstrap.csv; fitting_stability_wilcoxon_holm.csv\', \'scope_or_remaining_action\': \'Conditional test-cluster intervals; no training resampling or independent-site inference\'}, {\'reviewer_comment\': \'R2.2\', \'topic\': \'Effective sample sizes\', \'implementation_status\': \'Implemented for Study C\', \'outputs\': \'effective_test_counts.csv; counts_across_scenarios.csv\', \'scope_or_remaining_action\': \'Use the actual counts; repeated missing-type scenarios reuse the same records\'}, {\'reviewer_comment\': \'R2.3\', \'topic\': \'Verification and leakage\', \'implementation_status\': \'Implemented: two datasets and training-only grouped CV\', \'outputs\': \'run_manifest.json; split_identifiers.csv; cv_fold_identifiers.csv\', \'scope_or_remaining_action\': \'No auxiliary dataset; record and borehole overlap cause failure\'}, {\'reviewer_comment\': \'R2.4\', \'topic\': \'Calibration\', \'implementation_status\': \'Implemented for Study C\', \'outputs\': \'tables/Supplement_StudyC_calibration.csv\', \'scope_or_remaining_action\': \'Report effective test-borehole counts\'}, {\'reviewer_comment\': \'R2.5\', \'topic\': \'Robust loss scale\', \'implementation_status\': \'Implemented for Study C\', \'outputs\': \'tables/Supplement_StudyC_robust_L2_scale.csv\', \'scope_or_remaining_action\': \'Standardization uses training target SD\'}, {\'reviewer_comment\': \'R2.6\', \'topic\': \'Boundary and repeated settings\', \'implementation_status\': \'Training-only extended search and audits implemented\', \'outputs\': \'hyperparameter_boundary_audit.csv; repeated_selected_settings.csv; selection/*cv_results.csv\', \'scope_or_remaining_action\': \'Search is randomized with a declared budget; justify unresolved boundary choices\'}, {\'reviewer_comment\': \'R2.7\', \'topic\': \'Settings and published provenance\', \'implementation_status\': \'Study C settings implemented; published numbers omitted\', \'outputs\': \'tables/StudyC_selected_settings.csv; comparator_selected_settings.csv; published_comparator_status.json\', \'scope_or_remaining_action\': \'No Study A hyperparameters or benchmark values are relabelled as Study C\'}, {\'reviewer_comment\': \'R2.8\', \'topic\': \'Geostatistical comparison\', \'implementation_status\': \'Heuristic documentation and limited sensitivity implemented\', \'outputs\': \'development_variogram_sensitivity.csv; comparator_metadata/*\', \'scope_or_remaining_action\': \'Not empirical variogram model fitting or equal optimization effort\'}, {\'reviewer_comment\': \'R2.9\', \'topic\': \'Depth-only prominence\', \'implementation_status\': \'All four configurations reported for Study C\', \'outputs\': \'tables/StudyC_spatial_improvements.csv\', \'scope_or_remaining_action\': \'Revise manuscript interpretation after inspecting results\'}, {\'reviewer_comment\': \'R2.10\', \'topic\': \'E50 lateral interpretation\', \'implementation_status\': \'Study C quantitative evidence exported\', \'outputs\': \'tables/StudyC_spatial_improvements.csv\', \'scope_or_remaining_action\': \'Manuscript text requires separate reconciliation\'}, {\'reviewer_comment\': \'R2.11\', \'topic\': \'Train-test gaps\', \'implementation_status\': \'Implemented for Study C\', \'outputs\': \'train_test_gap_by_seed.csv\', \'scope_or_remaining_action\': \'Boreholes are excluded from fitting; coordinate mechanisms remain hypotheses\'}, {\'reviewer_comment\': \'R2.12\', \'topic\': \'Study B Su ratio\', \'implementation_status\': \'Outside Study C\', \'outputs\': \'\', \'scope_or_remaining_action\': \'Requires Study B records and code\'}, {\'reviewer_comment\': \'R2.13\', \'topic\': \'Polynomial confounding\', \'implementation_status\': \'Matched training-only retuning for both degrees\', \'outputs\': \'polynomial_ablation_paired.csv\', \'scope_or_remaining_action\': \'MT1 is degree 1; engineered predictors remain in both analyses\'}, {\'reviewer_comment\': \'R2.14\', \'topic\': \'Title and spatial awareness\', \'implementation_status\': \'Evidence exported; editorial work remains\', \'outputs\': \'tables/StudyC_spatial_improvements.csv\', \'scope_or_remaining_action\': \'Qualify wording using actual results\'}, {\'reviewer_comment\': \'R2.15\', \'topic\': \'Ensemble justification\', \'implementation_status\': \'Implemented for Study C\', \'outputs\': \'learner_error_correlations_by_seed.csv; ensemble_robustness_by_task.csv\', \'scope_or_remaining_action\': \'Do not change the prespecified ensemble using test results\'}, {\'reviewer_comment\': \'R2.16\', \'topic\': \'SHAP population\', \'implementation_status\': \'All held-out Study C records by default\', \'outputs\': \'shap/*evaluation_ids.csv; shap/*background_ids.csv\', \'scope_or_remaining_action\': \'Other studies and original-image provenance require their own evidence\'}, {\'reviewer_comment\': \'R2.17\', \'topic\': \'Polynomial SHAP mapping\', \'implementation_status\': \'Mask pre-expansion inputs through complete pipelines\', \'outputs\': \'shap/*polynomial_feature_mapping.csv; shap/*additivity.csv\', \'scope_or_remaining_action\': \'Independent masking does not preserve predictor dependence\'}, {\'reviewer_comment\': \'R2.18\', \'topic\': \'Qualitative classification\', \'implementation_status\': \'Study C descriptive summary and hypothesis labels\', \'outputs\': \'tables/StudyC_qualitative_summary.csv\', \'scope_or_remaining_action\': \'No causal physical test or formal classification threshold\'}, {\'reviewer_comment\': \'R2.19\', \'topic\': \'Claims and within-site scope\', \'implementation_status\': \'Within-site held-out-borehole scope recorded\', \'outputs\': \'analysis_interpretation.txt\', \'scope_or_remaining_action\': \'Edit clean manuscript, Highlights and Conclusions separately\'}, {\'reviewer_comment\': \'R2.20\', \'topic\': \'Section numbering\', \'implementation_status\': \'Editorial work remains\', \'outputs\': \'\', \'scope_or_remaining_action\': \'Edit manuscript source\'}, {\'reviewer_comment\': \'R3.1\', \'topic\': \'Table consistency\', \'implementation_status\': \'Study C saved CSV views checked\', \'outputs\': \'table_consistency_checks.csv\', \'scope_or_remaining_action\': \'Does not identify origins of conflicting historical Study A values\'}, {\'reviewer_comment\': \'R3.2\', \'topic\': \'Figure lineage\', \'implementation_status\': \'Study C figures and SHAP regenerated with IDs and hashes\', \'outputs\': \'figures/*provenance.json; shap/*provenance.json\', \'scope_or_remaining_action\': \'Historical-image comparisons and manuscript figure numbering remain separate\'}, {\'reviewer_comment\': \'R3.3\', \'topic\': \'Counts and benchmark provenance\', \'implementation_status\': \'Study C counts and omission status exported\', \'outputs\': \'effective_test_counts.csv; published_comparator_status.json\', \'scope_or_remaining_action\': \'Original published sources must be verified independently\'}, {\'reviewer_comment\': \'R3.4\', \'topic\': \'Heuristic variograms and invariant OK\', \'implementation_status\': \'Study C sensitivity and OK invariance checks implemented\', \'outputs\': \'ordinary_kriging_invariance_checks.csv; development_variogram_sensitivity.csv\', \'scope_or_remaining_action\': \'Does not correct Study B Table 19\'}, {\'reviewer_comment\': \'R3.5\', \'topic\': \'Scaling and traceability\', \'implementation_status\': \'Implemented for Study C\', \'outputs\': \'run_manifest.json; environment_actual.csv; prediction_record_index.csv\', \'scope_or_remaining_action\': \'Package reviewer access and verify historical environments separately\'}, {\'reviewer_comment\': \'R3.presentation\', \'topic\': \'Manuscript and graphical abstract\', \'implementation_status\': \'Editorial work remains\', \'outputs\': \'\', \'scope_or_remaining_action\': \'Separate borehole-disjoint evaluation from feature availability\'}, {\'reviewer_comment\': \'R4.DOI\', \'topic\': \'DOI formatting\', \'implementation_status\': \'Editorial work remains\', \'outputs\': \'\', \'scope_or_remaining_action\': \'Edit bibliography separately\'}, {\'reviewer_comment\': \'R4.pseudocode\', \'topic\': \'Algorithm inputs/outputs\', \'implementation_status\': \'Notebook algorithm and generated pseudocode\', \'outputs\': \'PSEUDOCODE.txt; README.md\', \'scope_or_remaining_action\': \'Adapt to manuscript layout\'}]\n\nSOURCE_ARTIFACTS = {\'parent_notebook\': \'StudyA_reviewer_revision_fixed (1)(1).ipynb\', \'parent_notebook_sha256\': \'af191d692361aa8d36f79b8a695e54ad52dec3da915a8c17ea0329cf08a20e36\', \'adaptation\': \'Two-dataset Study C; original Study A manuscript references are not carried into results\', \'historical_study_c_reproduction\': \'Not established; no historical Study C hyperparameters were supplied\'}\n\nPSEUDOCODE_TEXT = \'STUDY C: TWO DATASETS, NO MISSING-TYPE TEST-ROW MAPPING\\nINPUT: BM2_Data_All_without_106_records.csv (training),\\n       BM2_Data_All_with_106_records.csv (test), configuration and seeds.\\n1. Validate schema, stable IDs and finite engineered predictors. Require record-\\n   and borehole-disjoint datasets. Export all input counts, IDs, hashes and CV folds.\\n2. For every missing type, target, spatial configuration and polynomial analysis,\\n   use the same entire test dataset. Known mechanical inputs follow the declared\\n   missingness pattern; test targets never select settings.\\n3. Fit polynomial expansion, predictor scaling and target scaling within each\\n   grouped training CV fold. Select RF/GBR/XGB settings and RK ridge alpha from\\n   training only. Lock all settings before producing held-out predictions.\\n4. Refit each learner on full training at seeds 2026-2065. Inverse-transform\\n   predictions to original target units, then average learners without weights.\\n5. Predict OK once per target/seed over the entire test set. Reuse predictions\\n   across missing types and verify identical OK RMSE on identical observations.\\n   Fit RK using grouped out-of-fold training residuals and training-only scaling.\\n6. Save immutable prediction records and integrity receipts. Derive tables,\\n   calibration, scale-standardized Huber loss, gaps and learner correlations.\\n7. Compare configurations using paired seed tests with study-specific Holm\\n   correction. Separately resample whole test boreholes to obtain conditional\\n   pointwise paired percentile intervals. Do not refit models during bootstrap.\\n8. Regenerate figures and default held-out SHAP using training backgrounds and\\n   exact masker invariants. Check SHAP additivity and retain lineage and IDs.\\n9. Export full bootstrap data plus a compact 12-column table with data notes.\\n   Report the actual held-out borehole count and within-site scope. Keep Study A\\n   and Study C inference families separate. Write reports and mark COMPLETE.\\nOUTPUT: prediction records, settings/CV logs, counts/IDs, comparable metrics and\\n        bootstrap columns, diagnostic tables, figures/SHAP, lineage and reports.\\n\'\n\n\nif __name__ == \'__main__\':\n    cli()\n'

import ast
import hashlib
import json
import os
import sys
import time
import types
import uuid
from dataclasses import asdict, dataclass, replace
from datetime import datetime, timezone
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from joblib import Memory, Parallel, delayed, parallel_config
from scipy.stats import rankdata
from sklearn.base import clone
from sklearn.model_selection import ParameterGrid, ParameterSampler
from threadpoolctl import threadpool_limits

ENGINE_REVISION = 'study-c-fast-resume-2026-11-09-v1'


def _load_original():
    name = '_study_c_original_' + hashlib.sha256(ORIGINAL_CORE_SOURCE.encode()).hexdigest()[:12]
    module = types.ModuleType(name)
    module.__file__ = __file__
    module.CORE_SOURCE = ORIGINAL_CORE_SOURCE
    sys.modules[name] = module
    exec(compile(ORIGINAL_CORE_SOURCE, '<original-study-c>', 'exec'), module.__dict__)
    return module


_BASE = _load_original()
StudyCConfig = _BASE.StudyCConfig


@dataclass
class RuntimeOptions:
    workers: int = min(4, max(1, os.cpu_count() or 1))
    stage: str = 'all'  # all, tune, fit, reports, shap
    cache_preprocessing: bool = True
    shap_batch_size: int = 4
    reuse_legacy_cv_results: bool = True
    verbose: bool = True


def _now():
    return datetime.now(timezone.utc).isoformat()


def _digest(path):
    return _BASE.sha256_file(path)


def _canonical(value):
    return json.dumps(value, sort_keys=True, default=_BASE.json_safe, separators=(',', ':'))


def _key(value):
    return hashlib.sha256(_canonical(value).encode()).hexdigest()


def _tmp(path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    return path.with_name('.' + path.name + '.' + uuid.uuid4().hex + '.tmp')


def _json(path, value):
    path = Path(path); temporary = _tmp(path)
    temporary.write_text(json.dumps(value, indent=2, default=_BASE.json_safe), encoding='utf-8')
    temporary.replace(path)


def _csv(path, frame):
    path = Path(path); temporary = _tmp(path)
    frame.to_csv(temporary, index=False, float_format='%.17g')
    temporary.replace(path)


def _joblib(path, value):
    path = Path(path); temporary = _tmp(path)
    joblib.dump(value, temporary, compress=3)
    temporary.replace(path)


def _npz(path, **arrays):
    path = Path(path); temporary = _tmp(path)
    with temporary.open('wb') as stream:
        np.savez_compressed(stream, **arrays)
    temporary.replace(path)


def _commit(path, contract, **metadata):
    _json(str(path) + '.checkpoint.json', dict(contract=contract, sha256=_digest(path), **metadata))


def _valid(path, contract):
    path = Path(path); receipt = Path(str(path) + '.checkpoint.json')
    if not path.is_file() or not receipt.is_file():
        return False
    try:
        meta = json.loads(receipt.read_text())
        return meta['contract'] == contract and meta['sha256'] == _digest(path)
    except (ValueError, KeyError, OSError):
        return False


def _quarantine(path):
    path = Path(path)
    if path.exists():
        path.replace(path.with_name(path.name + '.incomplete-' + uuid.uuid4().hex[:8]))


def _locked_write(path, value):
    _json(path, value)
    _json(str(path) + '.receipt.json', dict(sha256=_digest(path)))


def _locked_read(path):
    path = Path(path)
    if not path.exists():
        return None
    try:
        return _BASE.read_locked_json(path)
    except (ValueError, KeyError, OSError):
        _quarantine(path); _quarantine(str(path) + '.receipt.json')
        return None


def _say(ctx, message):
    if ctx['runtime'].verbose:
        print(message, flush=True)


def _coerce_cfg(cfg):
    if isinstance(cfg, dict):
        return StudyCConfig(**cfg)
    return StudyCConfig(**asdict(cfg))


def _scientific_config(cfg):
    value = asdict(cfg) if not isinstance(cfg, dict) else dict(cfg)
    for name in ['train', 'test', 'output_dir', 'resume', 'n_jobs']:
        value.pop(name, None)
    return json.loads(_canonical(value))


def _initialize(cfg, runtime):
    cfg = _coerce_cfg(cfg)
    if cfg.run_shap and not cfg.save_representative_models:
        raise ValueError('run_shap=True requires save_representative_models=True')
    if runtime.workers < 1 or runtime.shap_batch_size < 1:
        raise ValueError('workers and shap_batch_size must be positive')
    if runtime.stage not in {'all', 'tune', 'fit', 'reports', 'shap'}:
        raise ValueError('stage must be all, tune, fit, reports or shap')
    out = Path(cfg.output_dir).expanduser().resolve()
    manifest_file = out / 'run_manifest.json'
    if not manifest_file.exists():
        ctx = _BASE.initialize_run(cfg)
    else:
        if not cfg.resume:
            raise ValueError('Existing outputs require resume=True or a new output folder')
        manifest = json.loads(manifest_file.read_text())
        if manifest.get('study') != 'C':
            raise ValueError('The existing output folder is not Study C')
        if manifest.get('source_snapshot_sha256') != hashlib.sha256(ORIGINAL_CORE_SOURCE.encode()).hexdigest():
            raise ValueError('The source folder was made by a different original script. Use a new output_dir.')
        if _scientific_config(cfg) != _scientific_config(manifest['config']):
            raise ValueError('Scientific settings changed. Restore the previous settings or choose a new output_dir.')
        paths = {role: _BASE.resolve_file(getattr(cfg, role)) for role in ['train', 'test']}
        for role, path in paths.items():
            if _digest(path) != manifest['input_sha256'][role]:
                raise ValueError(f'The {role} dataset differs from the original run')
        dev = _BASE.read_input(paths['train']).reset_index(drop=True)
        test = _BASE.read_input(paths['test']).reset_index(drop=True)
        if set(dev.global_id) & set(test.global_id) or set(dev.borehole_id) & set(test.borehole_id):
            raise ValueError('Study C requires record- and borehole-disjoint training/test data')
        if cfg.expected_test_records is not None and len(test) != cfg.expected_test_records:
            raise ValueError('Unexpected Study C test-record count')
        ids = pd.read_csv(out / 'split_identifiers.csv')
        for role, frame in [('train', dev), ('test', test)]:
            selected = ids.loc[ids.source_split == role]
            if selected.global_id.duplicated().any() or set(selected.global_id) != set(frame.global_id):
                raise ValueError('Saved split identifiers differ from the source datasets')
            np.testing.assert_array_equal(selected.set_index('global_id').loc[frame.global_id].borehole_id, frame.borehole_id)
        dev['source_split'] = 'train'; test['source_split'] = 'test'
        assigned = pd.read_csv(out / 'cv_fold_identifiers.csv')
        if assigned.global_id.duplicated().any() or set(assigned.global_id) != set(dev.global_id):
            raise ValueError('Saved CV folds do not cover the original training dataset')
        assigned = assigned.set_index('global_id').loc[dev.global_id]
        np.testing.assert_array_equal(assigned.borehole_id, dev.borehole_id)
        folds = [(np.flatnonzero(assigned.fold.to_numpy() != f), np.flatnonzero(assigned.fold.to_numpy() == f))
                 for f in sorted(assigned.fold.unique())]
        expected = _BASE.grouped_folds(dev, cfg.cv_folds, cfg.tuning_seed)
        if len(folds) != len(expected) or any(not np.array_equal(a, c) or not np.array_equal(b, d)
                                             for (a, b), (c, d) in zip(folds, expected)):
            raise ValueError('Saved grouped folds differ from the declared splitter and seed')
        ctx = dict(cfg=cfg, out=out, train=dev, dev=dev, test=test, cv_data=dev, folds=folds, manifest=manifest)
    engine_sha = _digest(__file__)
    ctx.update(runtime=runtime, engine_sha256=engine_sha, pipeline_started=time.perf_counter())
    ctx['cache_contract'] = _key(dict(engine=engine_sha, protocol=ctx['manifest']['protocol_signature']))
    ctx['memory'] = Memory(str(out / 'preprocessing_cache'), mmap_mode='r', verbose=0) if runtime.cache_preprocessing else None
    execution = dict(
        engine_revision=ENGINE_REVISION, engine_sha256=engine_sha,
        original_source_snapshot_sha256=hashlib.sha256(ORIGINAL_CORE_SOURCE.encode()).hexdigest(),
        original_protocol_signature=ctx['manifest']['protocol_signature'],
        runtime=asdict(runtime), scientific_settings_unchanged=True,
        status='VALIDATED', latest_start_utc=_now(), attempt_id=uuid.uuid4().hex,
        note='Original protocol/source fields identify the supplied scientific implementation. '
             'This execution manifest identifies the accelerated checkpoint engine. '
             'n_jobs/workers, preprocessing cache and stage are execution settings.',
    )
    _save_execution(ctx, execution)
    return ctx


def _save_execution(ctx, value):
    _json(ctx['out'] / 'execution_manifest.json', value)
    _json(ctx['out'] / 'execution_attempts' / (value['attempt_id'] + '.json'), value)


def _template(ctx, name, task, parameters=None):
    estimator = _BASE.build_estimator(name, task.polynomial_degree, ctx['cfg'].tuning_seed)
    if parameters:
        estimator.set_params(**{'regressor__model__' + k: v for k, v in parameters.items()})
    if ctx['memory'] is not None:
        estimator.set_params(regressor__memory=ctx['memory'])
    return estimator


def _parallel(ctx, jobs):
    if not jobs:
        return
    # Each process fits one estimator at a time; RF/XGB and BLAS stay single-threaded.
    with parallel_config(backend='loky', inner_max_num_threads=1):
        with Parallel(n_jobs=ctx['runtime'].workers, return_as='generator_unordered',
                      batch_size=1, pre_dispatch=ctx['runtime'].workers) as pool:
            for item in pool(jobs):
                yield item


def _cv_worker(estimator, X, y, tr, va, parameters, path, contract, candidate, fold):
    started = time.perf_counter()
    with threadpool_limits(limits=1):
        model = clone(estimator).set_params(**parameters)
        model.fit(X.iloc[tr], y.iloc[tr])
        fit_seconds = time.perf_counter() - started
        score_started = time.perf_counter()
        test_score = -float(np.sqrt(np.mean((y.iloc[va].to_numpy() - model.predict(X.iloc[va])) ** 2)))
        train_score = -float(np.sqrt(np.mean((y.iloc[tr].to_numpy() - model.predict(X.iloc[tr])) ** 2)))
    record = dict(candidate_id=candidate, fold=fold, parameters=parameters,
                  test_score=test_score, train_score=train_score,
                  fit_seconds=fit_seconds, score_seconds=time.perf_counter() - score_started)
    _json(path, record); _commit(path, contract)
    return candidate, fold


def _validate_cv_table(frame, candidates, folds):
    try:
        if len(frame) != len(candidates) or 'params' not in frame:
            return False
        params = [ast.literal_eval(p) if isinstance(p, str) else p for p in frame.params]
        if [_canonical(p) for p in params] != [_canonical(p) for p in candidates]:
            return False
        columns = [f'split{i}_{split}_score' for i in range(folds) for split in ['test', 'train']]
        if not set(columns) <= set(frame) or not np.isfinite(frame[columns].to_numpy(float)).all():
            return False
        tests = frame[[f'split{i}_test_score' for i in range(folds)]].to_numpy(float)
        return bool(np.allclose(tests.mean(axis=1), frame.mean_test_score, rtol=1e-12, atol=1e-12))
    except (ValueError, TypeError, KeyError, SyntaxError):
        return False


def _checkpointed_search(ctx, key, estimator, X, y, candidates, folds, cvpath):
    if ctx['runtime'].reuse_legacy_cv_results and Path(cvpath).is_file():
        try:
            legacy = pd.read_csv(cvpath)
            if _validate_cv_table(legacy, candidates, len(folds)):
                best = int(np.argmax(legacy.mean_test_score.to_numpy()))
                _say(ctx, f'Reusing complete search: {key}')
                return dict(parameters=candidates[best], best_score=float(legacy.mean_test_score.iloc[best]),
                            n_candidates=len(candidates), seconds=float(legacy.mean_fit_time.sum() * len(folds))
                            if 'mean_fit_time' in legacy else 0.0, reused_legacy=True)
        except (ValueError, OSError, pd.errors.EmptyDataError):
            pass
    folder = ctx['out'] / 'checkpoints' / 'cv' / key
    contract = _key(dict(base=ctx['cache_contract'], key=key, candidates=candidates))
    jobs = []
    for candidate, parameters in enumerate(candidates):
        for fold, (tr, va) in enumerate(folds):
            path = folder / f'candidate{candidate:03d}_fold{fold:02d}.json'
            if not _valid(path, contract):
                jobs.append(delayed(_cv_worker)(estimator, X, y, tr, va, parameters, path, contract, candidate, fold))
    total = len(candidates) * len(folds); done = total - len(jobs)
    _say(ctx, f'Tuning {key}: {done}/{total} candidate-fold checkpoints present; workers={ctx["runtime"].workers}')
    for _, _ in _parallel(ctx, jobs):
        done += 1
        _json(ctx['out'] / 'progress.json', dict(stage='tuning', task=key, completed=done, total=total, updated_utc=_now()))
        _say(ctx, f'  {key}: {done}/{total}')
    records = []
    for candidate, parameters in enumerate(candidates):
        scores = [json.loads((folder / f'candidate{candidate:03d}_fold{fold:02d}.json').read_text()) for fold in range(len(folds))]
        row = dict(params=parameters, **{'param_' + k: v for k, v in parameters.items()})
        for split in ['test', 'train']:
            values = np.array([s[split + '_score'] for s in scores])
            row.update({f'split{i}_{split}_score': float(v) for i, v in enumerate(values)})
            row['mean_' + split + '_score'] = float(values.mean())
            row['std_' + split + '_score'] = float(values.std(ddof=0))
        for label, field in [('fit', 'fit_seconds'), ('score', 'score_seconds')]:
            row['mean_' + label + '_time'] = float(np.mean([s[field] for s in scores]))
            row['std_' + label + '_time'] = float(np.std([s[field] for s in scores]))
        records.append(row)
    frame = pd.DataFrame(records)
    frame['rank_test_score'] = rankdata(-frame.mean_test_score.to_numpy(), method='min').astype(int)
    _csv(cvpath, frame)
    best = int(np.argmax(frame.mean_test_score.to_numpy()))
    return dict(parameters=candidates[best], best_score=float(frame.mean_test_score.iloc[best]),
                n_candidates=len(candidates), seconds=float(frame.mean_fit_time.sum() * len(folds)), reused_legacy=False)


def select_models_fast(ctx, task, analysis='primary'):
    key = _BASE.task_key(task, analysis); cfg = ctx['cfg']
    path = ctx['out'] / 'selection' / (key + '.json')
    selected = _locked_read(path)
    if selected is not None and selected.get('protocol_signature') != ctx['manifest']['protocol_signature']:
        raise ValueError('Saved selected settings have a different protocol signature')
    if selected is None:
        selected = dict(protocol_signature=ctx['manifest']['protocol_signature'], models={})
        for name in cfg.learners:
            part = ctx['out'] / 'checkpoints' / 'selected_models' / f'{key}_{name}.json'
            contract = _key(dict(base=ctx['cache_contract'], key=key, model=name))
            if _valid(part, contract):
                selected['models'][name] = json.loads(part.read_text())
                continue
            space = _BASE.search_space(name, 'smoke') if cfg.mode == 'smoke' else _BASE.reviewer_extended_search_space(name)
            if cfg.mode == 'smoke':
                space['regressor__model__n_estimators'] = [8]
            candidates = list(ParameterSampler(space, n_iter=min(cfg.search_iterations, len(ParameterGrid(space))), random_state=cfg.tuning_seed))
            record = _checkpointed_search(ctx, key + '_' + name, _template(ctx, name, task),
                                           ctx['cv_data'].loc[:, task.features], ctx['cv_data'][task.target],
                                           candidates, ctx['folds'], ctx['out'] / 'selection' / f'{key}_{name}_cv_results.csv')
            value = dict(parameters=_BASE.strip_model_prefix(record['parameters']), best_cv_neg_rmse=record['best_score'],
                         selection_status='Training-only grouped CV; candidate-fold checkpoints; settings locked before test predictions',
                         n_candidates=record['n_candidates'], seconds=record['seconds'],
                         polynomial_degree=task.polynomial_degree, raw_features=list(task.features), cv_policy=cfg.cv_policy,
                         timing_basis='Sum of completed candidate-fold fit durations; parallel wall time is recorded separately')
            _json(part, value); _commit(part, contract)
            selected['models'][name] = value
        _locked_write(path, selected)
    results, bounds = [], []
    if set(selected['models']) != set(cfg.learners):
        raise ValueError('Saved task selection has a different learner set')
    for name, value in selected['models'].items():
        results.append(dict(analysis=analysis, missing_type=task.missing_type, configuration=task.configuration,
                            target=task.target, model=name, **value))
        space = _BASE.search_space(name, 'smoke') if cfg.mode == 'smoke' else _BASE.reviewer_extended_search_space(name)
        if cfg.mode == 'smoke': space['regressor__model__n_estimators'] = [8]
        for param, parameter in value['parameters'].items():
            options = _BASE.strip_model_prefix(space).get(param, [])
            numeric = [x for x in options if isinstance(x, (int, float)) and not isinstance(x, bool)]
            bounds.append(dict(analysis=analysis, missing_type=task.missing_type, configuration=task.configuration,
                               target=task.target, model=name, parameter=param, value=json.dumps(parameter),
                               search_values=json.dumps(options), at_numeric_boundary=bool(numeric and parameter in [min(numeric), max(numeric)]),
                               interpretation='Boundary relative to the declared training-only search distribution'))
    _csv(ctx['out'] / 'selection' / f'{key}_selected.csv', pd.DataFrame(results))
    _csv(ctx['out'] / 'selection' / f'{key}_boundaries.csv', pd.DataFrame(bounds))
    return {name: _template(ctx, name, task, value['parameters']) for name, value in selected['models'].items()}


def select_ridge_fast(ctx, task):
    key = _BASE.task_key(task); path = ctx['out'] / 'selection' / f'{key}_RK_alpha.json'
    saved = _locked_read(path)
    if saved is not None: return float(saved['ridge_alpha'])
    features = _BASE.nonspatial_features(task)
    estimator = _BASE.ridge_pipeline(task, 1)
    if ctx['memory'] is not None: estimator.set_params(memory=ctx['memory'])
    record = _checkpointed_search(ctx, key + '_RK_alpha', estimator, ctx['cv_data'][features], ctx['cv_data'][task.target],
                                   [{'ridge__alpha': a} for a in ctx['cfg'].ridge_alphas], ctx['folds'], path.with_suffix('.csv'))
    alpha = float(record['parameters']['ridge__alpha'])
    _locked_write(path, dict(ridge_alpha=alpha, selection='Development-only grouped CV for trend RMSE, not joint RK optimization',
                            best_cv_neg_rmse=record['best_score'], features=features, polynomial_degree=task.polynomial_degree))
    return alpha


def _prediction_valid(ctx, path):
    path = Path(path); receipt = path.with_name(path.name + '.sha256.json')
    if not path.exists(): return False
    try:
        meta = json.loads(receipt.read_text())
        if meta['protocol_signature'] != ctx['manifest']['protocol_signature']:
            raise RuntimeError('Foreign protocol in prediction record: ' + path.name)
        if _digest(path) == meta['sha256']: return True
    except (OSError, ValueError, KeyError):
        pass
    _quarantine(path); _quarantine(receipt)
    _say(ctx, 'Incomplete prediction preserved for audit; rebuilding ' + path.name)
    return False


def _representative_valid(ctx, task, analysis):
    path = ctx['out'] / 'models' / f'{_BASE.task_key(task, analysis)}_seed{ctx["cfg"].representative_seed}.joblib'
    if not path.exists(): return False
    contract = _key(dict(base=ctx['cache_contract'], bundle=_BASE.task_key(task, analysis), seed=ctx['cfg'].representative_seed))
    if _valid(path, contract): return True
    try:
        value = joblib.load(path)
        valid = (value['protocol_signature'] == ctx['manifest']['protocol_signature']
                and set(value['models']) == set(ctx['cfg'].learners)
                and value['features'] == list(task.features)
                and value['analysis'] == analysis and value['seed'] == ctx['cfg'].representative_seed)
        if valid: _commit(path, contract)
        else: _quarantine(path)
        return valid
    except Exception:
        _quarantine(path)
        return False


def _final_worker(estimator, X, y, Xtest, seed, prediction_file, model_file, contract, timing_file, metadata):
    # The worker commits each learner independently, so another learner's failure
    # or a kernel interruption cannot discard already committed predictions.
    started = time.perf_counter()
    model = clone(estimator)
    model.set_params(**{name: seed for name in model.get_params() if name.endswith('random_state')})
    with threadpool_limits(limits=1):
        model.fit(X, y)
        seconds = time.perf_counter() - started
        development = model.predict(X); test = model.predict(Xtest)
    if model_file is not None:
        _joblib(model_file, model); _commit(model_file, contract)
    _npz(prediction_file, development=development, test=test)
    _commit(prediction_file, contract)
    _json(timing_file, dict(**metadata, fit_seconds=seconds))
    return metadata['model'], seed


def fit_learner_task_fast(ctx, task, analysis='primary'):
    cfg = ctx['cfg']; templates = select_models_fast(ctx, task, analysis)
    key = _BASE.task_key(task, analysis)
    dev, test = ctx['dev'], ctx['test']
    pending, jobs = [], []
    for seed in range(cfg.base_seed, cfg.base_seed + cfg.runs):
        path = _BASE.prediction_path(ctx, task, seed, analysis)
        existing = _prediction_valid(ctx, path)
        needs_model = cfg.save_representative_models and seed == cfg.representative_seed
        if existing and (not needs_model or _representative_valid(ctx, task, analysis)):
            continue
        pending.append((seed, path, existing, needs_model))
        for name, estimator in templates.items():
            part = ctx['out'] / 'checkpoints' / 'final' / key / f'{name}_seed{seed}.npz'
            model_file = part.with_suffix('.joblib') if needs_model else None
            contract = _key(dict(base=ctx['cache_contract'], key=key, seed=seed, model=name,
                                 parameters={k: v for k, v in estimator.get_params().items()
                                             if k.startswith('regressor__model__')}))
            ready = _valid(part, contract) and (not needs_model or _valid(model_file, contract))
            if not ready:
                meta = dict(analysis=analysis, missing_type=task.missing_type, configuration=task.configuration,
                            target=task.target, model=name, seed=seed)
                timing = ctx['out'] / 'timing' / f'{key}_{name}_{seed}.json'
                jobs.append(delayed(_final_worker)(estimator, dev.loc[:, task.features], dev[task.target],
                            test.loc[:, task.features], seed, part, model_file, contract, timing, meta))
    _say(ctx, f'Fitting {key}: {len(pending)} remaining seeds, {len(jobs)} remaining learner fits')
    for name, seed in _parallel(ctx, jobs):
        _json(ctx['out'] / 'progress.json', dict(stage='final_fitting', task=key, learner=name, seed=seed, updated_utc=_now()))
        _say(ctx, f'  Saved {key} {name} seed {seed}')
    for seed, path, existing, needs_model in pending:
        records = {label: _BASE.base_prediction_frame(ctx, task, seed, analysis, label, data)
                   for label, data in [('Development', dev), ('Test', test)]}
        fitted = {}
        for name in cfg.learners:
            part = ctx['out'] / 'checkpoints' / 'final' / key / f'{name}_seed{seed}.npz'
            with np.load(part, allow_pickle=False) as data:
                records['Development']['prediction_' + name] = data['development']
                records['Test']['prediction_' + name] = data['test']
            if needs_model: fitted[name] = joblib.load(part.with_suffix('.joblib'))
        for frame in records.values():
            frame['prediction_' + cfg.ensemble_label] = frame[['prediction_' + n for n in cfg.learners]].mean(axis=1)
        if needs_model:
            bundle = ctx['out'] / 'models' / f'{key}_seed{seed}.joblib'
            _joblib(bundle, dict(models=fitted, features=list(task.features), task=asdict(task), analysis=analysis,
                                 seed=seed, protocol_signature=ctx['manifest']['protocol_signature']))
            _commit(bundle, _key(dict(base=ctx['cache_contract'], bundle=key, seed=seed)))
        if existing:
            old = _BASE.read_prediction_part(ctx, path)
            new = pd.concat(records.values(), ignore_index=True)
            for name in cfg.learners:
                np.testing.assert_allclose(new['prediction_' + name], old['prediction_' + name], rtol=1e-8, atol=1e-8)
        else:
            _BASE.write_prediction_part(ctx, path, pd.concat(records.values(), ignore_index=True))
        if needs_model:
            # The permanent bundle and canonical predictions now exist. Retain
            # small per-learner prediction checkpoints, but remove duplicate
            # temporary model dumps to avoid doubling representative-model disk use.
            for name in cfg.learners:
                temp_model = ctx['out'] / 'checkpoints' / 'final' / key / f'{name}_seed{seed}.joblib'
                temp_model.unlink(missing_ok=True)
                Path(str(temp_model) + '.checkpoint.json').unlink(missing_ok=True)


def _stage_contract(ctx, name, dependencies):
    return _key(dict(base=ctx['cache_contract'], stage=name, dependencies=dependencies))


def _stage(ctx, name, dependencies, function, outputs):
    marker = ctx['out'] / 'checkpoints' / 'stages' / (name + '.json')
    contract = _stage_contract(ctx, name, dependencies)
    if _valid(marker, contract):
        meta = json.loads(marker.read_text())
        if all(Path(p).exists() and _digest(p) == digest for p, digest in meta['outputs'].items()):
            _say(ctx, 'Reusing completed stage: ' + name)
            return
    _say(ctx, 'Running stage: ' + name)
    function()
    paths = outputs() if callable(outputs) else outputs
    paths = [Path(p) for p in paths]
    if not paths or any(not p.is_file() for p in paths):
        raise RuntimeError('A required output is missing after stage ' + name)
    _json(marker, dict(outputs={str(p): _digest(p) for p in paths}, completed_utc=_now()))
    _commit(marker, contract)


def _sensitivity_fast(ctx):
    tasks = [t for t in _BASE.study_tasks(ctx['cfg']) if t.configuration == 'XYZ']
    legacy = None
    legacy_file = ctx['out'] / 'development_variogram_sensitivity.csv'
    if legacy_file.exists():
        try:
            candidate = pd.read_csv(legacy_file)
            if len(candidate) == len(tasks) * 18 and np.isfinite(candidate.development_holdout_rmse).all():
                legacy = candidate
        except (ValueError, AttributeError, pd.errors.EmptyDataError):
            pass
    parts = []
    for task in tasks:
        name = f'sensitivity_{task.missing_type}_{task.target}'
        folder = ctx['out'] / 'checkpoints' / 'sensitivity' / name
        path = folder / 'development_variogram_sensitivity.csv'
        marker = ctx['out'] / 'checkpoints' / 'stages' / (name + '.json')
        contract = _stage_contract(ctx, name, [])
        if legacy is not None and not _valid(marker, contract):
            part = legacy.loc[(legacy.missing_type == task.missing_type) & (legacy.target == task.target)]
            if len(part) == 18 and not part.duplicated(['model', 'range_quantile', 'nugget_fraction']).any():
                _csv(path, part)
                for filename in ['sensitivity_development_training_ids.csv', 'sensitivity_development_holdout_ids.csv']:
                    if (ctx['out'] / filename).exists(): _csv(folder / filename, pd.read_csv(ctx['out'] / filename))
                _json(marker, dict(outputs={str(path): _digest(path)}, completed_utc=_now(), imported_complete_legacy=True))
                _commit(marker, contract)
        def execute(task=task, folder=folder):
            folder.mkdir(parents=True, exist_ok=True)
            # A missing stage receipt means a prior CSV write may have stopped.
            # Preserve that file, then rerun only this task's sensitivity block.
            if path.exists(): _quarantine(path)
            child = dict(ctx, out=folder, cfg=replace(ctx['cfg'], missing_types=(task.missing_type,), targets=(task.target,), n_jobs=1))
            with threadpool_limits(limits=1): _BASE.development_variogram_sensitivity(child)
        _stage(ctx, name, [], execute, [path])
        parts.append(pd.read_csv(path))
    if parts:
        _csv(ctx['out'] / 'development_variogram_sensitivity.csv', pd.concat(parts, ignore_index=True))
        first = ctx['out'] / 'checkpoints' / 'sensitivity' / f'sensitivity_{tasks[0].missing_type}_{tasks[0].target}'
        for name in ['sensitivity_development_training_ids.csv', 'sensitivity_development_holdout_ids.csv']:
            _csv(ctx['out'] / name, pd.read_csv(first / name))


def _repair_comparator_interruption(ctx):
    for path in (ctx['out'] / 'prediction_record').glob('*_comparators_seed*.csv.gz'):
        _prediction_valid(ctx, path)
    for path in (ctx['out'] / 'comparator_metadata').glob('OK_all_test_*.csv'):
        receipt = path.with_suffix('.json')
        try:
            good = json.loads(receipt.read_text())['prediction_sha256'] == _digest(path)
        except (OSError, ValueError, KeyError): good = False
        if not good:
            _quarantine(path); _quarantine(receipt)


def _all_prediction_paths(ctx):
    cfg = ctx['cfg']; paths = []
    analyses = ['primary'] + (['no_polynomial'] if cfg.run_polynomial_ablation else [])
    for analysis in analyses:
        for task in _BASE.study_tasks(cfg, analysis):
            paths.extend(_BASE.prediction_path(ctx, task, seed, analysis)
                         for seed in range(cfg.base_seed, cfg.base_seed + cfg.runs))
    if cfg.comparators:
        for task in _BASE.study_tasks(cfg):
            if task.configuration == 'XYZ':
                paths.extend(_BASE.prediction_path(ctx, task, seed, kind='comparators')
                             for seed in range(cfg.base_seed, cfg.base_seed + cfg.runs))
    return sorted(paths)


def _equivalent_frame(left, right):
    if left.shape != right.shape or list(left.columns) != list(right.columns): return False
    for name in left:
        if pd.api.types.is_numeric_dtype(left[name]) and pd.api.types.is_numeric_dtype(right[name]):
            if not np.allclose(left[name].to_numpy(float), right[name].to_numpy(float), rtol=1e-13, atol=1e-13, equal_nan=True):
                return False
        elif not left[name].fillna('').astype(str).equals(right[name].fillna('').astype(str)):
            return False
    return True


def _metrics_fast(ctx):
    paths = _all_prediction_paths(ctx); index = []; parts = []; test_frames = []
    for number, path in enumerate(paths, 1):
        if not _prediction_valid(ctx, path):
            raise FileNotFoundError('Incomplete predictions; run stage="fit" or "all" first: ' + path.name)
        receipt = json.loads(path.with_name(path.name + '.sha256.json').read_text())
        index.append(dict(file=path.name, sha256=receipt['sha256'], rows=receipt['rows'],
                          protocol_signature=ctx['manifest']['protocol_signature']))
        cached = ctx['out'] / 'checkpoints' / 'metrics' / (path.name + '.joblib')
        contract = _stage_contract(ctx, 'metrics_part', [path.name, receipt['sha256']])
        if _valid(cached, contract):
            stored = joblib.load(cached)
        else:
            frame = _BASE.read_prediction_part(ctx, path); rows = []
            for split, g in frame.groupby('split', sort=False):
                key = {k: g.iloc[0][k] for k in ['analysis', 'missing_type', 'configuration', 'target', 'seed', 'study', 'output_class']}
                key.update(split=split, n_records=len(g), n_boreholes=g.borehole_id.nunique())
                for col in [c for c in g if c.startswith('prediction_')]:
                    if g[col].isna().any(): raise ValueError('Missing predictions in ' + path.name)
                    rows.append(dict(**key, model=col.removeprefix('prediction_'), **_BASE.metrics_from_arrays(
                        g.actual, g[col], float(g.target_scale.iloc[0]), ctx['cfg'].robust_delta)))
            tests = frame.loc[frame.split == 'Test'].copy() if path.name.startswith('primary_') and '_learners_seed' in path.name else None
            stored = dict(metrics=pd.DataFrame(rows), tests=tests)
            _joblib(cached, stored); _commit(cached, contract)
        parts.append(stored['metrics'])
        if stored['tests'] is not None: test_frames.append(stored['tests'])
        if number % 200 == 0: _say(ctx, f'Metrics: {number}/{len(paths)} prediction files')
    metrics = pd.concat(parts, ignore_index=True)
    unique = ['analysis', 'missing_type', 'configuration', 'target', 'seed', 'split', 'model']
    if metrics.duplicated(unique).any(): raise ValueError('Duplicate metric keys')
    for _, group in metrics.groupby(['analysis', 'missing_type', 'configuration', 'target', 'split', 'model']):
        if set(group.seed) != set(range(ctx['cfg'].base_seed, ctx['cfg'].base_seed + ctx['cfg'].runs)):
            raise ValueError('Incomplete metric seed set')
    index_path = ctx['out'] / 'prediction_record_index.csv'
    try:
        old_index = pd.read_csv(index_path) if index_path.exists() else pd.DataFrame()
    except (ValueError, OSError):
        _quarantine(index_path)
        old_index = pd.DataFrame()
    same_index = _equivalent_frame(old_index, pd.DataFrame(index))
    if not same_index: _csv(index_path, pd.DataFrame(index))
    metrics_path = ctx['out'] / 'run_metrics_from_predictions.csv'
    preserved_metrics = False
    if same_index and metrics_path.exists():
        try:
            old_metrics = pd.read_csv(metrics_path)
            if _equivalent_frame(old_metrics, metrics):
                metrics = old_metrics
                preserved_metrics = True
        except (ValueError, OSError):
            pass
    if not preserved_metrics: _csv(metrics_path, metrics)
    ctx['_primary_tests'] = pd.concat(test_frames, ignore_index=True) if test_frames else pd.DataFrame()
    return metrics


def _with_test_cache(name, ctx, *args):
    namespace = dict(_BASE.__dict__)
    namespace['test_prediction_records'] = lambda context, analysis='primary': context['_primary_tests']
    fn = getattr(_BASE, name)
    cached = types.FunctionType(fn.__code__, namespace, fn.__name__, fn.__defaults__, fn.__closure__)
    return cached(ctx, *args)


def _reports(ctx):
    metrics = _metrics_fast(ctx)
    _BASE.verify_ok_invariance(ctx, metrics)
    summary = _BASE.summarize_run_metrics(metrics)
    _csv(ctx['out'] / 'summary_mean_sd_fitting.csv', summary)
    dependencies = [_digest(ctx['out'] / 'prediction_record_index.csv')]
    _stage(ctx, 'fitting_stability', dependencies, lambda: _BASE.fitting_stability(metrics, ctx),
           [ctx['out'] / 'fitting_stability_wilcoxon_holm.csv', ctx['out'] / 'improvement_by_seed.csv'])
    _stage(ctx, 'borehole_bootstrap', dependencies, lambda: _with_test_cache('borehole_bootstrap', ctx),
           [ctx['out'] / 'primary_borehole_bootstrap.csv'])
    _stage(ctx, 'train_test_gaps', dependencies, lambda: _BASE.train_test_gaps(metrics, ctx),
           [ctx['out'] / 'train_test_gap_by_seed.csv'])
    _stage(ctx, 'constituent_diagnostics', dependencies, lambda: _with_test_cache('constituent_diagnostics', ctx, metrics),
           [ctx['out'] / 'learner_error_correlations_by_seed.csv', ctx['out'] / 'ensemble_robustness_by_task.csv'])
    if ctx['cfg'].run_polynomial_ablation:
        _stage(ctx, 'polynomial_ablation', dependencies, lambda: _BASE.polynomial_ablation_summary(metrics, ctx),
               [ctx['out'] / 'polynomial_ablation_paired.csv'])
    stability = pd.read_csv(ctx['out'] / 'fitting_stability_wilcoxon_holm.csv')
    bootstrap = pd.read_csv(ctx['out'] / 'primary_borehole_bootstrap.csv')
    _stage(ctx, 'tables', dependencies, lambda: _BASE.export_tables(ctx, metrics, summary, stability, bootstrap),
           lambda: [p for p in (ctx['out'] / 'tables').glob('*') if 'fit_time' not in p.name])
    _stage(ctx, 'prediction_figures', dependencies, lambda: _BASE.regenerate_prediction_figures(ctx),
           lambda: list((ctx['out'] / 'figures').glob('StudyC_*.png'))
                   + list((ctx['out'] / 'figures').glob('StudyC_*.provenance.json')))
    if ctx['cfg'].save_representative_models and 'MT1' in ctx['cfg'].missing_types:
        _stage(ctx, 'feature_importance', dependencies, lambda: _BASE.regenerate_mt1_importance(ctx),
               lambda: [ctx['out'] / 'MT1_global_importance.csv']
                       + list((ctx['out'] / 'figures').glob('*importance*')))
    return metrics, stability, bootstrap


def _shap_predictor(obj, features):
    """Share identical polynomial/scaler transforms across the three learners."""
    models = list(obj['models'].values())
    first = models[0].regressor_.named_steps
    compatible = True
    for model in models[1:]:
        steps = model.regressor_.named_steps
        compatible &= (steps['poly'].get_params() == first['poly'].get_params())
        compatible &= np.array_equal(steps['scale'].mean_, first['scale'].mean_)
        compatible &= np.array_equal(steps['scale'].scale_, first['scale'].scale_)

    def reference(values):
        frame = pd.DataFrame(np.asarray(values), columns=features)
        return np.mean(np.column_stack([model.predict(frame) for model in models]), axis=1)

    def shared(values):
        frame = pd.DataFrame(np.asarray(values), columns=features)
        expanded = first['poly'].transform(frame)
        scaled = first['scale'].transform(expanded)
        predictions = []
        for model in models:
            raw = np.asarray(model.regressor_.named_steps['model'].predict(scaled)).reshape(-1, 1)
            predictions.append(model.transformer_.inverse_transform(raw).reshape(-1))
        return np.mean(np.column_stack(predictions), axis=1)
    return (shared if compatible else reference), reference


def _rng_arrays():
    kind, keys, position, has_gauss, cached = np.random.get_state()
    return dict(rng_kind=np.asarray(kind), rng_keys=keys, rng_position=np.asarray(position),
                rng_has_gauss=np.asarray(has_gauss), rng_cached=np.asarray(cached))


def _restore_rng(data):
    np.random.set_state((str(data['rng_kind'].item()), data['rng_keys'], int(data['rng_position']),
                         int(data['rng_has_gauss']), float(data['rng_cached'])))


def _legacy_shap_valid(ctx, prefix, task, obj, model_file, evaluation, background):
    folder = ctx['out'] / 'shap'; image = folder / (prefix + '_beeswarm.png')
    prov = image.with_suffix('.provenance.json'); values = folder / (prefix + '_values.npz')
    if not all(p.exists() for p in [image, prov, values]): return False
    try:
        d = json.loads(prov.read_text())
        valid = (d['protocol_signature'] == ctx['manifest']['protocol_signature']
                 and d['figure_sha256'] == _digest(image) and d['model_sha256'] == _digest(model_file)
                 and d['evaluation_global_ids'] == evaluation.global_id.tolist()
                 and d['background_global_ids'] == background.global_id.tolist())
        for suffix in ['_evaluation_ids.csv', '_background_ids.csv', '_additivity.csv']:
            valid &= (folder / (prefix + suffix)).exists()
        if task.target in {'su', 'E50'}:
            force = folder / (prefix + '_local_force.png'); force_prov = force.with_suffix('.provenance.json')
            valid &= force.exists() and force_prov.exists()
            if force.exists() and force_prov.exists(): valid &= _digest(force) == json.loads(force_prov.read_text())['figure_sha256']
        return bool(valid)
    except (OSError, KeyError, ValueError):
        return False


def regenerate_shap_fast(ctx):
    import shap
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    cfg = ctx['cfg']; folder = ctx['out'] / 'shap'; folder.mkdir(exist_ok=True)
    specification = [('MT1', 'su'), ('MT4', 'su'), ('MT1', 'E50'), ('MT4', 'E50'),
                     ('MT1', 'Pc'), ('MT1', 'Cc'), ('MT1', 'Cv'), ('MT3', 'Pc'), ('MT3', 'Cc'), ('MT3', 'Cv')]
    rankings = []
    for mt, target in specification:
        matching = [t for t in _BASE.study_tasks(cfg) if t.missing_type == mt and t.target == target and t.configuration == 'XYZ']
        if not matching: continue
        task = matching[0]
        obj, model_file = _BASE.load_representative(ctx, task)
        _BASE.save_feature_mapping(ctx, task, obj)
        rng = np.random.default_rng(cfg.representative_seed)
        ids = np.sort(rng.choice(len(ctx['dev']), min(cfg.shap_background_size, len(ctx['dev'])), replace=False))
        background = ctx['dev'].iloc[ids]
        heldout = cfg.shap_scope == 'heldout_all' or target in {'su', 'E50'}
        evaluation = ctx['test'] if heldout else ctx['dev']
        population = 'Complete Study C held-out test observations' if heldout else 'Study C training observations; interpretation only'
        if not heldout and cfg.shap_max_development_samples is not None and len(evaluation) > cfg.shap_max_development_samples:
            choice = np.sort(rng.choice(len(evaluation), cfg.shap_max_development_samples, replace=False))
            evaluation = evaluation.iloc[choice]; population += '; explicitly subsampled'
        X, B = evaluation.loc[:, task.features], background.loc[:, task.features]
        predict, reference = _shap_predictor(obj, task.features)
        np.testing.assert_allclose(predict(X), reference(X), rtol=1e-12, atol=1e-12)
        np.testing.assert_allclose(predict(B), reference(B), rtol=1e-12, atol=1e-12)
        stored = _BASE.read_prediction_part(ctx, _BASE.prediction_path(ctx, task, cfg.representative_seed))
        stored = stored.loc[stored.split == ('Test' if heldout else 'Development')].set_index('global_id')
        predictions = predict(X)
        np.testing.assert_allclose(predictions, stored.loc[evaluation.global_id, 'prediction_' + cfg.ensemble_label], rtol=1e-8, atol=1e-8)
        prefix = f'StudyC_SHAP_{mt}_{target}'; budget = 10 * (2 * len(task.features) + 1)
        contract = _stage_contract(ctx, 'shap_' + prefix, dict(
            model=_digest(model_file), evaluation=evaluation.global_id.tolist(), background=background.global_id.tolist(),
            features=list(task.features), budget=budget, batch_size=ctx['runtime'].shap_batch_size, shap_version=shap.__version__))
        marker = ctx['out'] / 'checkpoints' / 'shap' / (prefix + '_complete.json')
        legacy = _legacy_shap_valid(ctx, prefix, task, obj, model_file, evaluation, background)
        completed = False
        if _valid(marker, contract):
            d = json.loads(marker.read_text())
            completed = all(Path(p).exists() and _digest(p) == digest for p, digest in d['outputs'].items())
        if completed or legacy:
            _say(ctx, 'Reusing complete SHAP result: ' + prefix)
            with np.load(folder / (prefix + '_values.npz'), allow_pickle=False) as saved:
                np.testing.assert_array_equal(saved['global_ids'], evaluation.global_id)
                np.testing.assert_array_equal(saved['feature_names'], np.asarray(task.features))
                np.testing.assert_array_equal(saved['data'], X.to_numpy())
                values = saved['values']; bases = saved['base_values'].reshape(-1)
            explanation = shap.Explanation(values=values, base_values=bases, data=X.to_numpy(), feature_names=list(task.features))
            _BASE.validate_shap_additivity(explanation, predictions, evaluation.global_id.to_numpy(),
                                          folder / (prefix + '_additivity.csv'), feature_count=len(task.features))
        else:
            masker = _BASE.make_exact_shap_masker(B)
            explainer = shap.PermutationExplainer(predict, masker, feature_names=list(task.features), seed=cfg.representative_seed)
            chunks, base_chunks = [], []
            batch = ctx['runtime'].shap_batch_size
            for start in range(0, len(X), batch):
                stop = min(start + batch, len(X))
                path = ctx['out'] / 'checkpoints' / 'shap' / prefix / f'rows_{start:06d}_{stop:06d}.npz'
                if _valid(path, contract):
                    with np.load(path, allow_pickle=False) as saved:
                        np.testing.assert_array_equal(saved['global_ids'], evaluation.global_id.iloc[start:stop])
                        values = saved['values'].copy(); bases = saved['base_values'].reshape(-1).copy()
                        _restore_rng(saved)
                else:
                    with threadpool_limits(limits=1):
                        part = explainer(X.iloc[start:stop], max_evals=budget, silent=True)
                    values = np.asarray(part.values)
                    bases = np.broadcast_to(np.asarray(part.base_values).reshape(-1), (stop - start,)).copy()
                    reconstructed = bases + values.sum(axis=1)
                    np.testing.assert_allclose(reconstructed, predictions[start:stop], rtol=1e-6, atol=1e-6)
                    _npz(path, values=values, base_values=bases, global_ids=evaluation.global_id.iloc[start:stop].to_numpy(), **_rng_arrays())
                    _commit(path, contract)
                chunks.append(values); base_chunks.append(bases)
                _json(ctx['out'] / 'progress.json', dict(stage='shap', task=prefix, completed=stop, total=len(X), updated_utc=_now()))
                _say(ctx, f'SHAP {mt} {target}: {stop}/{len(X)} observations checkpointed')
            values = np.concatenate(chunks); bases = np.concatenate(base_chunks)
            explanation = shap.Explanation(values=values, base_values=bases, data=X.to_numpy(), feature_names=list(task.features))
            additivity = _BASE.validate_shap_additivity(explanation, predictions, evaluation.global_id.to_numpy(),
                                                       folder / (prefix + '_additivity.csv'), feature_count=len(task.features))
            _npz(folder / (prefix + '_values.npz'), values=values, base_values=bases, data=X.to_numpy(),
                 feature_names=np.asarray(task.features), global_ids=evaluation.global_id.to_numpy())
            _csv(folder / (prefix + '_evaluation_ids.csv'), evaluation[['global_id', 'borehole_id']])
            _csv(folder / (prefix + '_background_ids.csv'), background[['global_id', 'borehole_id']])
            shap.plots.beeswarm(explanation, max_display=len(task.features), show=False)
            plt.title(f'Study C {mt} {target}: n={len(evaluation)}, boreholes={evaluation.borehole_id.nunique()}')
            plt.tight_layout(); image = folder / (prefix + '_beeswarm.png')
            plt.savefig(image, dpi=180, bbox_inches='tight'); plt.close('all')
            provenance = dict(seed=cfg.representative_seed, missing_type=mt, target=target, configuration='XYZ', population=population,
                n_evaluation_records=len(evaluation), n_evaluation_boreholes=evaluation.borehole_id.nunique(),
                evaluation_global_ids=evaluation.global_id.tolist(), background_global_ids=background.global_id.tolist(),
                background_seed=cfg.representative_seed, background_size=len(background), model_file=model_file.name,
                model_sha256=_digest(model_file), method='Permutation SHAP on complete raw-input ensemble pipelines',
                max_evals=budget, output_units='Original target units after inverse transformation', shap_version=shap.__version__,
                masker_invariants='Exact equality (np.equal)', additivity_validation=additivity,
                engine_revision=ENGINE_REVISION, engine_sha256=ctx['engine_sha256'], shap_batch_size=batch,
                checkpointing='Contiguous batches with saved NumPy RNG state',
                sampling_note='Batched calls can change Monte Carlo SHAP values relative to an unbatched historical run; '
                              'background, sample population and per-observation evaluation budget are retained.',
                attribution_mapping='Pre-polynomial input features; no aggregation of transformed-term SHAP values',
                dependence_caution='Independent masking does not preserve predictor dependence; associations are not causal')
            _BASE.record_figure(ctx, image, provenance)
            if target in {'su', 'E50'}:
                shap.force_plot(float(bases[0]), values[0], X.iloc[0], matplotlib=True, show=False)
                force = folder / (prefix + '_local_force.png')
                plt.savefig(force, dpi=180, bbox_inches='tight'); plt.close('all')
                _BASE.record_figure(ctx, force, dict(provenance, local_global_id=int(evaluation.global_id.iloc[0])))
        importance = np.mean(np.abs(values), axis=0)
        for rank, i in enumerate(np.argsort(-importance), 1):
            rankings.append(dict(missing_type=mt, target=target, feature=task.features[i], rank=rank,
                                  mean_abs_shap=float(importance[i]), population=population, n_evaluation=len(evaluation), seed=cfg.representative_seed))
        outputs = [folder / (prefix + suffix) for suffix in ['_values.npz', '_evaluation_ids.csv', '_background_ids.csv',
                                                             '_additivity.csv', '_beeswarm.png', '_beeswarm.provenance.json']]
        if target in {'su', 'E50'}:
            outputs += [folder / (prefix + suffix) for suffix in ['_local_force.png', '_local_force.provenance.json']]
        _json(marker, dict(outputs={str(p): _digest(p) for p in outputs}, completed_utc=_now()))
        _commit(marker, contract)
    ranking = pd.DataFrame(rankings)
    _csv(folder / 'shap_feature_rankings.csv', ranking)
    if not ranking.empty:
        pc = ranking.loc[(ranking.missing_type == 'MT3') & (ranking.target == 'Pc')]
        if not pc.empty:
            _json(folder / 'Pc_MT3_abstract_alignment_check.json', dict(top_feature=pc.sort_values('rank').feature.iloc[0],
                  action='Align abstract, caption and discussion with this ranking'))
    return ranking


def checkpoint_status(cfg):
    """Read-only overview. Does not fit models or change run settings."""
    cfg = _coerce_cfg(cfg); out = Path(cfg.output_dir).expanduser()
    counts = dict(cv_fold_checkpoints=sum(not p.name.endswith('.checkpoint.json')
                                         for p in (out / 'checkpoints' / 'cv').glob('**/candidate*_fold*.json')),
                  selected_task_files=sum(not p.name.endswith('.receipt.json')
                                          for p in (out / 'selection').glob('*.json')),
                  learner_prediction_files=len(list((out / 'prediction_record').glob('*_learners_seed*.csv.gz'))),
                  comparator_prediction_files=len(list((out / 'prediction_record').glob('*_comparators_seed*.csv.gz'))),
                  shap_batch_checkpoints=len(list((out / 'checkpoints' / 'shap').glob('**/rows_*.npz'))))
    progress = out / 'progress.json'
    if progress.exists(): counts['latest_progress'] = json.loads(progress.read_text())
    execution = out / 'execution_manifest.json'
    if execution.exists(): counts['execution_status'] = json.loads(execution.read_text()).get('status')
    return counts


def run_study_c_fast(cfg, runtime=None, validate_only=False):
    runtime = RuntimeOptions() if runtime is None else runtime
    cfg = replace(_coerce_cfg(cfg), n_jobs=1)
    ctx = _initialize(cfg, runtime)
    primary = list(_BASE.study_tasks(cfg))
    analyses = ['primary'] + (['no_polynomial'] if cfg.run_polynomial_ablation else [])
    tasks = [(analysis, task) for analysis in analyses for task in _BASE.study_tasks(cfg, analysis)]
    _say(ctx, f'Study C: {len(ctx["dev"])} training records, {len(ctx["test"])} test records; '
              f'{len(tasks)} learner tasks; stage={runtime.stage}; workers={runtime.workers}')
    if validate_only: return ctx
    execution_path = ctx['out'] / 'execution_manifest.json'
    execution = json.loads(execution_path.read_text())
    stage = runtime.stage
    try:
        if stage in {'all', 'tune', 'fit'} and 'XGB' in cfg.learners:
            _BASE.get_xgb_regressor(cfg.tuning_seed)
        if stage in {'all', 'shap'} and cfg.run_shap:
            try: __import__('shap')
            except ImportError as exc:
                raise RuntimeError('Install SHAP for stage=all/shap, or run stage=fit/reports first. Scientific settings need not change.') from exc
        if stage in {'all', 'tune', 'fit'}:
            execution['status'] = 'TUNING'; _save_execution(ctx, execution)
            for analysis, task in tasks: select_models_fast(ctx, task, analysis)
            if cfg.comparators:
                for task in primary:
                    if task.configuration == 'XYZ': select_ridge_fast(ctx, task)
            if cfg.run_variogram_sensitivity and cfg.comparators: _sensitivity_fast(ctx)
            ctx['manifest'].update(status='SETTINGS_LOCKED_BEFORE_TEST_PREDICTION', selection_locked_time_utc=_now())
            _json(ctx['out'] / 'run_manifest.json', ctx['manifest'])
            if stage == 'tune':
                execution.update(status='TUNING_COMPLETE', completed_utc=_now()); _save_execution(ctx, execution)
                return ctx
            execution['status'] = 'FITTING'; _save_execution(ctx, execution)
            for analysis, task in tasks: fit_learner_task_fast(ctx, task, analysis)
            if cfg.comparators:
                _repair_comparator_interruption(ctx)
                with threadpool_limits(limits=1): _BASE.fit_comparators(ctx)
            if stage == 'fit':
                ctx['manifest'].update(status='PREDICTIONS_COMPLETE_REPORTS_PENDING')
                _json(ctx['out'] / 'run_manifest.json', ctx['manifest'])
                execution.update(status='PREDICTIONS_COMPLETE', completed_utc=_now()); _save_execution(ctx, execution)
                return ctx
        report_values = None
        if stage in {'all', 'reports'}:
            execution['status'] = 'REPORTS'; _save_execution(ctx, execution)
            report_values = _reports(ctx)
        if stage in {'all', 'shap'} and cfg.run_shap:
            execution['status'] = 'SHAP'; _save_execution(ctx, execution)
            regenerate_shap_fast(ctx)
        if report_values is not None:
            metrics, stability, bootstrap = report_values
            _BASE.summarize_timing(ctx)
            _BASE.final_notes(ctx, metrics, stability, bootstrap)
            note = ('\n\nAccelerated execution: scientific settings and original protocol lineage were retained. '
                    'See execution_manifest.json and execution_attempts/ for the new engine and attempt durations. '
                    'New selection seconds sum completed candidate-fold fit durations; legacy selection seconds '
                    'retain their original timing basis. Optimization totals therefore are not parallel wall-time '
                    'benchmarks. SHAP uses checkpointed batches and can have different Monte Carlo attributions '
                    'from an unbatched historical call; samples/background/evaluation budgets are retained.\n')
            for name in ['README.md', 'analysis_interpretation.txt']:
                path = ctx['out'] / name
                path.write_text(path.read_text() + note, encoding='utf-8')
        index = ctx['out'] / 'prediction_record_index.csv'
        if stage == 'all':
            ctx['manifest'].update(status='COMPLETE', completed_time_utc=_now(),
                                   elapsed_seconds=time.perf_counter() - ctx['pipeline_started'],
                                   execution_engine=ENGINE_REVISION, execution_engine_sha256=ctx['engine_sha256'])
            if index.exists(): ctx['manifest']['prediction_index_sha256'] = _digest(index)
            _json(ctx['out'] / 'run_manifest.json', ctx['manifest'])
        execution.update(status='COMPLETE' if stage == 'all' else stage.upper() + '_COMPLETE',
                         completed_utc=_now(), elapsed_seconds=time.perf_counter() - ctx['pipeline_started'])
        _save_execution(ctx, execution)
        _json(ctx['out'] / 'progress.json', dict(stage=execution['status'], updated_utc=_now()))
        _say(ctx, f'{execution["status"]}: {ctx["out"]}')
        return ctx
    except BaseException as exc:
        execution.update(status='INTERRUPTED' if isinstance(exc, KeyboardInterrupt) else 'FAILED',
                         stopped_utc=_now(), exception_type=type(exc).__name__, exception_message=str(exc))
        _save_execution(ctx, execution)
        _say(ctx, 'Saved checkpoints retained. Rerun the same call to continue.')
        raise


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Study C: accelerated execution with candidate-fold, learner and SHAP checkpoints')
    parser.add_argument('--config', help='JSON file of original StudyCConfig fields')
    parser.add_argument('--workers', type=int, default=RuntimeOptions().workers)
    parser.add_argument('--stage', choices=['all', 'tune', 'fit', 'reports', 'shap'], default='all')
    parser.add_argument('--validate-only', action='store_true')
    parser.add_argument('--status', action='store_true')
    args = parser.parse_args()
    cfg = StudyCConfig(**(json.loads(Path(args.config).read_text()) if args.config else {}))
    if args.status: print(json.dumps(checkpoint_status(cfg), indent=2))
    else: run_study_c_fast(cfg, RuntimeOptions(workers=args.workers, stage=args.stage), validate_only=args.validate_only)
